/**
 * All of the JS for your public-facing functionality should be
 * included in this file.
 */
(function( $ ) {
    'use strict';

    // Security check: always validate nonce in AJAX requests
    function ajaxRequest(data) {
        data.nonce = wp2id_public.nonce;
        
        return $.ajax({
            url: wp2id_public.ajax_url,
            method: 'POST',
            data: data
        });
    }

    $(document).ready(function() {
        // Public initialization code here
    });

})( jQuery );
