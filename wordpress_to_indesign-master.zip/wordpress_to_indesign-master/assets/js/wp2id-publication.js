/**
 * JS functionality for the Publication post type
 */
(function($) {
    'use strict';

    // Global variable to store template tags details for word count warnings
    let templateTagsDetails = {};
    
    // Global variable to store post preview data
    let postPreviewData = {};
    
    // Global variable to store used tags across all posts
    let globalUsedTags = [];

    // Initialize on document ready
    $(document).ready(function() {
        initPublicationMetabox();
    });

    /**
     * Initialize the publication metabox functionality
     */
    function initPublicationMetabox() {
        // Initialize upload mode switching
        initUploadModeSwitching();
        
        // Initialize direct IDML upload
        initDirectIdmlUpload();
        
        // Initialize central mappings from server data to UI
        initializeCentralMappingsToUI();
        
        // Initialize bulk actions functionality
        initBulkActions();
        
        // Initialize tab switching
        $('.wp2id-tab-link').on('click', function(e) {
            e.preventDefault();
            var tabId = $(this).data('tab');
            
            // Update active tab link
            $('.wp2id-tab-link').removeClass('active');
            $(this).addClass('active');
            
            // Show the selected tab content
            $('.wp2id-tab-content').removeClass('active');
            $('#wp2id-tab-' + tabId).addClass('active');
        });
        
        // Initialize sortable for selected posts
        $('#wp2id_selected_posts_body').sortable({
            placeholder: 'sortable-placeholder',
            items: 'tr:not(.no-posts)',
            axis: 'y',
            handle: 'td',
            helper: function(e, ui) {
                // Fix the cell widths during drag
                ui.children().each(function() {
                    $(this).width($(this).width());
                });
                return ui;
            },
            update: function(event, ui) {
                updatePostOrder();
            }
        });
        
        // Initialize select all checkbox
        $('#wp2id-select-all-posts').on('change', function() {
            $('.wp2id-post-check').prop('checked', $(this).prop('checked'));
        });
         // Update select all checkbox when individual checkboxes change
        $(document).on('change', '.wp2id-post-check', function() {
            updateSelectAllCheckboxState();
        });
        

        // Bind search/filter action
        $('#wp2id_filter_posts').on('click', function() {
            searchPosts(1);
        });

        // Bind reset filters action
        $('#wp2id_reset_filters').on('click', function() {
            resetFilters();
        });

        // Bind preview publication action
        $('#wp2id_preview_publication').on('click', function() {
            console.log('Preview publication requested');
            handlePreviewPublication();
        });

        // Bind export publication action
        $('#wp2id_export_publication').on('click', function() {
            console.log('Export publication requested');
            handleExportPublication();
        });

        // Allow pressing Enter in search field
        $('#wp2id_post_search').keypress(function(e) {
            if (e.which == 13) {
                e.preventDefault();
                searchPosts(1);
            }
        });

        // Delegate click handler for adding posts from search results
        $('#wp2id_search_results_container').on('click', '.wp2id-add-post', function(e) {
            e.preventDefault();
            
            // Immediately disable the button to prevent double-clicks
            var $button = $(this);
            if ($button.prop('disabled')) {
                return; // Already processing
            }
            
            var postId = $button.data('id');
            var postTitle = $button.data('title');
            var postType = $button.data('type');
            
            // Get page number from the corresponding input field
            var pageNumber = $('#page_number_' + postId).val() || '';
            
            // Disable button immediately
            $button.prop('disabled', true).text('Adding...');
            
            addPostToSelected(postId, postTitle, postType, pageNumber, function(success) {
                if (success) {
                    $button.text(wp2id_publication.i18n.addToPub + 'ed');
                } else {
                    // Re-enable button if addition failed
                    $button.prop('disabled', false).text(wp2id_publication.i18n.addToPub);
                }
            });
        });

        // Handle page number updates for search results
        $('#wp2id_search_results_container').on('input change', '.wp2id-page-number', function() {
            var postId = $(this).data('post-id');
            var pageNumber = $(this).val();
            
            // Update page number in selected posts if the post is already selected
            var selectedRow = $('#wp2id_selected_posts tr[data-post-id="' + postId + '"]');
            if (selectedRow.length > 0) {
                selectedRow.find('.post-page-number').text(pageNumber);
                updatePageNumberInData(postId, pageNumber);
                
                // Update page info display if dialog is open for this post
                const dialogPostId = $('#wp2id-position-post-id').val();
                if (dialogPostId == postId && $('.wp2id-position-dialog').is(':visible')) {
                    updatePageInfoDisplay(postId);
                }
            }
        });

        // Delegate click handler for removing posts from selected list
        $('#wp2id_selected_posts').on('click', '.wp2id-remove-post', function(e) {
            e.preventDefault();
            removeSelectedPost($(this).data('id'));
        });
    }

    /**
     * Search posts based on filter criteria
     */
    function searchPosts(page) {
        var $resultsContainer = $('#wp2id_search_results_container');
        var $paginationContainer = $('#wp2id_search_results_pagination');
        
        // Show loading message
        $resultsContainer.html('<p>' + wp2id_publication.i18n.loading + '</p>');
        
        // Collect filter data
        var data = {
            action: 'wp2id_search_posts',
            nonce: wp2id_publication.nonce,
            category: $('#wp2id_post_category').val(),
            date_filter: $('#wp2id_post_date').val(),
            author: $('#wp2id_post_author').val(),
            search: $('#wp2id_post_search').val(),
            paged: page || 1
        };
        
        // Make AJAX request
        console.log("wp2id_publication", wp2id_publication);
        console.log("data", data);
        $.post(wp2id_publication.ajaxurl, data, function(response) {
            if (response.success) {
                renderSearchResults(response.data);
            } else {
                $resultsContainer.html('<p class="error">' + response.data.message + '</p>');
                $paginationContainer.empty();
            }
        })
        .fail(function() {
            $resultsContainer.html('<p class="error">Error connecting to server.</p>');
            $paginationContainer.empty();
        });
    }

    /**
     * Render search results and pagination
     */
    function renderSearchResults(data) {
        var $resultsContainer = $('#wp2id_search_results_container');
        var $paginationContainer = $('#wp2id_search_results_pagination');
        var html = '';
        
        if (data.posts.length === 0) {
            html = '<p>No posts found. Try different search criteria.</p>';
        } else {
            for (var i = 0; i < data.posts.length; i++) {
                var post = data.posts[i];
                var isAlreadySelected = $('#wp2id_selected_posts input[value="' + post.id + '"]').length > 0;
                
                // Get existing page number if post is already selected
                var existingPageNumber = '';
                if (isAlreadySelected) {
                    var selectedRow = $('#wp2id_selected_posts tr[data-post-id="' + post.id + '"]');
                    if (selectedRow.length > 0) {
                        existingPageNumber = selectedRow.find('.post-page-number').text() || '';
                    }
                }
                
                html += '<div class="wp2id-search-result">';
                html += '<div class="result-content">';
                html += '<div class="result-title">' + post.title + '</div>';
                html += '<div class="result-info">' + post.date + ' | ' + post.author + ' | ' + post.categories + '</div>';
                html += '</div>';
                
                html += '<div class="result-page-info">';
                html += '<label for="page_number_' + post.id + '">Page:</label>';
                html += '<input type="text" id="page_number_' + post.id + '" class="wp2id-page-number" placeholder="Page number/name" value="' + existingPageNumber + '" data-post-id="' + post.id + '">';
                html += '</div>';
                
                html += '<div class="result-actions">';
                if (isAlreadySelected) {
                    html += '<button disabled class="wp2id-add-post added">' + wp2id_publication.i18n.addToPub + 'ed</button>';
                } else {
                    html += '<button class="wp2id-add-post" data-id="' + post.id + '" data-title="' + post.title + '" data-type="' + post.post_type + '">' + wp2id_publication.i18n.addToPub + '</button>';
                }
                html += '</div>';
                
                html += '</div>';
            }
        }
        
        // Update results
        $resultsContainer.html(html);
        
        // Update pagination
        renderPagination(data.pages, data.total);
    }

    /**
     * Render pagination controls
     */
    function renderPagination(totalPages, totalPosts) {
        var $paginationContainer = $('#wp2id_search_results_pagination');
        var html = '';
        
        if (totalPages > 1) {
            html += '<div class="tablenav-pages">';
            html += '<span class="displaying-num">' + totalPosts + ' items</span>';
            html += '<span class="pagination-links">';
            
            for (var i = 1; i <= Math.min(totalPages, 5); i++) {
                html += '<a class="page-numbers" href="#" data-page="' + i + '">' + i + '</a>';
            }
            
            if (totalPages > 5) {
                html += '<span class="page-numbers dots">…</span>';
                html += '<a class="page-numbers" href="#" data-page="' + totalPages + '">' + totalPages + '</a>';
            }
            
            html += '</span>';
            html += '</div>';
        }
        
        $paginationContainer.html(html);
        
        // Bind pagination clicks
        $('.page-numbers').on('click', function(e) {
            e.preventDefault();
            var page = $(this).data('page');
            searchPosts(page);
        });
    }

    /**
     * Reset all filters to default values
     */
    function resetFilters() {
        $('#wp2id_post_category').val('');
        $('#wp2id_post_date').val('');
        $('#wp2id_post_author').val('');
        $('#wp2id_post_search').val('');
        
        // Reset search results
        $('#wp2id_search_results_container').html('<p class="description">Use the filters above to search for posts.</p>');
        $('#wp2id_search_results_pagination').empty();
    }

    /**
     * Add a post to the selected posts list
     */
    function addPostToSelected(postId, postTitle, postType, pageNumber, callback) {
        // If pageNumber is a function (backward compatibility), it's actually the callback
        if (typeof pageNumber === 'function') {
            callback = pageNumber;
            pageNumber = '';
        }
        
        // Remove "no posts" message if present
        $('#wp2id_selected_posts_body .no-posts').remove();
        
        // Check if not already added (double check to prevent race conditions)
        if ($('#wp2id_selected_posts_body input[value="' + postId + '"]').length > 0) {
            console.log('Post already exists, skipping addition');
            if (callback) callback(false);
            return;
        }
        
        // Add a temporary placeholder to prevent duplicate additions during AJAX
        var $placeholder = $('<tr id="post-' + postId + '-temp" class="post-row-temp">' +
            '<td colspan="11">Adding post...</td></tr>');
        $('#wp2id_selected_posts_body').append($placeholder);
        
        // Fetch comprehensive post data via AJAX
        $.post(wp2id_publication.ajaxurl, {
            action: 'wp2id_get_post_details',
            nonce: wp2id_publication.nonce,
            post_id: postId
        }, function(response) {
            // Remove placeholder
            $placeholder.remove();
            
            // Final check to ensure post wasn't added by another request
            if ($('#wp2id_selected_posts_body input[value="' + postId + '"]').length > 0) {
                console.log('Post was already added by another request, skipping');
                if (callback) callback(false);
                return;
            }
            
            if (response.success) {
                var post = response.data;
                
                var html = '<tr id="post-' + postId + '" class="post-row" data-post-id="' + postId + '" data-post-content="' + encodeURIComponent(post.content) + '">';
                html += '<td class="check-column">';
                html += '<input type="checkbox" class="wp2id-post-check" name="wp2id_post_check[]" value="' + postId + '">';
                html += '<input type="hidden" name="wp2id_publication_posts[]" value="' + postId + '">';
                html += '</td>';
                html += '<td class="id-column">' + postId + '</td>';
                html += '<td class="title-column">';
                html += post.title;
                html += '</td>';
                html += '<td class="image-column">';
                html += (post.thumbnail || '<div class="no-thumbnail">No Image</div>');
                html += '</td>';
                html += '<td class="content-column">';
                html += '<div class="content-preview wp2id-content-preview">' + post.content + '</div>';
                html += '</td>';
                html += '<td class="excerpt-column">';
                html += '<div class="excerpt-preview">' + post.excerpt + '</div>';
                html += '</td>';
                html += '<td class="author-column">';
                html += post.author;
                html += '</td>';
                html += '<td class="date-column">';
                html += post.date;
                html += '</td>';
                html += '<td class="category-column">';
                html += post.categories;
                html += '</td>';
                html += '<td class="page-column">';
                html += '<span class="post-page-number">' + (pageNumber || '') + '</span>';
                html += '<input type="hidden" name="wp2id_page_numbers[' + postId + ']" value="' + (pageNumber || '') + '">';
                html += '</td>';
                html += '<td class="actions-column">';
                html += '<a href="#" class="wp2id-remove-post button button-small" data-id="' + postId + '">';
                html += wp2id_publication.i18n.remove + '</a>';
                html += '<a href="#" class="wp2id-set-position button button-small" data-id="' + postId + '">';
                html += 'Set Template Tags</a>';
                html += '</td>';
                html += '</tr>';
                
                $('#wp2id_selected_posts_body').append(html);
                
                // Update the select all checkbox state after adding new row
                updateSelectAllCheckboxState();
                
                if (callback) callback(true);
            } else {
                // Fallback with minimal information if AJAX fails
                var html = '<tr id="post-' + postId + '" class="post-row">';
                html += '<td class="check-column">';
                html += '<input type="checkbox" class="wp2id-post-check" name="wp2id_post_check[]" value="' + postId + '">';
                html += '<input type="hidden" name="wp2id_publication_posts[]" value="' + postId + '">';
                html += '</td>';
                html += '<td class="id-column">' + postId + '</td>';
                html += '<td class="title-column">' + postTitle + '</td>';
                html += '<td class="image-column"><div class="no-thumbnail">No Image</div></td>';
                html += '<td class="content-column"><div class="content-preview">Loading...</div></td>';
                html += '<td class="excerpt-column"><div class="excerpt-preview">Loading...</div></td>';
                html += '<td class="author-column">-</td>';
                html += '<td class="date-column">-</td>';
                html += '<td class="category-column">-</td>';
                html += '<td class="page-column">';
                html += '<span class="post-page-number">' + (pageNumber || '') + '</span>';
                html += '<input type="hidden" name="wp2id_page_numbers[' + postId + ']" value="' + (pageNumber || '') + '">';
                html += '</td>';
                html += '<td class="actions-column">';
                html += '<a href="#" class="wp2id-remove-post button button-small" data-id="' + postId + '">';
                html += wp2id_publication.i18n.remove + '</a>';
                html += '<a href="#" class="wp2id-set-position button button-small" data-id="' + postId + '">';
                html += 'Set Template Tags</a>';
                html += '</td>';
                html += '</tr>';
                
                $('#wp2id_selected_posts_body').append(html);
                
                // Update the select all checkbox state after adding new row
                updateSelectAllCheckboxState();
                
                if (callback) callback(true);
            }
        }).fail(function() {
            // Remove placeholder
            $placeholder.remove();
            
            // Fallback if AJAX completely fails
            var html = '<tr id="post-' + postId + '" class="post-row">';
            html += '<td class="check-column">';
            html += '<input type="checkbox" class="wp2id-post-check" name="wp2id_post_check[]" value="' + postId + '">';
            html += '<input type="hidden" name="wp2id_publication_posts[]" value="' + postId + '">';
            html += '</td>';
            html += '<td class="id-column">' + postId + '</td>';
            html += '<td class="title-column">' + postTitle + '</td>';
            html += '<td class="image-column"><div class="no-thumbnail">No Image</div></td>';
            html += '<td class="content-column"><div class="content-preview">Loading...</div></td>';
            html += '<td class="excerpt-column"><div class="excerpt-preview">Loading...</div></td>';
            html += '<td class="author-column">-</td>';
            html += '<td class="date-column">-</td>';
            html += '<td class="category-column">-</td>';
            html += '<td class="page-column">';
            html += '<span class="post-page-number>' + (pageNumber || '') + '</span>';
            html += '<input type="hidden" name="wp2id_page_numbers[' + postId + ']" value="' + (pageNumber || '') + '">';
            html += '</td>';
            html += '<td class="actions-column">';
            html += '<a href="#" class="wp2id-remove-post button button-small" data-id="' + postId + '">';
            html += wp2id_publication.i18n.remove + '</a>';
            html += '<a href="#" class="wp2id-set-position button button-small" data-id="' + postId + '">';
            html += 'Set Template Tags</a>';
            html += '</td>';
            html += '</tr>';
            
            $('#wp2id_selected_posts_body').append(html);
            
            // Update the select all checkbox state after adding new row
            updateSelectAllCheckboxState();
            
            if (callback) callback(true);
        });
    }

    /**
     * Remove a post from the selected posts list
     */
    function removeSelectedPost(postId) {
        console.log("=== Removing post from selected posts ===");
        console.log("Post ID to remove:", postId);
        
        // Remove the post row from the UI
        $('#wp2id_selected_posts_body #post-' + postId).remove();
        
        // Remove mapping data from central mappings field
        removeMappingDataForPost(postId);
        
        // Add "no posts" message if empty
        if ($('#wp2id_selected_posts_body tr').length === 0) {
            $('#wp2id_selected_posts_body').html(
                '<tr class="no-posts">' +
                '<td colspan="10">No posts selected. Use the Search tab to find and add posts.</td>' +
                '</tr>'
            );
        }
        
        // Update the select all checkbox state after removing row
        updateSelectAllCheckboxState();
        
        // Enable the add button in search results if present
        $('.wp2id-add-post[data-id="' + postId + '"]')
            .prop('disabled', false)
            .text(wp2id_publication.i18n.addToPub);
        
        console.log("=== Post removal completed ===");
    }

    /**
     * Update the order of selected posts after sorting
     */
    function updatePostOrder() {
        // This function doesn't need to do anything special since
        // the form will submit the posts in the correct order based
        // on the DOM order of the hidden inputs
    }
    
    /**
     * Update select all checkbox state based on individual checkboxes
     */
    function updateSelectAllCheckboxState() {
        var totalCheckboxes = $('.wp2id-post-check').length;
        var checkedCheckboxes = $('.wp2id-post-check:checked').length;
        
        if (checkedCheckboxes === 0) {
            $('#wp2id-select-all-posts').prop('indeterminate', false);
            $('#wp2id-select-all-posts').prop('checked', false);
        } else if (checkedCheckboxes === totalCheckboxes) {
            $('#wp2id-select-all-posts').prop('indeterminate', false);
            $('#wp2id-select-all-posts').prop('checked', true);
        } else {
            $('#wp2id-select-all-posts').prop('indeterminate', true);
            $('#wp2id-select-all-posts').prop('checked', false);
        }
    }
    
    /**
     * Initialize position dialog and related functionality
     */
    function initPositionDialog() {
        // Add event listener for 'Set Position' button clicks (now for tag mapping)
        $(document).on('click', '.wp2id-set-position', function(e) {
            e.preventDefault();
            const postId = $(this).data('id');
            
            // Store the post ID in the dialog
            $('#wp2id-position-post-id').val(postId);
            $('#wp2id-tag-mapping-dialog').data('post-id', postId);
            
            // Update page information display
            updatePageInfoDisplay(postId);
            
            // Load existing tag mappings
            const positionData = $('#post-' + postId).data('positions') || {};
            if (positionData.tagMappings) {
                updateTagMappingIndicators(postId, positionData.tagMappings);
            }
            
            // Load template tags and post preview simultaneously
            const templateTagsPromise = loadTemplateTags(postId);
            const postPreviewPromise = loadPostPreview(postId);
            
            // Wait for both to complete, then check for warnings
            Promise.all([templateTagsPromise, postPreviewPromise]).then(() => {
                // Small delay to ensure UI is fully rendered
                setTimeout(() => {
                    checkExistingMappingWarnings();
                }, 100);
            }).catch((error) => {
                console.log("Warning: One or both AJAX calls failed, skipping warning checks:", error);
                // Continue without warnings if data loading fails
            });
            
            // Show dialog and overlay
            $('.wp2id-position-overlay').fadeIn(200);
            $('.wp2id-position-dialog').fadeIn(200);
        });
        
        // Close dialog when clicking the X or Cancel button
        $('.wp2id-position-dialog-close, #wp2id-cancel-position').on('click', function(e) {
            e.preventDefault();
            closePositionDialog();
        });
        
        // Close dialog when clicking the overlay
        $('.wp2id-position-overlay').on('click', function() {
            closePositionDialog();
        });
        
        // Handle saving the tag mappings
        $('#wp2id-save-position').on('click', function() {
            const postId = $('#wp2id-position-post-id').val();
            
            if (postId) {
                // Save tag mappings
                saveTagMappings(postId);
                
                // Close dialog
                closePositionDialog();
            }
        });
        
        // Add event handler for "Add Position" button
        $(document).on('click', '.wp2id-add-position-btn', function() {
            const element = $(this).data('element');
            const $contentItem = $(this).closest('.wp2id-mapping-item');
            
            if (element === 'content') {
                // Get available tags from the first position select
                const $firstSelect = $contentItem.find('.wp2id-position-tag-select').first();
                const availableTags = [];
                $firstSelect.find('option').each(function() {
                    const value = $(this).val();
                    if (value) {
                        availableTags.push(value);
                    }
                });
                
                addContentPosition($contentItem, '', '', '', availableTags);
                
                // Update tag availability after adding new position
                setTimeout(() => {
                    updateTagSelectsAvailability();
                }, 0);
            }
        });
    }
    
    /**
     * Close the position dialog
     */
    function closePositionDialog() {
        $('.wp2id-position-dialog').fadeOut(200);
        $('.wp2id-position-overlay').fadeOut(200);
    }
    
    /**
     * Load position data for a post - now only handles tag mappings
     */
    function loadTagMappingData(postId) {
        // Get post positions from hidden input or data attribute
        const positionData = $('#post-' + postId).data('positions') || {};
        
        // If there are tag mappings, update visual indicators
        if (positionData.tagMappings) {
            updateTagMappingIndicators(postId, positionData.tagMappings);
        }
    }
    
    /**
     * Load position data for a specific element
     */
    function loadElementPositionData(postId, element) {
        // Get post positions from hidden input or data attribute
        const positionData = $('#post-' + postId).data('positions') || {};
        const elementData = positionData[element] || {};
        
        // Set horizontal position if available
        if (elementData.horizontal) {
            $('input[name="wp2id_horizontal_position"][value="' + elementData.horizontal + '"]').prop('checked', true);
        }
        
        // Set vertical position if available
        if (elementData.vertical) {
            $('input[name="wp2id_vertical_position"][value="' + elementData.vertical + '"]').prop('checked', true);
        }
    }
    
    /**
     * Save position data for a post element
     */
    function savePositionData(postId, element, horizontalPos, verticalPos) {
        const $row = $('#post-' + postId);
        let positionData = $row.data('positions') || {};
        
        // Initialize element data if needed
        if (!positionData[element]) {
            positionData[element] = {};
        }
        
        // Set positions
        positionData[element].horizontal = horizontalPos;
        positionData[element].vertical = verticalPos;
        
        // Store the data
        $row.data('positions', positionData);
        
        // Add hidden input with position data if not exists
        let $posInput = $row.find('input[name="wp2id_positions[' + postId + ']"]');
        if ($posInput.length === 0) {
            $posInput = $('<input>').attr({
                type: 'hidden',
                name: 'wp2id_positions[' + postId + ']'
            });
            $row.append($posInput);
        }
        
        // Store JSON data in hidden input
        $posInput.val(JSON.stringify(positionData));
    }
    
    /**
     * Update visual indicators for position
     */
    function updatePositionIndicator(postId, element, horizontalPos, verticalPos) {
        const $row = $('#post-' + postId);
        const colMap = {
            'title': '.title-column',
            'content': '.content-column',
            'excerpt': '.excerpt-column',
            'image': '.image-column',
            'author': '.author-column',
            'date': '.date-column',
            'category': '.category-column'
        };
        
        // Get the cell for this element
        const $cell = $row.find(colMap[element]);
        if (!$cell.length) return;
        
        // Remove existing position classes
        $cell.removeClass('pos-left pos-right pos-center pos-top pos-middle pos-bottom');
        
        // Add new position classes
        if (horizontalPos) {
            $cell.addClass('pos-' + horizontalPos);
        }
        
        if (verticalPos) {
            $cell.addClass('pos-' + verticalPos);
        }
        
        // Add position label if it doesn't exist
        let $posLabel = $cell.find('.wp2id-position-label');
        if ($posLabel.length === 0) {
            $posLabel = $('<span class="wp2id-position-label"></span>');
            $cell.append($posLabel);
        }
        
        // Set position label text
        const posText = [];
        if (horizontalPos) posText.push(horizontalPos);
        if (verticalPos) posText.push(verticalPos);
        
        if (posText.length > 0) {
            $posLabel.text(posText.join('-')).show();
        } else {
            $posLabel.hide();
        }
    }
    
    /**
     * Update visual indicators for tag mappings
     */
    function updateTagMappingIndicators(postId, mappings) {
        const $row = $('#post-' + postId);
        const colMap = {
            'title': '.title-column',
            'content': '.content-column',
            'excerpt': '.excerpt-column',
            'image': '.image-column',
            'author': '.author-column',
            'date': '.date-column',
            'category': '.category-column'
        };
        
        // Remove existing mapping indicators
        $row.find('.wp2id-tag-mapping-indicator').remove();
        
        // Add new mapping indicators with warning checks
        for (const element in mappings) {
            if (colMap[element]) {
                const $cell = $row.find(colMap[element]);
                const mapping = mappings[element];
                
                if ($cell.length && mapping) {
                    let hasWarning = false;
                    
                    // Check for warnings based on element type
                    if (element === 'content' && Array.isArray(mapping)) {
                        // Content with multiple positions
                        for (const position of mapping) {
                            if (position.tag && checkMappingWarning(postId, element, position.tag, position)) {
                                hasWarning = true;
                                break;
                            }
                        }
                    } else if (typeof mapping === 'string') {
                        // Standard single mapping
                        hasWarning = checkMappingWarning(postId, element, mapping);
                    }
                    
                    // Create tag indicator
                    const $indicator = $('<div>')
                        .addClass('wp2id-tag-mapping-indicator')
                        .addClass(hasWarning ? 'warning' : '')
                        .attr('title', hasWarning ? 'Mapped with warning: content exceeds limit' : `Mapped to tag: ${typeof mapping === 'string' ? mapping : 'multiple'}`)
                        .text('T');
                    
                    $cell.append($indicator);
                }
            }
        }
    }

    /**
     * Update the central mappings hidden field with all post mappings
     */
    function updateCentralMappingsField() {
        const allMappings = {};
        
        // Collect mappings from all posts in the work area
        $('#wp2id_selected_posts_body .post-row').each(function() {
            const $row = $(this);
            const postId = $row.attr('id').replace('post-', '');
            const positionData = $row.data('positions') || {};
            
            if (positionData.tagMappings && Object.keys(positionData.tagMappings).length > 0) {
                allMappings[postId] = positionData.tagMappings;
            }
        });
        
        // Update the central hidden field
        $('#wp2id_post_mappings').val(JSON.stringify(allMappings));
        
        console.log('Updated central mappings field with data:', allMappings);
    }

    /**
     * Remove mapping data for a specific post from the central mappings field
     */
    function removeMappingDataForPost(postId) {
        console.log("=== Removing mapping data for post ===");
        console.log("Post ID:", postId);
        
        // Get current central mappings
        const centralMappingsJson = $('#wp2id_post_mappings').val();
        let centralMappings = {};
        
        if (centralMappingsJson) {
            try {
                centralMappings = JSON.parse(centralMappingsJson);
            } catch (e) {
                console.error("Error parsing central mappings JSON:", e);
                centralMappings = {};
            }
        }
        
        console.log("Current central mappings before removal:", centralMappings);
        
        // Remove the post mapping data
        if (centralMappings[postId]) {
            console.log("Removing mapping data for post", postId, ":", centralMappings[postId]);
            delete centralMappings[postId];
        } else {
            console.log("No mapping data found for post", postId);
        }
        
        // Update the central hidden field with the cleaned data
        $('#wp2id_post_mappings').val(JSON.stringify(centralMappings));
        
        console.log("Updated central mappings after removal:", centralMappings);
        console.log("=== Mapping data removal completed ===");
    }
    
    /**
     * Load template tags for a post
     */
    function loadTemplateTags(postId) {
        // Get publication ID from the localized data
        const publicationId = wp2id_publication.postId;
        
        // Return promise for the AJAX request
        return $.post(wp2id_publication.ajaxurl, {
            action: 'wp2id_get_template_tags',
            nonce: wp2id_publication.nonce,
            publication_id: publicationId,
            post_id: postId
        }).then(function(response) {
            if (response.success) {
                // Store template tags details globally for word count warnings
                if (response.data.tags_details) {
                    templateTagsDetails = response.data.tags_details;
                }
                
                // Store global used tags for cross-post availability checking
                if (response.data.used_tags) {
                    globalUsedTags = response.data.used_tags;
                    console.log('=== WP2ID Tag Availability Debug ===');
                    console.log('Global used tags loaded:', globalUsedTags);
                    console.log('Current post mappings:', response.data.mappings);
                    console.log('===================================');
                }
                
                renderTagMappingInterface(response.data.tags, response.data.mappings);
                return response.data; // Return data for promise chain
            } else {
                showNoTemplateMessage(response.data.message);
                throw new Error(response.data.message);
            }
        }).fail(function() {
            showNoTemplateMessage('Error loading template tags.');
            throw new Error('Error loading template tags.');
        });
    }
    
    /**
     * Render the tag mapping interface
     */
    function renderTagMappingInterface(tags, existingMappings) {
        // Hide loading message and show container
        $('.wp2id-tags-loading').hide();
        $('.wp2id-tags-mapping-container').show();
        $('.wp2id-no-template-message').hide();
        
        const $container = $('#wp2id-tag-mapping-list');
        $container.empty();
        
        // Create mapping controls for each post element
        const elements = ['title', 'content', 'excerpt', 'image', 'author', 'date', 'category'];
        
        elements.forEach(element => {
            const elementLabel = element.charAt(0).toUpperCase() + element.slice(1);
            const isMapped = existingMappings && existingMappings[element];
            
            // Special handling for content element with multiple positions
            if (element === 'content') {
                const $item = $(`
                    <div class="wp2id-mapping-item" data-element="${element}">
                        <div class="wp2id-element-header ${isMapped ? 'mapped' : 'unmapped'}">
                            <div class="wp2id-element-icon">${elementLabel.charAt(0)}</div>
                            <div class="wp2id-element-label">${elementLabel}</div>
                        </div>
                        <div class="wp2id-control-group">
                            <label class="wp2id-control-label">Map Content Positions to Template Tags:</label>
                            <div class="wp2id-content-positions">
                                <div class="wp2id-positions-header">
                                    <h4 class="wp2id-positions-title">Content Position Mappings</h4>
                                    <button type="button" class="wp2id-add-position-btn" data-element="content">Add Position</button>
                                </div>
                                <div class="wp2id-position-list" data-element="content">
                                    <!-- Position items will be added here -->
                                </div>
                            </div>
                        </div>
                    </div>
                `);
                
                // Load existing content positions if available
                if (existingMappings && existingMappings[element]) {
                    const positions = Array.isArray(existingMappings[element]) ? existingMappings[element] : [existingMappings[element]];
                    positions.forEach((position, index) => {
                        let $positionItem;
                        if (typeof position === 'object' && position.tag) {
                            $positionItem = addContentPosition($item, position.tag, position.start || '', position.end || '', tags);
                        } else if (typeof position === 'string') {
                            // Legacy single tag mapping
                            $positionItem = addContentPosition($item, position, '', '', tags);
                        }
                        
                        // Check for warnings on existing content positions (case 2.2 from flow)
                        if ($positionItem && (position.tag || (typeof position === 'string'))) {
                            // Don't check immediately, wait for data to be available
                            // checkContentPositionWarning will be called later via checkExistingMappingWarnings
                        }
                    });
                }
                
                // If no existing positions, add one empty position
                if (!existingMappings || !existingMappings[element]) {
                    addContentPosition($item, '', '', '', tags);
                }
                
                $container.append($item);
            } else {
                // Standard single tag mapping for other elements
                const $item = $(`
                    <div class="wp2id-mapping-item" data-element="${element}">
                        <div class="wp2id-element-header ${isMapped ? 'mapped' : 'unmapped'}">
                            <div class="wp2id-element-icon">${elementLabel.charAt(0)}</div>
                            <div class="wp2id-element-label">${elementLabel}</div>
                        </div>
                        <div class="wp2id-control-group">
                            <label class="wp2id-control-label">Map to Template Tag:</label>
                            <select class="wp2id-tag-select" data-element="${element}">
                                <option value="">— Select Tag —</option>
                            </select>
                        </div>
                    </div>
                `);
                
                const $select = $item.find('.wp2id-tag-select');
                console.log("tags: ", tags);
                console.log("tag details: ", templateTagsDetails);
                 // Populate tag options
                if (Array.isArray(tags)) {
                    tags.forEach(tag => {
                        // Get details from template details if available
                        const tagDetails = templateTagsDetails[tag];
                        
                        const characterLimit = tagDetails && tagDetails.length ? tagDetails.length : null;
                        const wordCount = tagDetails && tagDetails.word_count ? tagDetails.word_count : null;
                        const pageInfo = tagDetails && tagDetails.page_info ? tagDetails.page_info : null;
                        
                        // Create option text with additional info
                        let optionText = tag;
                        let additionalInfo = [];
                        
                        // Add word count and character limit info
                        if (wordCount && characterLimit) {
                            additionalInfo.push(`${wordCount} words, ${characterLimit} chars`);
                        } else if (wordCount) {
                            additionalInfo.push(`${wordCount} words`);
                        } else if (characterLimit) {
                            additionalInfo.push(`${characterLimit} chars`);
                        }
                        
                        if (pageInfo && pageInfo.page_numbers && pageInfo.page_numbers.length > 0) {
                            const pages = pageInfo.page_numbers;
                            if (pages.length > 3) {
                                additionalInfo.push(`pages: ${pages[0]}-${pages[pages.length-1]}`);
                            } else {
                                additionalInfo.push(`page: ${pages.join(', ')}`);
                            }
                        }
                        
                        if (additionalInfo.length > 0) {
                            optionText = `${tag} (${additionalInfo.join(', ')})`;
                        }
                         const $option = $('<option>').val(tag).text(optionText);
                        if (existingMappings && existingMappings[element] === tag) {
                            $option.prop('selected', true);
                        }
                        $select.append($option);
                    });
                }

                // Add change event listener for content warnings
                $select.on('change', function() {
                    console.log("Tag select changed for element:", element);
                    const selectedTag = $(this).val();
                    const hasMapping = selectedTag !== '';
                    const $header = $item.find('.wp2id-element-header');
                    $header.removeClass('mapped unmapped').addClass(hasMapping ? 'mapped' : 'unmapped');
                    
                    // Check for content warning if tag is selected
                    if (selectedTag && hasMapping) {
                        checkContentWarning(element, selectedTag, $item);
                    } else {
                        // Clear any existing warnings
                        clearContentWarning($item);
                    }
                    
                    // Update tag availability across all selects
                    updateTagSelectsAvailability();
                });

                $container.append($item);
                
                // Check for warnings on existing mappings (case 2.2 from flow)
                if (existingMappings && existingMappings[element]) {
                    // Don't check immediately, wait for data to be available
                    // checkContentWarning will be called later via checkExistingMappingWarnings
                }
            }
        });
        
        // Update tag availability after all elements are rendered
        setTimeout(() => {
            updateTagSelectsAvailability();
        }, 0);
    }
    
    /**
     * Show no template message
     */
    function showNoTemplateMessage(message) {
        $('.wp2id-tags-loading').hide();
        $('.wp2id-tags-mapping-container').hide();
        $('.wp2id-no-template-message').show().find('p').text(message || 'No template selected or no tags available.');
    }
    
    /**
     * Save tag mappings
     */
    function saveTagMappings(postId) {
        console.log("=== Starting saveTagMappings function ===");
        console.log("Post ID:", postId);
        
        // Collect mappings from the dialog
        const mappings = {};
        let mappingCount = 0;
        
        // Handle standard single-select elements
        $('#wp2id-tag-mapping-list .wp2id-tag-select').each(function() {
            const element = $(this).data('element');
            const tagName = $(this).val();
            
            if (tagName) {
                mappings[element] = tagName;
                mappingCount++;
                console.log(`Mapped ${element} to tag: ${tagName}`);
            }
        });
        
        // Handle content element with multiple positions
        const $contentItem = $('#wp2id-tag-mapping-list .wp2id-mapping-item[data-element="content"]');
        if ($contentItem.length > 0) {
            const contentPositions = [];
            
            $contentItem.find('.wp2id-position-item').each(function() {
                const $item = $(this);
                const tag = $item.find('.wp2id-position-tag-select').val();
                const start = $item.find('.wp2id-position-start').val();
                const end = $item.find('.wp2id-position-end').val();
                console.log(`Processing content position: tag=${tag}, start=${start}, end=${end}`);
                if (tag) {
                    const position = {
                        tag: tag,
                        start: start ? parseInt(start) : null,
                        end: end ? parseInt(end) : null
                    };
                    
                    contentPositions.push(position);
                    mappingCount++;
                    console.log(`Mapped content position to tag: ${tag} (${start}-${end})`);
                }
            });
            
            if (contentPositions.length > 0) {
                mappings['content'] = contentPositions;
            }
        }
        
        console.log("Total mappings collected:", mappingCount);
        console.log("Mappings data:", mappings);
        
        // Get the post row
        const $row = $('#post-' + postId);
        if ($row.length === 0) {
            console.error("Post row not found for ID:", postId);
            return;
        }
        
        // Get existing position data
        let posData = $row.data('positions') || {};
        console.log("Existing position data:", posData);
        
        // Update tag mappings
        posData.tagMappings = mappings;
        posData.lastMappingUpdate = Date.now();
        
        // Store the data in the row
        $row.data('positions', posData);
        console.log("Updated position data:", posData);
        
        // Update hidden input
        let $posInput = $row.find('input[name="wp2id_positions[' + postId + ']"]');
        if ($posInput.length === 0) {
            $posInput = $('<input>').attr({
                type: 'hidden',
                name: 'wp2id_positions[' + postId + ']'
            });
            $row.append($posInput);
            console.log("Created new hidden input for position data");
        }
        
        // Store updated data in hidden input
        $posInput.val(JSON.stringify(posData));
        
        // Update central mappings hidden field
        updateCentralMappingsField();
        
        // Log the final mapping data
        console.log("Final tag mappings saved:", mappings);
        console.log("Complete position data:", posData);
        
        // Update visual indicators
        updateTagMappingIndicators(postId, mappings);
        
        // Show success message
        showSaveMappingsFeedback(mappingCount);
        
        console.log("=== saveTagMappings function completed ===");
    }
    
    /**
     * Show save mappings feedback
     */
    function showSaveMappingsFeedback(mappingCount) {
        // Create or update feedback message
        let $feedback = $('.wp2id-mapping-feedback');
        if ($feedback.length === 0) {
            $feedback = $('<div class="wp2id-mapping-feedback"></div>');
            $('.wp2id-position-actions').prepend($feedback);
        }
        
        const message = mappingCount > 0 
            ? `Mappings stored temporarily (${mappingCount} mapping${mappingCount !== 1 ? 's' : ''}). Click "Update" on the publication to save permanently.`
            : 'All mappings cleared. Click "Update" on the publication to save changes.';
            
        $feedback.html(`<div style="background: #d1edff; border: 1px solid #0073aa; padding: 8px 12px; border-radius: 4px; margin-bottom: 10px; color: #0073aa; font-size: 13px;">${message}</div>`);
        
        // Auto-hide after 5 seconds
        setTimeout(() => {
            $feedback.fadeOut();
        }, 5000);
    }

    /**
     * Initialize the central mappings data from server to UI on page load
     */
    function initializeCentralMappingsToUI() {
        console.log("=== Initializing central mappings to UI ===");
        
        // Get the central mappings from the hidden field
        const centralMappingsJson = $('#wp2id_post_mappings').val();
        console.log("Central mappings JSON from server:", centralMappingsJson);
        
        if (!centralMappingsJson) {
            console.log("No central mappings found, skipping initialization");
            return;
        }
        
        let centralMappings;
        try {
            centralMappings = JSON.parse(centralMappingsJson);
        } catch (e) {
            console.error("Error parsing central mappings JSON:", e);
            return;
        }
        
        if (!centralMappings || typeof centralMappings !== 'object') {
            console.log("Invalid central mappings data, skipping initialization");
            return;
        }
        
        console.log("Parsed central mappings:", centralMappings);
        
        // Apply mappings to each post row in the UI
        for (const postId in centralMappings) {
            const mappings = centralMappings[postId];
            
            if (!mappings || typeof mappings !== 'object') {
                continue;
            }
            
            console.log(`Applying mappings for post ${postId}:`, mappings);
            
            // Get the post row
            const $row = $('#post-' + postId);
            if ($row.length === 0) {
                console.warn(`Post row not found for ID: ${postId}`);
                continue;
            }
            
            // Get existing position data from the row
            let posData = $row.data('positions') || {};
            
            // Merge the mappings into the position data
            posData.tagMappings = mappings
            posData.lastMappingUpdate = Date.now();
            posData.loadedFromServer = true;
            
            // Store the updated data back to the row
            $row.data('positions', posData);
            
            // Update hidden input if it exists
            let $posInput = $row.find('input[name="wp2id_positions[' + postId + ']"]');
            if ($posInput.length === 0) {
                $posInput = $('<input>').attr({
                    type: 'hidden',
                    name: 'wp2id_positions[' + postId + ']'
                });
                $row.append($posInput);
            }
            $posInput.val(JSON.stringify(posData));
            
            // Update visual indicators for this post
            updateTagMappingIndicators(postId, mappings);
            
            console.log(`Successfully applied ${Object.keys(mappings).length} mappings for post ${postId}`);
        }
        
        console.log("=== Central mappings initialization completed ===");
    }

    /**
     * Load post preview in the dialog right panel
     */
    function loadPostPreview(postId) {
        console.log("Loading post preview for post ID:", postId);
        
        const $previewContainer = $('#wp2id-post-preview-container');
        
        // Show loading state
        $previewContainer.html('<p class="wp2id-preview-loading">Loading post preview...</p>');
        
        if (postPreviewData[postId]) {
            // If preview data is already loaded, render it directly
            renderPostPreview(postPreviewData[postId]);
            return Promise.resolve(postPreviewData[postId]);
        }
        
        // Return promise for the AJAX request
        return $.post(wp2id_publication.ajaxurl, {
            action: 'wp2id_get_post_details',
            nonce: wp2id_publication.nonce,
            post_id: postId
        }).then(function(response) {
            if (response.success) {
                postPreviewData[postId] = response.data;
                renderPostPreview(response.data);
                return response.data; // Return data for promise chain
            } else {
                $previewContainer.html('<p class="wp2id-preview-error">Error loading post preview: ' + response.data.message + '</p>');
                throw new Error(response.data.message);
            }
        }).fail(function() {
            $previewContainer.html('<p class="wp2id-preview-error">Failed to load post preview.</p>');
            throw new Error('Failed to load post preview.');
        });
    }
    
    /**
     * Render the post preview in the right panel
     */
    function renderPostPreview(post) {
        const $previewContainer = $('#wp2id-post-preview-container');
        
        // Calculate word counts for each section
        const titleWords = countWords(post.title);
        const authorWords = countWords(post.author);
        const dateWords = countWords(post.date);
        const excerptWords = countWords(post.excerpt);
        const contentWords = countWords(post.content);
        const categoriesWords = countWords(post.categories);
        
        let html = `
            <div class="wp2id-post-preview">
                <div class="wp2id-preview-header">
                    <h3 class="wp2id-preview-title">${post.title}</h3>
                    <div class="wp2id-title-stats">
                        <span class="wp2id-word-count"><strong>Title Words:</strong> ${titleWords}</span>
                    </div>
                    <div class="wp2id-preview-meta">
                        <span><strong>ID:</strong> ${post.id}</span>
                        <div class="wp2id-meta-item">
                            <span><strong>Author:</strong> ${post.author}</span>
                            <span class="wp2id-word-count">(${authorWords} words)</span>
                        </div>
                        <div class="wp2id-meta-item">
                            <span><strong>Date:</strong> ${post.date}</span>
                            <span class="wp2id-word-count">(${dateWords} words)</span>
                        </div>
                    </div>
                    <div class="wp2id-preview-categories">
                        <span class="wp2id-preview-category">${post.categories}</span>
                        <span class="wp2id-word-count">(${categoriesWords} words)</span>
                    </div>
                </div>
                
                <div class="wp2id-preview-content">
                    <div class="wp2id-content-preview-section">
                        <h4 class="wp2id-content-preview-title">
                            <span class="dashicons dashicons-format-image"></span>
                            Featured Image
                        </h4>
                        <div class="wp2id-preview-image-container wp2id-large-image" id="wp2id-preview-image-container">
                            ${post.thumbnail}
                        </div>
                        <div class="wp2id-image-info" id="wp2id-image-info">
                            <span class="wp2id-image-orientation">Loading image info...</span>
                        </div>
                    </div>
                    
                    <div class="wp2id-content-preview-section">
                        <h4 class="wp2id-content-preview-title">
                            <span class="dashicons dashicons-editor-alignleft"></span>
                            Excerpt
                            <span class="wp2id-section-word-count">(${excerptWords} words)</span>
                        </h4>
                        <p class="wp2id-content-preview-text">${post.excerpt}</p>
                    </div>
                    
                    <div class="wp2id-content-preview-section">
                        <h4 class="wp2id-content-preview-title">
                            <span class="dashicons dashicons-editor-paragraph"></span>
                            Content
                            <span class="wp2id-section-word-count">(${contentWords} words)</span>
                        </h4>
                        <div class="wp2id-content-preview-text">${post.content}</div>
                    </div>
                </div>
            </div>
        `;
        
        $previewContainer.html(html);
        
        // Display image orientation if available from server
        if (post.thumbnail_info && post.thumbnail_info.orientation) {
            displayImageOrientationFromServer(post.thumbnail_info);
        } else {
            // Fallback to client-side detection
            setTimeout(() => {
                detectAndDisplayImageOrientation();
            }, 100);
        }
        
        // Initialize text selection functionality for content preview
        initializeTextSelection();
    }
    
    /**
     * Display image orientation info from server data
     */
    function displayImageOrientationFromServer(thumbnailInfo) {
        const $imageContainer = $('#wp2id-preview-image-container');
        const $imageInfo = $('#wp2id-image-info');
        
        const { width, height, ratio, orientation } = thumbnailInfo;
        
        // Apply orientation class
        const orientationClass = `wp2id-image-${orientation}`;
        $imageContainer.removeClass('wp2id-image-landscape wp2id-image-portrait wp2id-image-square')
                      .addClass(orientationClass);
        
        // Update info display
        const orientationLabel = getOrientationLabel(orientation);
        $imageInfo.html(`
            <div class="wp2id-image-details">
                <span class="wp2id-image-orientation"><strong>Orientation:</strong> ${orientationLabel}</span>
                <span class="wp2id-image-dimensions"><strong>Original Size:</strong> ${width} × ${height}px</span>
                <span class="wp2id-image-ratio"><strong>Ratio:</strong> ${ratio}</span>
            </div>
        `);
    }
    
    /**
     * Detect and display image orientation information
     */
    function detectAndDisplayImageOrientation() {
        const $imageContainer = $('#wp2id-preview-image-container');
        const $imageInfo = $('#wp2id-image-info');
        const $img = $imageContainer.find('img').first();
        
        if (!$img.length) {
            $imageInfo.html('<span class="wp2id-image-orientation">No image available</span>');
            return;
        }
        
        // Wait for image to load
        if ($img.prop('complete')) {
            updateImageOrientationInfo($img, $imageContainer, $imageInfo);
        } else {
            $img.on('load', function() {
                updateImageOrientationInfo($img, $imageContainer, $imageInfo);
            });
        }
    }
    
    /**
     * Update image orientation info and apply styling
     */
    function updateImageOrientationInfo($img, $imageContainer, $imageInfo) {
        const width = $img.prop('naturalWidth') || $img.width();
        const height = $img.prop('naturalHeight') || $img.height();
        
        if (width === 0 || height === 0) {
            $imageInfo.html('<span class="wp2id-image-orientation">Unable to determine image dimensions</span>');
            return;
        }
        
        const ratio = width / height;
        let orientation, orientationClass;
        
        if (ratio > 1.1) {
            orientation = 'landscape';
            orientationClass = 'wp2id-image-landscape';
        } else if (ratio < 0.9) {
            orientation = 'portrait';
            orientationClass = 'wp2id-image-portrait';
        } else {
            orientation = 'square';
            orientationClass = 'wp2id-image-square';
        }
        
        // Apply orientation class to image container
        $imageContainer.removeClass('wp2id-image-landscape wp2id-image-portrait wp2id-image-square')
                      .addClass(orientationClass);
        
        // Update info display
        const orientationLabel = getOrientationLabel(orientation);
        $imageInfo.html(`
            <div class="wp2id-image-details">
                <span class="wp2id-image-orientation"><strong>Orientation:</strong> ${orientationLabel}</span>
                <span class="wp2id-image-dimensions"><strong>Dimensions:</strong> ${width} × ${height}px</span>
                <span class="wp2id-image-ratio"><strong>Ratio:</strong> ${ratio.toFixed(2)}</span>
            </div>
        `);
    }
    
    /**
     * Initialize text selection functionality for showing start/end positions
     */
    function initializeTextSelection() {
        // Add selection indicators to content sections and initialize with total stats
        $('.wp2id-content-preview-text').each(function() {
            const $section = $(this).closest('.wp2id-content-preview-section');
            const $textElement = $(this);
            const textContent = $textElement.text();
            const totalChars = textContent.length;
            const totalWords = countWords(textContent);
            
            if ($section.find('.wp2id-selection-indicator').length === 0) {
                const $indicator = $('<div class="wp2id-selection-indicator active"></div>');
                $indicator.html(`
                    <div class="wp2id-selection-range">Total: ${totalWords} words, ${totalChars} characters</div>
                    <div class="wp2id-selection-text">Select text to see range positions</div>
                `);
                $section.append($indicator);
            } else {
                // Update existing indicator
                const $indicator = $section.find('.wp2id-selection-indicator');
                $indicator.addClass('active').html(`
                    <div class="wp2id-selection-range">Total: ${totalWords} words, ${totalChars} characters</div>
                    <div class="wp2id-selection-text">Select text to see range positions</div>
                `);
            }
        });
        
        // Handle text selection events
        $('.wp2id-content-preview-text').off('mouseup keyup').on('mouseup keyup', function() {
            handleTextSelection($(this));
        });
        
        // Note: Removed click-outside handler to keep indicators always visible
    }
    
    /**
     * Handle text selection and show start/end positions
     */
    function handleTextSelection($textElement) {
        const selection = window.getSelection();
        const $indicator = $textElement.closest('.wp2id-content-preview-section').find('.wp2id-selection-indicator');
        const textContent = $textElement.text();
        const totalChars = textContent.length;
        const totalWords = countWords(textContent);
        
        // Always show the indicator with total stats
        $indicator.addClass('active');
        
        if (selection.rangeCount === 0 || selection.isCollapsed) {
            // No selection - show total stats only
            $indicator.html(`
                <div class="wp2id-selection-range">Total: ${totalWords} words, ${totalChars} characters</div>
                <div class="wp2id-selection-text">Select text to see range positions</div>
            `);
            return;
        }
        
        const range = selection.getRangeAt(0);
        
        // Calculate character positions
        let startPos = 0;
        let endPos = 0;
        
        try {
            // Create a range for the entire text element
            const fullRange = document.createRange();
            fullRange.selectNodeContents($textElement[0]);
            
            // Calculate start position
            const startRange = document.createRange();
            startRange.setStart(fullRange.startContainer, fullRange.startOffset);
            startRange.setEnd(range.startContainer, range.startOffset);
            startPos = startRange.toString().length;
            
            // Calculate end position
            const endRange = document.createRange();
            endRange.setStart(fullRange.startContainer, fullRange.startOffset);
            endRange.setEnd(range.endContainer, range.endOffset);
            endPos = endRange.toString().length;
            
        } catch (e) {
            console.warn('Error calculating text positions:', e);
            // Fallback to showing total stats only
            $indicator.html(`
                <div class="wp2id-selection-range">Total: ${totalWords} words, ${totalChars} characters</div>
                <div class="wp2id-selection-text">Error calculating selection positions</div>
            `);
            return;
        }
        
        const selectedText = selection.toString().trim();
        
        if (selectedText.length > 0) {
            const selectedLength = selectedText.length;
            const selectedWords = countWords(selectedText);
            const rangeText = `Selection: ${selectedWords} words, ${selectedLength} chars (pos: ${startPos + 1}-${endPos}) | Total: ${totalWords} words, ${totalChars} chars`;
            const previewText = selectedText.length > 50 
                ? selectedText.substring(0, 50) + '...' 
                : selectedText;
            
            $indicator.html(`
                <div class="wp2id-selection-range">${rangeText}</div>
                <div class="wp2id-selection-text">"${previewText}"</div>
            `);
        } else {
            // Selection exists but no text (shouldn't happen, but just in case)
            $indicator.html(`
                <div class="wp2id-selection-range">Total: ${totalWords} words, ${totalChars} characters</div>
                <div class="wp2id-selection-text">Select text to see range positions</div>
            `);
        }
    }

    /**
     * Add a content position mapping row
     */
    function addContentPosition($contentItem, selectedTag = '', startPos = '', endPos = '', availableTags = []) {
        const $positionList = $contentItem.find('.wp2id-position-list');
        const positionIndex = $positionList.find('.wp2id-position-item').length;
        
        const $positionItem = $(`
            <div class="wp2id-position-item" data-index="${positionIndex}">
                <div class="wp2id-position-item-header">
                    <select class="wp2id-position-tag-select">
                        <option value="">— Select Tag —</option>
                    </select>
                    <button type="button" class="wp2id-remove-position-btn" title="Remove Position">×</button>
                </div>
                <div class="wp2id-position-inputs">
                    <span class="wp2id-position-inputs-label">Position:</span>
                    <input type="number" class="wp2id-position-start" placeholder="Start" min="0" value="${startPos}">
                    <span class="wp2id-position-separator">to</span>
                    <input type="number" class="wp2id-position-end" placeholder="End" min="0" value="${endPos}">
                </div>
            </div>
        `);
        
        const $tagSelect = $positionItem.find('.wp2id-position-tag-select');
        
        // Populate tag options
        if (Array.isArray(availableTags)) {
            availableTags.forEach(tag => {
                // Get details from template details if available
                const tagDetails = templateTagsDetails[tag];
                const characterLimit = tagDetails && tagDetails.length ? tagDetails.length : null;
                const wordCount = tagDetails && tagDetails.word_count ? tagDetails.word_count : null;
                const pageInfo = tagDetails && tagDetails.page_info ? tagDetails.page_info : null;
                
                // Create option text with additional info
                let optionText = tag;
                let additionalInfo = [];
                
                // Add word count and character limit info
                if (wordCount && characterLimit) {
                    additionalInfo.push(`${wordCount} words, ${characterLimit} chars`);
                } else if (wordCount) {
                    additionalInfo.push(`${wordCount} words`);
                } else if (characterLimit) {
                    additionalInfo.push(`${characterLimit} chars`);
                }
                
                if (pageInfo && pageInfo.page_numbers && pageInfo.page_numbers.length > 0) {
                    const pages = pageInfo.page_numbers;
                    if (pages.length > 3) {
                        additionalInfo.push(`pages: ${pages[0]}-${pages[pages.length-1]}`);
                    } else {
                        additionalInfo.push(`page: ${pages.join(', ')}`);
                    }
                }
                
                if (additionalInfo.length > 0) {
                    optionText = `${tag} (${additionalInfo.join(', ')})`;
                }
                
                const $option = $('<option>').val(tag).text(optionText);
                if (selectedTag === tag) {
                    $option.prop('selected', true);
                }
                $tagSelect.append($option);
            });
        }
        
        // Add change event listener for tag selection
        $tagSelect.on('change', function() {
            const selectedTag = $(this).val();
            updateContentMappingStatus($contentItem);
            
            // Auto-fill optimal positions when tag is selected
            if (selectedTag) {
                autoFillOptimalPositions($positionItem, selectedTag);
                checkContentPositionWarning($positionItem, selectedTag);
            } else {
                clearContentPositionWarning($positionItem);
            }
            
            // Update tag availability across all selects
            updateTagSelectsAvailability();
        });
        
        // Add input event listeners for start/end positions with debouncing
        let positionCheckTimeout;
        $positionItem.find('.wp2id-position-start, .wp2id-position-end').on('input', function() {
            updateContentMappingStatus($contentItem);
            validatePositionInputs($positionItem);
            
            // Show real-time content preview
            showContentPreview($positionItem);
            
            // Clear previous timeout
            if (positionCheckTimeout) {
                clearTimeout(positionCheckTimeout);
            }
            
            // Debounced warning check when positions change
            positionCheckTimeout = setTimeout(() => {
                const selectedTag = $tagSelect.val();
                if (selectedTag) {
                    checkContentPositionWarning($positionItem, selectedTag);
                }
            }, 500); // Wait 500ms after user stops typing
        });
        
        // Add blur event listeners for immediate check when user leaves input
        $positionItem.find('.wp2id-position-start, .wp2id-position-end').on('blur', function() {
            const selectedTag = $tagSelect.val();
            if (selectedTag) {
                checkContentPositionWarning($positionItem, selectedTag);
            }
        });
        
        // Add remove button event listener
        $positionItem.find('.wp2id-remove-position-btn').on('click', function() {
            $positionItem.remove();
            updateContentMappingStatus($contentItem);
            
            // Update tag availability after removing position
            updateTagSelectsAvailability();
            
            // If no positions left, add an empty one
            if ($positionList.find('.wp2id-position-item').length === 0) {
                addContentPosition($contentItem, '', '', '', availableTags);
            }
        });
        
        $positionList.append($positionItem);
        updateContentMappingStatus($contentItem);
        
        return $positionItem;
    }
    
    /**
     * Update content mapping status indicator
     */
    function updateContentMappingStatus($contentItem) {
        const $header = $contentItem.find('.wp2id-element-header');
        const $positions = $contentItem.find('.wp2id-position-item');
        
        let hasMappings = false;
        
        $positions.each(function() {
            const tagValue = $(this).find('.wp2id-position-tag-select').val();
            if (tagValue && tagValue !== '') {
                hasMappings = true;
                return false; // Break out of each loop
            }
        });
        
        $header.removeClass('mapped unmapped').addClass(hasMappings ? 'mapped' : 'unmapped');
    }
    
    /**
     * Validate position inputs (ensure end is greater than start, within content bounds)
     */
    function validatePositionInputs($positionItem) {
        const $startInput = $positionItem.find('.wp2id-position-start');
        const $endInput = $positionItem.find('.wp2id-position-end');
        
        const startVal = parseInt($startInput.val());
        const endVal = parseInt($endInput.val());
        
        // Remove any existing error styling
        $startInput.removeClass('error');
        $endInput.removeClass('error');
        $positionItem.find('.wp2id-position-validation-error').remove();
        
        let errorMessage = '';
        
        // Get content length for validation
        const postId = $('#wp2id-position-post-id').val();
        const postPreview = getPostPreviewData(postId);
        const contentLength = postPreview && postPreview.content ? postPreview.content.length : 0;
        console.log(`Validating positions for post ${postId}: start=${startVal}, end=${endVal}, contentLength=${contentLength}`);
        // Validate positions
        if (startVal && startVal < 1) {
            $startInput.addClass('error');
            errorMessage = 'Start position must be 1 or greater';
        } else if (endVal && startVal && endVal <= startVal) {
            $endInput.addClass('error');
            errorMessage = 'End position must be greater than start position';
        } else if (contentLength > 0) {
            if (startVal && startVal > contentLength) {
                $startInput.addClass('error');
                errorMessage = `Start position cannot exceed content length (${contentLength})`;
            } else if (endVal && endVal > contentLength) {
                $endInput.addClass('error');
                errorMessage = `End position cannot exceed content length (${contentLength})`;
            }
        }
        
        // Show error message if any
        if (errorMessage) {
            const $errorDiv = $(`
                <div class="wp2id-position-validation-error">
                    <span class="wp2id-error-icon">⚠</span>
                    <span class="wp2id-error-text">${errorMessage}</span>
                </div>
            `);
            $positionItem.append($errorDiv);
        }
        
        // Update input titles for additional guidance
        if (contentLength > 0) {
            $startInput.attr('title', `Start position (1-${contentLength})`);
            $endInput.attr('title', `End position (${startVal || 1}-${contentLength})`);
        }
    }
    
    /**
     * Get the current post content from the dialog
     */
    /**
     * Handle preview publication action
     */
    function handlePreviewPublication() {
        console.log("=== Preview Publication Function Called ===");
        
        // 1. Validate that posts are selected
        var selectedPosts = getSelectedPosts();
        if (selectedPosts.length === 0) {
            alert('Please select at least one post to preview.');
            return;
        }
        
        // 2. Check that template is assigned
        var templateId = $('#wp2id_template_id').val();
        if (!templateId) {
            alert('Please select a template before previewing.');
            return;
        }
        
        // 3. Show loading indicator
        var $previewBtn = $('#wp2id_preview_publication');
        var originalText = $previewBtn.text();
        $previewBtn.prop('disabled', true).text('Generating Preview...');
        
        // 4. Send AJAX request to generate preview
        $.ajax({
            url: wp2id_publication.ajaxurl,
            type: 'POST',
            data: {
                action: 'wp2id_preview_publication',
                nonce: wp2id_publication.nonce,
                template_id: templateId,
                post_ids: selectedPosts,
                publication_id: $('#post_ID').val()
            },
            success: function(response) {
                $previewBtn.prop('disabled', false).text(originalText);
                
                if (response.success) {
                    // Open preview in new window using the preview URL
                    console.log('Opening preview URL:', response.data.preview_url);
                    var previewWindow = window.open(
                        response.data.preview_url, 
                        'wp2id_preview', 
                        'width=1200,height=800,scrollbars=yes,resizable=yes,menubar=yes,toolbar=yes,location=yes'
                    );
                    
                    if (!previewWindow) {
                        alert('Preview window was blocked by popup blocker. Please allow popups for this site and try again.');
                    }
                } else {
                    alert('Preview failed: ' + (response.data.message || 'Unknown error'));
                }
            },
            error: function(xhr, status, error) {
                $previewBtn.prop('disabled', false).text(originalText);
                console.error('Preview AJAX error:', error);
                alert('Preview failed due to a network error. Please try again.');
            }
        });
        
        console.log("=== Preview Publication Function Completed ===");
    }
    
    /**
     * Get selected post IDs from the form
     */
    function getSelectedPosts() {
        var postIds = [];
        $('input[name="wp2id_publication_posts[]"]').each(function() {
            var postId = parseInt($(this).val());
            if (postId && !isNaN(postId)) {
                postIds.push(postId);
            }
        });
        return postIds;
    }

    /**
     * Handle export publication action
     */
    function handleExportPublication(e) {
        if (e) e.preventDefault();
        console.log("=== Export Publication Function Called ===");
        
        // Get publication ID
        const publicationId = wp2id_publication.postId;
        
        if (!publicationId) {
            alert('Error: Cannot determine publication ID');
            return;
        }
        
        // Show loading indicator
        const $exportButton = $('#wp2id_export_publication');
        const originalButtonText = $exportButton.html();
        $exportButton.html('<span class="dashicons dashicons-update-alt spinning"></span> Exporting...');
        $exportButton.prop('disabled', true);
        
        // Call AJAX to generate IDML export
        $.ajax({
            url: wp2id_publication.ajaxurl,
            type: 'POST',
            data: {
                action: 'wp2id_export_idml',
                nonce: wp2id_publication.nonce,
                publication_id: publicationId
            },
            success: function(response) {
                if (response.success && response.data.download_url) {
                    // Create success message with download link instead of using jQuery UI dialog
                    const $successMessage = $('<div class="notice notice-success wp2id-export-success" style="padding: 10px 15px; margin-top: 15px;">' +
                        '<p><strong>IDML Export Complete!</strong> Your IDML export has been successfully generated!</p>' +
                        '<p><a href="' + response.data.download_url + '" class="button button-primary" target="_blank">Download IDML Package</a></p>' +
                    '</div>');
                    
                    // Show message at the top of the page
                    $('.wrap > h1').after($successMessage);
                    
                    // Scroll to the success message
                    $('html, body').animate({
                        scrollTop: $successMessage.offset().top - 50
                    }, 500);
                    
                    // Auto-remove after 60 seconds
                    setTimeout(function() {
                        $successMessage.fadeOut(500, function() {
                            $(this).remove();
                        });
                    }, 60000);
                } else {
                    alert('Error exporting publication: ' + (response.data ? response.data.message : 'Unknown error'));
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', error);
                alert('An error occurred during export. Please check the console for details.');
            },
            complete: function() {
                // Restore button state
                $exportButton.html(originalButtonText);
                $exportButton.prop('disabled', false);
            }
        });
        
        console.log("=== Export Publication Function Initiated ===");
    }

    /**
     * Get selected post IDs from checkboxes
     */
    function getSelectedPostsFromCheckboxes() {
        var postIds = [];
        $('.wp2id-post-check:checked').each(function() {
            var postId = parseInt($(this).val());
            if (postId && !isNaN(postId)) {
                postIds.push(postId);
            }
        });
        return postIds;
    }
    
    /**
     * Add bulk actions functionality
     */
    function initBulkActions() {
        // Add bulk actions dropdown if it doesn't exist
        if ($('#wp2id-bulk-actions').length === 0) {
            var bulkActionsHtml = `
                <div class="wp2id-bulk-actions" style="margin: 10px 0;">
                    <select id="wp2id-bulk-actions">
                        <option value="">Bulk Actions</option>
                        <option value="remove">Remove Selected</option>
                    </select>
                    <button type="button" class="button" id="wp2id-apply-bulk-action">Apply</button>
                    <span id="wp2id-selected-count" style="margin-left: 10px; color: #666;"></span>
                </div>
            `;
            $('.wp2id-table-container').before(bulkActionsHtml);
        }
        
        // Update selected count
        $(document).on('change', '.wp2id-post-check, #wp2id-select-all-posts', function() {
            var selectedCount = $('.wp2id-post-check:checked').length;
            $('#wp2id-selected-count').text(selectedCount > 0 ? `${selectedCount} item(s) selected` : '');
        });
        
        // Handle bulk actions
        $('#wp2id-apply-bulk-action').on('click', function() {
            var action = $('#wp2id-bulk-actions').val();
            var selectedPosts = getSelectedPostsFromCheckboxes();
            
            if (!action) {
                alert('Please select a bulk action.');
               
                return;
            }
            
            if (selectedPosts.length === 0) {
                alert('Please select at least one post.');
                return;
            }
            
            switch (action) {
                case 'remove':
                    if (confirm(`Are you sure you want to remove ${selectedPosts.length} selected post(s)?`)) {
                        selectedPosts.forEach(function(postId) {
                            removeSelectedPost(postId);
                        });
                        $('#wp2id-bulk-actions').val('');
                    }
                    break;
            }
        });
    }

    // Initialize the position dialog functionality
    initPositionDialog();

    // Initialize central mappings from server
    initializeCentralMappingsToUI();

    // Initialize bulk actions
    initBulkActions();

    // Initialize tag mapping styles
    initializeTagMappingStyles();

    /**
     * Check for content warning for standard elements (title, excerpt, etc.)
     */
    function checkContentWarning(element, selectedTag, $item) {
        const postId = $('#wp2id-position-post-id').val();
        debugger
        if (!postId || !selectedTag) return;

        // Get post preview data
        const postPreview = getPostPreviewData(postId);
        if (!postPreview) return;

        // Get content for the specific element
        let content = '';
        switch(element) {
            case 'title':
                content = postPreview.title || '';
                break;
            case 'excerpt':
                content = postPreview.excerpt || '';
                break;
            case 'author':
                content = postPreview.author || '';
                break;
            case 'date':
                content = postPreview.date || '';
                break;
            case 'category':
                content = postPreview.categories ? postPreview.categories.join(', ') : '';
                break;
            default:
                content = '';
        }

        // Check limits
        const wordCount = countWords(content);
        const characterCount = content.length;
        const tagDetails = templateTagsDetails[selectedTag];
        const characterLimit = tagDetails && tagDetails.length ? parseInt(tagDetails.length) : null;
        const wordLimit = tagDetails && tagDetails.word_count ? parseInt(tagDetails.word_count) : null;

        let hasWarning = false;
        let warnings = [];

        if (characterLimit && characterCount > characterLimit) {
            warnings.push(`${characterCount}/${characterLimit} chars`);
            hasWarning = true;
        }

        if (wordLimit && wordCount > wordLimit) {
            warnings.push(`${wordCount}/${wordLimit} words`);
            hasWarning = true;
        }

        if (hasWarning) {
            const warningText = `Exceeds limit: ${warnings.join(', ')}`;
            showContentWarning($item, wordCount, characterCount, characterLimit, ` - ${warningText}`);
        } else {
            clearContentWarning($item);
        }
    }

    /**
     * Check for content warning for content positions
     */
    function checkContentPositionWarning($positionItem, selectedTag) {
        const postId = $('#wp2id-position-post-id').val();
        if (!postId || !selectedTag) {
            clearContentPositionWarning($positionItem);
            return;
        }

        // Get tag details and limits
        const tagDetails = templateTagsDetails[selectedTag];
        const characterLimit = tagDetails && tagDetails.length ? parseInt(tagDetails.length) : null;
        const wordLimit = tagDetails && tagDetails.word_count ? parseInt(tagDetails.word_count) : null;
        
        if (!characterLimit && !wordLimit) {
            clearContentPositionWarning($positionItem);
            return;

        }

        // Get post preview data
        const postPreview = getPostPreviewData(postId);
        if (!postPreview || !postPreview.content) {
            clearContentPositionWarning($positionItem);
            return;
        }

        // Get start and end positions with validation (0-based indexing)
        const startInput = $positionItem.find('.wp2id-position-start');
        const endInput = $positionItem.find('.wp2id-position-end');
        
        let startPos = parseInt(startInput.val()) || 0;
        let endPos = parseInt(endInput.val()) || postPreview.content.length;
        
        // Validate positions
        const contentLength = postPreview.content.length;
        
        // Ensure positions are within bounds (0-based)
        startPos = Math.max(0, Math.min(startPos, contentLength));
        endPos = Math.max(startPos, Math.min(endPos, contentLength));
        
        // Update input values if they were corrected
        if (parseInt(startInput.val()) !== startPos) {
            startInput.val(startPos);
        }
        if (parseInt(endInput.val()) !== endPos) {
            endInput.val(endPos);
        }

        // Extract content portion (using 0-based indexing directly)
        const contentPortion = postPreview.content.substring(startPos, endPos);
        
        // Check both word count and character count vs limits
        const wordCount = countWords(contentPortion);
        const characterCount = contentPortion.length;

        let hasWarning = false;
        let warnings = [];

        if (characterLimit && characterCount > characterLimit) {
            warnings.push(`${characterCount}/${characterLimit} chars`);
            hasWarning = true;
        }

        if (wordLimit && wordCount > wordLimit) {
            warnings.push(`${wordCount}/${wordLimit} words`);
            hasWarning = true;
        }

        if (hasWarning) {
            showContentPositionWarning($positionItem, wordCount, characterCount, characterLimit, startPos, endPos, warnings);
        } else {
            clearContentPositionWarning($positionItem);
        }
    }

    /**
     * Show content warning for standard elements
     */
    function showContentWarning($item, wordCount, characterCount, characterLimit = null, extraInfo = '') {
        // Remove existing warning
        $item.find('.wp2id-warning').remove();

        // Create warning text
        let warningText;
        if (extraInfo.includes('Exceeds limit:')) {
            warningText = `Content ${extraInfo}`;
        } else {
            warningText = `Content: ${wordCount} words, ${characterCount} chars`;
            if (characterLimit) {
                warningText += ` (limit: ${characterLimit})`;
            }
            warningText += extraInfo;
        }

        // Add warning indicator
        const $warning = $(`
            <div class="wp2id-warning">
                <span class="wp2id-warning-icon">⚠</span>
                <span class="wp2id-warning-text">${warningText}</span>
            </div>
        `);
        
        $item.find('.wp2id-control-group').append($warning);
        $item.find('.wp2id-element-header').addClass('has-warning');
    }

    /**
     * Show content warning for content positions
     */
    function showContentPositionWarning($positionItem, wordCount, characterCount, characterLimit = null, startPos = null, endPos = null, warnings = null) {
        // Remove existing warning
        $positionItem.find('.wp2id-position-warning').remove();

        // Create warning text
        let warningText;
        if (warnings && warnings.length > 0) {
            warningText = `Exceeds limit: ${warnings.join(', ')}`;
        } else if (characterLimit) {
            warningText = `${characterCount}/${characterLimit} chars (${wordCount} words)`;
        } else {
            warningText = `${wordCount} words, ${characterCount} chars`;
        }
        
        if (startPos && endPos) {
            warningText += ` [pos: ${startPos}-${endPos}]`;
        }

        // Add warning indicator
        const $warning = $(`
            <div class="wp2id-position-warning">
                <span class="wp2id-warning-icon">⚠</span>
                <span class="wp2id-warning-text">${warningText}</span>
            </div>
        `);
        
        $positionItem.append($warning);
        $positionItem.addClass('has-warning');
    }

    /**
     * Clear content warning for standard elements
     */
    function clearContentWarning($item) {
        $item.find('.wp2id-warning').remove();
        $item.find('.wp2id-element-header').removeClass('has-warning');
    }

    /**
     * Clear content warning for content positions
     */
    function clearContentPositionWarning($positionItem) {
        $positionItem.find('.wp2id-position-warning').remove();
        $positionItem.removeClass('has-warning');
    }

    /**
     * Count words in text content
     */
    function countWords(text) {
        if (!text) return 0;
        // Remove HTML tags and extra whitespace, then count words
        const cleanText = text.replace(/<[^>]*>/g, '').trim();
        if (cleanText === '') return 0;
        return cleanText.split(/\s+/).length;
    }

    /**
     * Auto-calculate optimal start/end positions for content mapping
     * Prioritizes word boundaries to avoid cutting words
     */
    function autoCalculateOptimalPositions(content, characterLimit, wordLimit = null) {
        if (!content || !characterLimit) {
            return { start: 0, end: content ? content.length : 0 };
        }

        const contentLength = content.length;
        
        // If content fits within limits, use full content (start always 0)
        if (contentLength <= characterLimit) {
            return { start: 0, end: contentLength };
        }

        // Find optimal end position that doesn't cut words
        let optimalEnd = characterLimit;
        
        // Look backwards from character limit to find word boundary
        for (let i = characterLimit; i > 0; i--) {
            const char = content.charAt(i - 1);
            const nextChar = content.charAt(i);
            
            // Check if this is a good breaking point (end of word)
            if (char.match(/\s/) || // Current char is whitespace
                nextChar.match(/\s/) || // Next char is whitespace
                char.match(/[.!?]/) || // Current char is sentence ending
                i === contentLength) { // End of content
                optimalEnd = i;
                break;
            }
        }

        // If we couldn't find a good break point in reasonable distance, use character limit
        if (characterLimit - optimalEnd > characterLimit * 0.1) { // More than 10% lost
            optimalEnd = characterLimit;
        }

        // Double-check against word limit if provided
        if (wordLimit) {
            const contentPortion = content.substring(0, optimalEnd);
            const wordCount = countWords(contentPortion);
            
            if (wordCount > wordLimit) {
                // Try to find position that fits word limit
                const words = content.replace(/<[^>]*>/g, '').split(/\s+/);
                let wordBasedContent = words.slice(0, wordLimit).join(' ');
                
                // Find this content in original text (accounting for HTML tags)
                let searchEnd = contentLength;
                for (let i = 0; i < contentLength; i++) {
                    const portionText = content.substring(0, i + 1).replace(/<[^>]*>/g, '');
                    if (portionText.trim() === wordBasedContent.trim()) {
                        searchEnd = i + 1;
                        break;
                    }
                }
                
                // Use the smaller of character-based or word-based end
                optimalEnd = Math.min(optimalEnd, searchEnd);
            }
        }

        // Start position is always 0 for all content positions
        return { start: 0, end: Math.max(0, optimalEnd) };
    }

    /**
     * Auto-fill optimal positions when tag is selected
     */
    function autoFillOptimalPositions($positionItem, selectedTag) {
        const postId = $('#wp2id-position-post-id').val();
        if (!postId || !selectedTag) {
            return;
        }

        // Get tag limits
        const tagDetails = templateTagsDetails[selectedTag];
        const characterLimit = tagDetails && tagDetails.length ? parseInt(tagDetails.length) : null;
        const wordLimit = tagDetails && tagDetails.word_count ? parseInt(tagDetails.word_count) : null;

        if (!characterLimit && !wordLimit) {
            return; // No limits to work with
        }

        // Get post content
        const postPreview = getPostPreviewData(postId);
        if (!postPreview || !postPreview.content) {
            return;
        }

        // Calculate optimal positions
        const optimal = autoCalculateOptimalPositions(
            postPreview.content, 
            characterLimit, 
            wordLimit
        );

        // Fill the input fields
        const $startInput = $positionItem.find('.wp2id-position-start');
        const $endInput = $positionItem.find('.wp2id-position-end');

        // Only auto-fill if fields are empty or have default values
        // Start position is always 0, so always set it
        $startInput.val(optimal.start);
        
        if (!$endInput.val() || $endInput.val() === postPreview.content.length.toString()) {
            $endInput.val(optimal.end);
        }

        // Show preview of the calculated content
        showContentPreview($positionItem);
        
        // Check for warnings with new positions
        checkContentPositionWarning($positionItem, selectedTag);

        // Log the calculation for debugging
        console.log(`Auto-calculated positions for tag "${selectedTag}" (start always 0):`, {
            characterLimit,
            wordLimit,
            contentLength: postPreview.content.length,
            calculatedStart: optimal.start, // Always 0
            calculatedEnd: optimal.end,
            resultingLength: optimal.end - optimal.start
        });
    }

    /**
     * Check if a mapping has content warning
     */
    function checkMappingWarning(postId, element, tagName, position = null) {
        if (!tagName || !templateTagsDetails[tagName]) return false;
        
        const tagDetails = templateTagsDetails[tagName];
        const characterLimit = tagDetails.length ? parseInt(tagDetails.length) : null;
        const wordLimit = tagDetails.word_count ? parseInt(tagDetails.word_count) : null;
        
        if (!characterLimit && !wordLimit) return false;
        
        // Get post data from the row
        const $row = $('#post-' + postId);
        let content = '';
        
        switch(element) {
            case 'title':
                content = $row.find('.wp2id-post-title').text() || '';
                break;
            case 'content':
                content = $row.data('content') || $row.find('.wp2id-post-excerpt').text() || '';
                if (position && position.start && position.end) {
                    const startPos = parseInt(position.start) || 1;
                    const endPos = parseInt(position.end) || content.length;
                    content = content.substring(startPos - 1, endPos);
                }
                break;
            case 'excerpt':
                content = $row.data('excerpt') || '';
                break;
            case 'author':
                content = $row.data('author') || '';
                break;
            case 'date':
                content = $row.data('date') || '';
                break;
            case 'category':
                content = $row.data('categories') ? $row.data('categories').join(', ') : '';
                break;
            default:
                return false;
        }
        
        const characterCount = content.length;
        const wordCount = countWords(content);
        
        return (characterLimit && characterCount > characterLimit) || 
               (wordLimit && wordCount > wordLimit);
    }

    /**
     * Show real-time content preview for position selection
     */
    function showContentPreview($positionItem) {
        const postId = $('#wp2id-position-post-id').val();
        const postPreview = getPostPreviewData(postId);
        
        if (!postPreview || !postPreview.content) {
            return;
        }
        
        const startPos = parseInt($positionItem.find('.wp2id-position-start').val()) || 0;
        const endPos = parseInt($positionItem.find('.wp2id-position-end').val()) || postPreview.content.length;
        
        // Validate and adjust positions (0-based indexing)
        const contentLength = postPreview.content.length;
        const validStart = Math.max(0, Math.min(startPos, contentLength));
        const validEnd = Math.max(validStart, Math.min(endPos, contentLength));
        
        // Extract preview content using 0-based indexing
        const selectedContent = postPreview.content.substring(validStart, validEnd);
        const previewContent = selectedContent.length > 100 
            ? selectedContent.substring(0, 100) + '...' 
            : selectedContent;
        
        const wordCount = countWords(selectedContent);
        
        // Remove existing preview
        $positionItem.find('.wp2id-content-preview').remove();
        
        // Add content preview with enhanced vertical layout
        const $preview = $(`
            <div class="wp2id-content-preview">
                <div class="wp2id-preview-stats">
                    <div class="wp2id-preview-words">${wordCount} words</div>
                    <div class="wp2id-preview-chars">${selectedContent.length} chars</div>
                    <div class="wp2id-preview-range">Range: ${validStart} - ${validEnd}</div>
                </div>
                <div class="wp2id-preview-text" title="${selectedContent}">
                    ${previewContent}
                </div>
            </div>
        `);
        
        $positionItem.append($preview);
    }

    /**
     * Check warnings for existing mappings after all data is loaded
     */
    function checkExistingMappingWarnings() {
        console.log("Checking existing mapping warnings...");
        
        // Check standard element mappings
        $('#wp2id-tag-mapping-list .wp2id-mapping-item:not([data-element="content"])').each(function() {
            const $item = $(this);
            const element = $item.data('element');
            const selectedTag = $item.find('.wp2id-tag-select').val();
            
            if (selectedTag) {
                checkContentWarning(element, selectedTag, $item);
            }
        });
        
        // Check content position mappings
        $('#wp2id-tag-mapping-list .wp2id-mapping-item[data-element="content"] .wp2id-position-item').each(function() {
            const $positionItem = $(this);
            const selectedTag = $positionItem.find('.wp2id-position-tag-select').val();
            
            if (selectedTag) {
                checkContentPositionWarning($positionItem, selectedTag);
            }
        });
        
        console.log("Existing mapping warnings check completed");
    }

    /**
     * Get post preview data (from right panel or stored data)
     */
    function getPostPreviewData(postId) {
        // Try to get from stored data first
        if (postPreviewData && postPreviewData[postId]) {
            return postPreviewData[postId];
        }   
        return null;
    }

    /**
     * Show tag details in a tooltip or info panel
     */
    function showTagDetails(tagName, $element) {
        if (!tagName || !templateTagsDetails[tagName]) return;
        
        const tagDetails = templateTagsDetails[tagName];
        let detailsHtml = '<div class="wp2id-tag-details-tooltip">';
        detailsHtml += `<h4>${tagName}</h4>`;
        detailsHtml += '<ul>';
        
        if (tagDetails.type) {
            detailsHtml += `<li><strong>Type:</strong> ${tagDetails.type}</li>`;
        }
        
        if (tagDetails.length) {
            detailsHtml += `<li><strong>Character limit:</strong> ${tagDetails.length}</li>`;
        }
        
        if (tagDetails.word_count) {
            detailsHtml += `<li><strong>Template word count:</strong> ${tagDetails.word_count}</li>`;
        }
        
        if (tagDetails.page_info && tagDetails.page_info.page_numbers && tagDetails.page_info.page_numbers.length > 0) {
            const pages = tagDetails.page_info.page_numbers;
            let pageText = pages.length > 3 ? `${pages[0]}-${pages[pages.length - 1]}` : pages.join(', ');
            detailsHtml += `<li><strong>Page(s):</strong> ${pageText}</li>`;
        }
        
        if (tagDetails.source_story) {
            detailsHtml += `<li><strong>Source story:</strong> ${tagDetails.source_story}</li>`;
        }
        
        detailsHtml += '</ul></div>';
        
        // Add tooltip functionality (simple implementation)
        $element.attr('title', '').tooltip('destroy');
        $element.attr('data-tag-details', detailsHtml);
        
        // You could implement a more sophisticated tooltip system here
        console.log('Tag details for', tagName, tagDetails);
    }

    /**
     * Get orientation label for display
     */
    function getOrientationLabel(orientation) {
        switch(orientation) {
            case 'landscape':
                return 'Ngang (Landscape)';
            case 'portrait':
                return 'Dọc (Portrait)';
            case 'square':
                return 'Vuông (Square)';
            default:
                return 'Không xác định';
        }
    }

    /**
     * Detect image orientation from thumbnail element
     */
    function detectImageOrientation($imageElement) {
        if (!$imageElement || !$imageElement.length) {
            return 'unknown';
        }

        const img = $imageElement.find('img').first();
        if (!img.length) {
            return 'unknown';
        }

        const width = img.prop('naturalWidth') || img.width();
        const height = img.prop('naturalHeight') || img.height();

        if (width === 0 || height === 0) {
            return 'unknown';
        }

        const ratio = width / height;
        
        if (ratio > 1.1) {
            return 'landscape';
        } else if (ratio < 0.9) {
            return 'portrait';
        } else {
            return 'square';
        }
    }

    /**
     * Update page number in the selected posts data
     */
    function updatePageNumberInData(postId, pageNumber) {
        // Update the hidden input value
        var hiddenInput = $('#wp2id_selected_posts input[name="wp2id_page_numbers[' + postId + ']"]');
        if (hiddenInput.length > 0) {
            hiddenInput.val(pageNumber);
        }
        
        // Update page info display if the dialog is open for this post
        const dialogPostId = $('#wp2id-position-post-id').val();
        if (dialogPostId == postId && $('.wp2id-position-dialog').is(':visible')) {
            updatePageInfoDisplay(postId);
        }
    }

    /**
     * Update page information display in mapping dialog
     */
    function updatePageInfoDisplay(postId) {
        const $pageInfoDisplay = $('#wp2id-page-info-display');
        const $pageInfoValue = $('#wp2id-page-info-value');
        
        // Get page number from the selected posts table
        const $postRow = $('#post-' + postId);
        if ($postRow.length > 0) {
            const pageNumber = $postRow.find('.post-page-number').text().trim();
            
            // Always show the display when dialog is opened
            $pageInfoDisplay.show();
            
            if (pageNumber && pageNumber !== '') {
                $pageInfoValue.text(pageNumber);
                $pageInfoDisplay.addClass('has-page');
            } else {
                $pageInfoValue.text('');
                $pageInfoDisplay.removeClass('has-page');
            }
        } else {
            // Hide if post not found
            $pageInfoDisplay.hide();
        }
    }

    /**
     * Get all currently mapped tags from the dialog to prevent duplicate assignments
     */
    function getCurrentlyMappedTags() {
        const mappedTags = new Set();
        
        // Add global used tags from other posts first
        if (globalUsedTags && Array.isArray(globalUsedTags)) {
            globalUsedTags.forEach(tag => {
                if (tag && tag !== '') {
                    mappedTags.add(tag);
                }
            });
        }
        
        // Collect tags from current post's standard single-select elements
        $('#wp2id-tag-mapping-list .wp2id-tag-select').each(function() {
            const tagName = $(this).val();
            if (tagName && tagName !== '') {
                // Remove from set first (to allow current post's selections)
                mappedTags.delete(tagName);
            }
        });
        
        // Collect tags from current post's content position elements  
        $('#wp2id-tag-mapping-list .wp2id-position-tag-select').each(function() {
            const tagName = $(this).val();
            if (tagName && tagName !== '') {
                // Remove from set first (to allow current post's selections)
                mappedTags.delete(tagName);
            }
        });
        
        // Now add back currently selected tags from this dialog
        $('#wp2id-tag-mapping-list .wp2id-tag-select').each(function() {
            const tagName = $(this).val();
            if (tagName && tagName !== '') {
                mappedTags.add(tagName);
            }
        });
        
        $('#wp2id-tag-mapping-list .wp2id-position-tag-select').each(function() {
            const tagName = $(this).val();
            if (tagName && tagName !== '') {
                mappedTags.add(tagName);
            }
        });
        
        return Array.from(mappedTags);
    }

    /**
     * Get currently mapped tags in this dialog only (not including global used tags)
     */
    function getCurrentPostMappedTags() {
        const mappedTags = new Set();
        
        // Collect tags from current dialog's standard single-select elements
        $('#wp2id-tag-mapping-list .wp2id-tag-select').each(function() {
            const tagName = $(this).val();
            if (tagName && tagName !== '') {
                mappedTags.add(tagName);
            }
        });
        
        // Collect tags from current dialog's content position elements
        $('#wp2id-tag-mapping-list .wp2id-position-tag-select').each(function() {
            const tagName = $(this).val();
            if (tagName && tagName !== '') {
                mappedTags.add(tagName);
            }
        });
        
        return Array.from(mappedTags);
    }

    /**
     * Update all tag selects to reflect current mapping state
     */
    function updateTagSelectsAvailability() {
        const currentPostMappedTags = getCurrentPostMappedTags();
        const globallyUsedTags = globalUsedTags || [];
        
        // Update standard tag selects
        $('#wp2id-tag-mapping-list .wp2id-tag-select').each(function() {
            const $select = $(this);
            const currentValue = $select.val();
            
            $select.find('option').each(function() {
                const $option = $(this);
                const tagValue = $option.val();
                
                // Store original text if not already stored
                if (!$option.data('original-text')) {
                    $option.data('original-text', $option.text());
                }
                
                const originalText = $option.data('original-text');
                
                if (tagValue === '' || tagValue === currentValue) {
                    // Always allow empty option and currently selected option
                    $option.prop('disabled', false).removeClass('wp2id-assigned-tag');
                    $option.text(originalText);
                } else if (currentPostMappedTags.includes(tagValue)) {
                    // Priority: if already mapped in current dialog, show as "assigned"
                    $option.prop('disabled', true).addClass('wp2id-assigned-tag');
                    $option.text(originalText + ' (đã gán)');
                } else if (globallyUsedTags.includes(tagValue)) {
                    // Show as "used" only if not already assigned in current dialog
                    $option.prop('disabled', true).addClass('wp2id-assigned-tag');
                    $option.text(originalText + ' (đã sử dụng)');
                } else {
                    // Enable available tags and restore original text
                    $option.prop('disabled', false).removeClass('wp2id-assigned-tag');
                    $option.text(originalText);
                }
            });
        });
        
        // Update content position tag selects
        $('#wp2id-tag-mapping-list .wp2id-position-tag-select').each(function() {
            const $select = $(this);
            const currentValue = $select.val();
            
            $select.find('option').each(function() {
                const $option = $(this);
                const tagValue = $option.val();
                
                // Store original text if not already stored
                if (!$option.data('original-text')) {
                    $option.data('original-text', $option.text());
                }
                
                const originalText = $option.data('original-text');
                
                if (tagValue === '' || tagValue === currentValue) {
                    // Always allow empty option and currently selected option
                    $option.prop('disabled', false).removeClass('wp2id-assigned-tag');
                    $option.text(originalText);
                } else if (currentPostMappedTags.includes(tagValue)) {
                    // Priority: if already mapped in current dialog, show as "assigned"
                    $option.prop('disabled', true).addClass('wp2id-assigned-tag');
                    $option.text(originalText + ' (đã gán)');
                } else if (globallyUsedTags.includes(tagValue)) {
                    // Show as "used" only if not already assigned in current dialog
                    $option.prop('disabled', true).addClass('wp2id-assigned-tag');
                    $option.text(originalText + ' (đã sử dụng)');
                } else {
                    // Enable available tags and restore original text
                    $option.prop('disabled', false).removeClass('wp2id-assigned-tag');
                    $option.text(originalText);
                }
            });
        });
    }

    /**
     * Initialize tag mapping styles for disabled/assigned tags
     */
    function initializeTagMappingStyles() {
        // Check if styles are already added
        if ($('#wp2id-tag-mapping-styles').length > 0) {
            return;
        }
        
        // Add CSS styles for disabled/assigned tags
        const styles = `
            <style id="wp2id-tag-mapping-styles">
                /* Styles for assigned/disabled tags */
                .wp2id-tag-select option.wp2id-assigned-tag,
                .wp2id-position-tag-select option.wp2id-assigned-tag {
                    background-color: #f0f0f0 !important;
                    color: #999 !important;
                    font-style: italic;
                }
                
                .wp2id-tag-select option.wp2id-assigned-tag:disabled,
                .wp2id-position-tag-select option.wp2id-assigned-tag:disabled {
                    background-color: #e8e8e8 !important;
                    color: #777 !important;
                }
                
                /* Additional visual indicators */
                .wp2id-tag-select:focus option.wp2id-assigned-tag,
                .wp2id-position-tag-select:focus option.wp2id-assigned-tag {
                    background-color: #f5f5f5 !important;
                }
            </style>
        `;
        
        $('head').append(styles);
    }

    /**
     * Initialize upload mode switching based on values instead of radio buttons
     */
    function initUploadModeSwitching() {
        // Handle template select changes
        $('#wp2id_template_id').on('change', function() {
            var templateId = $(this).val();
            updateUploadMode();
        });
        
        // Initialize state on page load
        updateUploadMode();
    }

    /**
     * Update upload mode and disable/enable sections based on values
     */
    function updateUploadMode() {
        var templateId = $('#wp2id_template_id').val();
        var idmlFileId = $('#wp2id_direct_idml_file').val();
        var hasTemplate = templateId && templateId !== '';
        var hasIdmlFile = idmlFileId && idmlFileId !== '' && idmlFileId !== '0';
        
        var $templateSection = $('#wp2id_template_id').closest('.wp2id-section');
        var $idmlSection = $('#upload-direct-idml').closest('.wp2id-section');
        
        if (hasTemplate) {
            // Template selected - disable IDML upload
            $idmlSection.addClass('disabled');
            $('#wp2id_upload_mode').val('template');
        } else if (hasIdmlFile) {
            // IDML file uploaded - disable template select
            $templateSection.addClass('disabled');
            $('#wp2id_upload_mode').val('direct_idml');
            // Show tags button if tags exist
            var hasDirectTags = $('#tags-dialog-content table').length > 0;
            if (hasDirectTags) {
                $('#show-tags-dialog').show();
            }
        } else {
            // Neither selected - enable both
            $templateSection.removeClass('disabled');
            $idmlSection.removeClass('disabled');
            $('#wp2id_upload_mode').val('template'); // Default
            $('#show-tags-dialog').hide();
        }
    }

    /**
     * Initialize direct IDML upload functionality
     */
    function initDirectIdmlUpload() {
        // Ensure WordPress media library is available
        if (typeof wp === 'undefined' || typeof wp.media === 'undefined') {
            console.error('WordPress media library not available');
            return;
        }

        // Upload button click handler
        $('#upload-direct-idml').on('click', function(e) {
            e.preventDefault();
            handleDirectIdmlUpload();
        });

        // Remove button click handler
        $('#remove-direct-idml').on('click', function(e) {
            e.preventDefault();
            removeDirectIdmlFile();
        });

        // Form submit handler to preserve file state
        $('form#post').on('submit', function() {
            var fileId = $('#wp2id_direct_idml_file').val();
            var currentMode = $('#wp2id_upload_mode').val();
            
            // If in direct IDML mode and no explicit removal flag, preserve the file
            if (currentMode === 'direct_idml' && fileId && !$('#wp2id_remove_idml_file').length) {
                // Ensure file ID is preserved
                if (!fileId || fileId === '0' || fileId === '') {
                    // Try to get the file ID from the display text if available
                    var displayedFile = $('#idml-filename').text();
                    if (displayedFile && $('#selected-idml-info').is(':visible')) {
                        // Set preserve flag to prevent accidental deletion
                        $('#wp2id_direct_idml_file').val('preserve');
                    }
                }
            }
        });
    }

    /**
     * Handle direct IDML file upload via WordPress Media Library
     */
    function handleDirectIdmlUpload() {
        var frame = wp.media({
            title: 'Select IDML File',
            library: { 
                type: 'application/octet-stream'
            },
            multiple: false
        });

        frame.on('select', function() {
            var attachment = frame.state().get('selection').first().toJSON();
            
            // Validate file extension
            if (!validateIdmlFile(attachment)) {
                alert('Please select a valid IDML file.');
                return;
            }

            // Remove any existing removal flag
            $('#wp2id_remove_idml_file').remove();

            // Update UI with selected file
            $('#idml-filename').text(attachment.filename);
            $('#wp2id_direct_idml_file').val(attachment.id);
            $('#selected-idml-info').show();
            
            // Update upload mode based on new file
            updateUploadMode();

            // Show processing dialog
            showTagExtractionDialog();

            // Start tag extraction via AJAX
            var publicationId = wp2id_publication_admin.postId || $('#post_ID').val();
            extractTagsFromDirectIdml(publicationId, attachment.id);
        });

        frame.open();
    }

    /**
     * Remove direct IDML file
     */
    function removeDirectIdmlFile() {
        // Set explicit removal flag and clear file ID
        $('#wp2id_direct_idml_file').val('');
        $('#selected-idml-info').hide();
        $('#show-tags-dialog').hide();
        $('#tags-dialog-content').empty();
        
        // Update upload mode after removal
        updateUploadMode();
        
        // Add hidden field to indicate intentional removal
        if ($('#wp2id_remove_idml_file').length === 0) {
            $('<input type="hidden" name="wp2id_remove_idml_file" id="wp2id_remove_idml_file" value="1">').appendTo('#wp2id-publication-metabox');
        }
    }

    /**
     * Validate IDML file
     */
    function validateIdmlFile(attachment) {
        if (!attachment.filename) {
            return false;
        }
        
        var extension = attachment.filename.split('.').pop().toLowerCase();
        return extension === 'idml';
    }

    /**
     * Show tag extraction dialog
     */
    function showTagExtractionDialog() {
        var dialogHtml = 
            '<div id="tag-extraction-dialog" title="Processing IDML File">' +
            '<div class="extraction-progress">' +
            '<div class="wp2id-spinner">' +
            '<div class="spinner is-active"></div>' +
            '</div>' +
            '<p id="extraction-status">Analyzing IDML file structure...</p>' +
            '<div class="progress-container">' +
            '<div class="progress-bar">' +
            '<div class="progress-fill" style="width: 0%"></div>' +
            '</div>' +
            '<span class="progress-text">0%</span>' +
            '</div>' +
            '</div>' +
            '</div>';

        $('body').append(dialogHtml);

        $('#tag-extraction-dialog').dialog({
            modal: true,
            resizable: false,
            width: 450,
            height: 250,
            closeOnEscape: false,
            open: function() {
                $('.ui-dialog-titlebar-close').hide(); // Hide close button
            }
        });
    }

    /**
     * Extract tags from direct IDML file via AJAX
     */
    function extractTagsFromDirectIdml(publicationId, fileId) {
        // Simulate progress updates for better UX
        updateExtractionProgress(20, 'Extracting IDML structure...');

        setTimeout(function() {
            updateExtractionProgress(50, 'Analyzing XML tags...');
        }, 1000);

        setTimeout(function() {
            updateExtractionProgress(80, 'Processing tag details...');
        }, 2000);

        // Actual AJAX call
        $.ajax({
            url: wp2id_publication_admin.ajaxurl,
            type: 'POST',
            data: {
                action: 'wp2id_extract_direct_idml_tags',
                nonce: wp2id_publication_admin.nonce,
                publication_id: publicationId,
                idml_file_id: fileId
            },
            success: function(response) {
                if (response.success) {
                    updateExtractionProgress(100, 'Extraction completed!');

                    setTimeout(function() {
                        hideTagExtractionDialog();
                        displayExtractedTags(response.data.detailed_tags);
                        
                        // Show success message
                        showNotice('success', response.data.message + ' (' + response.data.tags_count + ' tags found)');
                    }, 500);
                } else {
                    hideTagExtractionDialog();
                    showNotice('error', 'Error: ' + response.data.message);
                }
            },
            error: function() {
                hideTagExtractionDialog();
                showNotice('error', 'Failed to extract tags. Please try again.');
            }
        });
    }

    /**
     * Update extraction progress
     */
    function updateExtractionProgress(percent, message) {
        $('#extraction-status').text(message);
        $('.progress-fill').css('width', percent + '%');
        $('.progress-text').text(percent + '%');
    }

    /**
     * Hide tag extraction dialog
     */
    function hideTagExtractionDialog() {
        $('#tag-extraction-dialog').dialog('close');
        $('#tag-extraction-dialog').remove();
    }

    /**
     * Display extracted tags in modal dialog
     */
    function displayExtractedTags(detailedTags) {
        if (!detailedTags || Object.keys(detailedTags).length === 0) {
            $('#tags-dialog-content').html('<p>No tags found in the IDML file.</p>');
            $('#show-tags-dialog').show();
            return;
        }
        // console.log('Displaying extracted tags:', detailedTags);
        var tableHtml = createTagsTable(detailedTags);
        $('#tags-dialog-content').html(tableHtml);
        $('#show-tags-dialog').show();
    }

    /**
     * Create tags table HTML
     */
    function createTagsTable(detailedTags) {
        var tableHtml = 
            '<div class="wp2id-tags-details">' +
            '<div class="wp2id-tags-details-table">' +
            '<table class="wp-list-table widefat fixed striped">' +
            '<thead>' +
            '<tr>' +
            '<th scope="col">Tag Name</th>' +
            '<th scope="col">Type</th>' +
            '<th scope="col">Length</th>' +
            '<th scope="col">Page</th>' +
            '<th scope="col">Content Preview</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody>';

        for (var tagName in detailedTags) {
            var details = detailedTags[tagName];
            var sourceStory = details.source_story || '';
            var internalId = details.internal_id || '';
            var tagType = details.type || 'text';
            var charCount = details.length || '0';
            var wordCount = details.word_count || '0';
            var pageInfo = details.page_info || {};
            var contentPreview = details.content || '';
            
            // Build tag ID display
            var tagIdDisplay = sourceStory;
            if (internalId) {
                tagIdDisplay += '/' + internalId;
            }
            
            // Build length display
            var lengthDisplay = charCount + ' chars';
            if (tagType !== 'image' && parseInt(wordCount) > 0) {
                lengthDisplay += '<br><small>' + wordCount + ' words</small>';
            }
            
            // Build page display
            var pageDisplay = '-';
            if (pageInfo.page_numbers && pageInfo.page_numbers.length > 0) {
                var pages = pageInfo.page_numbers.slice().sort(function(a, b) { return a - b; });
                if (pages.length > 3) {
                    pageDisplay = pages[0] + '-' + pages[pages.length - 1];
                } else {
                    pageDisplay = pages.join(', ');
                }
            }
            
            // Build content preview
            var contentDisplay = '';
            if (contentPreview && contentPreview.length > 0) {
                if (contentPreview.length > 100) {
                    contentDisplay = contentPreview.substring(0, 100) + '...';
                } else {
                    contentDisplay = contentPreview;
                }
            }
            
            tableHtml += 
                '<tr>' +
                '<td class="tag-id">' +
                '<div><code class="tag-name">' + escapeHtml(tagName) + '</code></div>' +    
                '<div><code class="id-tag">' + escapeHtml(tagIdDisplay) + '</code></div>' +
                '</td>' +
                '<td class="tag-type">' +
                '<span class="tag-type-badge tag-type-' + tagType.toLowerCase() + '">' +
                escapeHtml(tagType.charAt(0).toUpperCase() + tagType.slice(1)) +
                '</span>' +
                '</td>' +
                '<td class="tag-length">' + lengthDisplay + '</td>' +
                '<td class="tag-page">' + escapeHtml(pageDisplay) + '</td>' +
                '<td class="tag-content">' + escapeHtml(contentDisplay) + '</td>' +
                '</tr>';
        }

        tableHtml += 
            '</tbody>' +
            '</table>' +
            '</div>' +
            '</div>';

        return tableHtml;
    }

    /**
     * Escape HTML for safe display
     */
    function escapeHtml(text) {
        var map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, function(m) { return map[m]; });
    }

    /**
     * Show notice message
     */
    function showNotice(type, message) {
        var noticeClass = type === 'success' ? 'notice-success' : 'notice-error';
        var noticeHtml = '<div class="notice ' + noticeClass + ' is-dismissible"><p>' + message + '</p></div>';
        
        // Add notice to the top of the page
        $('.wrap h1').after(noticeHtml);
        
        // Auto dismiss after 5 seconds
        setTimeout(function() {
            $('.notice.is-dismissible').fadeOut();
        }, 5000);
    }

})(jQuery);
