/**
 * All of the JS for your admin-specific functionality should be
 * included in this file.
 */
(function ($) {
    'use strict';

    // Security check: always validate nonce in AJAX requests
    function ajaxRequest(data) {
        data.nonce = wp2id_admin.nonce;

        return $.ajax({
            url: wp2id_admin.ajax_url,
            method: 'POST',
            data: data
        });
    }
    $(document).ready(function () {

        // File uploader for template files
        if ($('.wp2id-upload-file').length) {
            // Handle file upload button click
            $('.wp2id-upload-file').on('click', function (e) {
                e.preventDefault();

                var button = $(this);
                var inputId = button.data('input-id');
                var fileFrame;
                var title = button.data('title');
                var fileType = button.data('file-type');

                // Default media options
                var mediaOptions = {
                    title: title || 'Select File',
                    button: {
                        text: 'Use this file'
                    },
                    multiple: false
                };

                // If it's specifically for IDML or ZIP, set library filtering
                if (fileType) {
                    // For IDML files, we'll allow any file type but suggest to user 
                    // through the UI that we expect IDML files
                    if (fileType === 'idml') {
                        mediaOptions.title = 'Select IDML File';
                        mediaOptions.button.text = 'Use this IDML file';
                    }
                    // For ZIP files
                    else if (fileType === 'zip') {
                        mediaOptions.title = 'Select ZIP File';
                        mediaOptions.button.text = 'Use this ZIP file';
                    }
                }

                // If the media frame already exists, reopen it
                if (fileFrame) {
                    fileFrame.open();
                    return;
                }

                // Create a new media frame
                fileFrame = wp.media(mediaOptions);

                // When a file is selected in the media frame
                fileFrame.on('select', function () {
                    var attachment = fileFrame.state().get('selection').first().toJSON();

                    // For IDML files, check extension when possible
                    if (fileType === 'idml' && attachment.filename) {
                        var ext = attachment.filename.split('.').pop().toLowerCase();
                        if (ext !== 'idml') {
                            if (!confirm('This does not appear to be an IDML file. Are you sure you want to use this file?')) {
                                return;
                            }
                        }
                    }

                    // For ZIP files, check extension when possible
                    if (fileType === 'zip' && attachment.filename) {
                        var ext = attachment.filename.split('.').pop().toLowerCase();
                        if (ext !== 'zip') {
                            if (!confirm('This does not appear to be a ZIP file. Are you sure you want to use this file?')) {
                                return;
                            }
                        }
                    }

                    $('#' + inputId).val(attachment.id);

                    // Update file info display
                    var parentRow = $('#' + inputId).closest('tr');
                    parentRow.find('.file-name').text(attachment.filename);

                    // Add download link if it doesn't exist
                    var fileInfo = parentRow.find('.file-info');
                    if (fileInfo.find('a.button').length === 0) {
                        fileInfo.append('<a href="' + attachment.url + '" target="_blank" class="button button-small">Download</a>');
                    } else {
                        fileInfo.find('a.button').attr('href', attachment.url);
                    }

                    // Show the remove button
                    parentRow.find('.wp2id-remove-file').show();
                });

                // Open the modal
                fileFrame.open();
            });

            // Handle file remove button click
            $('.wp2id-remove-file').on('click', function (e) {
                e.preventDefault();

                var button = $(this);
                var inputId = button.data('input-id');

                // Clear the hidden input value
                $('#' + inputId).val('');

                // Update file name display
                var parentRow = $('#' + inputId).closest('tr');
                parentRow.find('.file-name').text('No file selected');

                // Remove download link
                parentRow.find('.file-info a.button').remove();

                // Hide the remove button
                button.hide();
            });
        }

        // Handle tag system changes
        if ($('#wp2id_template_tag_system').length) {
            $('#wp2id_template_tag_system').on('change', function () {
                if ($('.wp2id-tags-preview').length) {
                    // Show a notification that the user needs to save to update the preview
                    var notification = $('<div class="notice notice-warning inline"><p>' +
                        wp2id_admin.i18n.saveToUpdatePreview +
                        '</p></div>');

                    // Remove any existing notifications first
                    $('.wp2id-tag-system-notification').remove();

                    // Add the notification
                    notification.addClass('wp2id-tag-system-notification');
                    $('.wp2id-tags-preview').prepend(notification);
                }
            });

            // Handle extract tags button click
            $('#wp2id_extract_tags').on('click', function () {
                console.log('wp2id_admin:', wp2id_admin);

                var button = $(this);
                var resultContainer = $('#wp2id_extract_tags_result');
                // Use the new wp2id_admin object that was localized
                var postId = wp2id_admin.postId;
                var tagSystem = $('#wp2id_template_tag_system').val();
                var idmlFileId = $('#wp2id_template_idml_file').val();

                // Check if IDML file is selected
                if (!idmlFileId) {
                    resultContainer.html('<div class="notice notice-error inline"><p>' +
                        wp2id_admin.i18n.selectIdmlFirst +
                        '</p></div>');
                    return;
                }

                // Disable button and show loading indicator
                button.prop('disabled', true).text(wp2id_admin.i18n.extracting);
                resultContainer.html('<p>' + wp2id_admin.i18n.extractingWait + '</p>');
                console.log('Extracting tags for post ID:', postId, 'using tag system:', tagSystem);
                // Make Ajax request to extract tags
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'wp2id_extract_tags',
                        post_id: postId,
                        tag_system: tagSystem,
                        force_extract: true, // Force re-extraction when button is clicked
                        nonce: wp2id_admin.extractTagsNonce
                    },
                    success: function (response) {
                        // Re-enable button
                        button.prop('disabled', false).text(wp2id_admin.i18n.extractTags);

                        if (response.success) {
                            // Format the tags as a list
                            var tagsHtml = '';
                            if (response.data.tags && response.data.tags.length > 0) {
                                var successMessage = '';

                                // Customize message based on action taken
                                if (response.data.action === 'extracted') {
                                    successMessage = wp2id_admin.i18n.tagsExtractedSuccess +
                                        ' (' + response.data.count + ' tags)';

                                    if (response.data.system_changed) {
                                        successMessage += ' ' + wp2id_admin.i18n.tagSystemChanged;
                                    }
                                } else {
                                    successMessage = wp2id_admin.i18n.tagsLoadedSuccess +
                                        ' (' + response.data.count + ' tags)';
                                }

                                tagsHtml = '<div class="notice notice-success inline"><p>' +
                                    successMessage +
                                    '</p></div>' +
                                    '<ul class="wp2id-tags-list">';

                                $.each(response.data.tags, function (index, tag) {
                                    tagsHtml += '<li><code>' + tag + '</code></li>';
                                });

                                tagsHtml += '</ul>';
                            } else {
                                tagsHtml = '<div class="notice notice-warning inline"><p>' +
                                    wp2id_admin.i18n.noTagsFound +
                                    '</p></div>';
                            }
                            resultContainer.html(tagsHtml);
                        } else {
                            // Show error message
                            resultContainer.html('<div class="notice notice-error inline"><p>' +
                                wp2id_admin.i18n.errorExtracting + ' ' +
                                (response.data.message || wp2id_admin.i18n.unknownError) +
                                '</p></div>');
                        }
                    },
                    error: function () {
                        // Re-enable button and show error message
                        button.prop('disabled', false).text(wp2id_admin.i18n.extractTags);
                        resultContainer.html('<div class="notice notice-error inline"><p>' +
                            wp2id_admin.i18n.errorConnecting +
                            '</p></div>');
                    }
                });
            });
        }
    });

})(jQuery);
