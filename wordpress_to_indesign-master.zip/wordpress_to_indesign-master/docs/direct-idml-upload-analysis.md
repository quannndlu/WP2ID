# Direct IDML Upload Feature Analysis

## Overview
Bổ sung chức năng upload file IDML trực tiếp trong metabox Template Selection của Publication, thay thế cho việc chọn template có sẵn.

## Current Architecture
### Template Selection Metabox hiện tại:
- Dropdown chọn template từ `wp2id-template` CPT
- Work status tracking
- Template tags được extract từ template đã chọn

### Publication Meta Fields hiện tại:
- `_wp2id_publication_template_id`: Template reference
- `_wp2id_publication_work_status`: Workflow tracking
- `_wp2id_publication_posts`: Array của post IDs
- `_wp2id_post_mappings`: Central tag mappings

## Feature Requirements

### 1. UI/UX Changes
- **Conditional display**: Khi upload file IDML hay chọn template thì chức năng còn lại bị disable
- **File upload interface**: WordPress Media Library integration
- **Preview restriction**: Disable preview khi dùng direct IDML
- **Auto extract**: Khi chọn file IDML hiển thị dialog đang extract tags. Khi chọn template, tự động (gọi Ajax) lấy dữ liệu từ template gắn vào các field ở publication mà không cần ấn update.

### 2. Backend Changes
- **New meta field**: `_wp2id_publication_direct_idml_file` (attachment ID)
- **New meta field**: `_wp2id_publication_direct_idml_tags` (extracted tags)
- **New meta field**: `_wp2id_publication_direct_idml_tags_details` (detailed tag analysis)
- **Tag extraction**: Reuse template tag extraction logic
- **Validation**: Ensure only IDML files accepted
- **Dynamic metabox**: Show tags metabox after extraction
- **Progress dialog**: Real-time extraction feedback

### 3. Processing Logic
- **Mode detection**: Template mode vs Direct IDML mode
- **Tag extraction**: Extract tags from uploaded IDML
- **Export compatibility**: Support both modes trong export process
- **Preview restriction**: Disable preview cho direct IDML mode
-- ** Auto 

## Technical Implementation

### 1. Database Schema Changes
```php
// New meta fields
_wp2id_publication_upload_mode              // 'template' or 'direct_idml'
_wp2id_publication_direct_idml_file         // Attachment ID của uploaded IDML
_wp2id_publication_direct_idml_tags         // Extracted tags từ direct IDML
_wp2id_publication_direct_idml_tags_details // Detailed tag analysis như template
```

### 2. Template Selection UI
```php
// Radio buttons for mode selection
<input type="radio" name="wp2id_upload_mode" value="template" checked>
<label>Use Template</label>

<input type="radio" name="wp2id_upload_mode" value="direct_idml">
<label>Upload IDML Directly</label>

// Conditional sections
<div id="template-selection" style="display: block;">
    <!-- Existing template dropdown -->
</div>

<div id="direct-idml-upload" style="display: none;">
    <!-- New IDML upload interface -->
    <div class="idml-upload-section">
        <button type="button" id="upload-direct-idml" class="button">
            <span class="dashicons dashicons-upload"></span>
            Select IDML File
        </button>
        <div id="selected-idml-info" style="display: none;">
            <p><strong>Selected file:</strong> <span id="idml-filename"></span></p>
            <button type="button" id="remove-direct-idml" class="button">Remove</button>
        </div>
    </div>
</div>

// Dynamic Tags Metabox (hiển thị sau khi extract)
<div id="direct-idml-tags-metabox" style="display: none;">
    <h3>Extracted Tags</h3>
    <div id="direct-idml-tags-content">
        <!-- Tags table will be populated here -->
    </div>
</div>
```

### 3. File Upload Integration
```php
// WordPress Media Library integration
wp_enqueue_media();

// Upload button với IDML filter
$('#upload-direct-idml').click(function() {
    var frame = wp.media({
        title: 'Select IDML File',
        library: { type: 'application/octet-stream' },
        multiple: false
    });
    
    frame.on('select', function() {
        var attachment = frame.state().get('selection').first().toJSON();
        
        // Show processing dialog
        showTagExtractionDialog();
        
        // Trigger AJAX tag extraction
        extractTagsFromDirectIdml(attachment.id);
    });
    
    frame.open();
});

// Tag extraction dialog
function showTagExtractionDialog() {
    $('<div id="tag-extraction-dialog">' +
      '<div class="extraction-progress">' +
      '<div class="spinner is-active"></div>' +
      '<p>Extracting tags from IDML file...</p>' +
      '<div class="progress-bar"><div class="progress-fill"></div></div>' +
      '</div>' +
      '</div>').dialog({
        title: 'Processing IDML File',
        modal: true,
        resizable: false,
        width: 400,
        height: 200,
        closeOnEscape: false
    });
}
```

### 4. Tag Extraction Process
```php
// Reuse existing template tag extraction
public function extract_direct_idml_tags($idml_file_id) {
    $idml_file_path = get_attached_file($idml_file_id);
    
    // Use existing WP2ID_IDML_Template logic
    $template = new WP2ID_IDML_Template();
    $tags = $template->extract_tags_from_file($idml_file_path);
    
    return $tags;
}

// AJAX handler for direct IDML tag extraction
public function ajax_extract_direct_idml_tags() {
    // Security checks
    if (!wp_verify_nonce($_POST['nonce'], 'wp2id_publication_ajax_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed.'));
    }
    
    $publication_id = intval($_POST['publication_id']);
    $idml_file_id = intval($_POST['idml_file_id']);
    
    // Extract tags
    $tags = $this->extract_direct_idml_tags($idml_file_id);
    $detailed_tags = $this->extract_detailed_tags($idml_file_id);
    
    if ($tags && $detailed_tags) {
        // Save extracted tags
        update_post_meta($publication_id, '_wp2id_publication_direct_idml_tags', $tags);
        update_post_meta($publication_id, '_wp2id_publication_direct_idml_tags_details', $detailed_tags);
        
        wp_send_json_success(array(
            'message' => 'Tags extracted successfully',
            'tags_count' => count($tags),
            'detailed_tags' => $detailed_tags
        ));
    } else {
        wp_send_json_error(array('message' => 'Failed to extract tags from IDML file'));
    }
}
```

### 5. Export Process Modification
```php
public function process_idml_export($publication_id, $template_id, $post_mappings) {
    $upload_mode = get_post_meta($publication_id, '_wp2id_publication_upload_mode', true);
    
    if ($upload_mode === 'direct_idml') {
        // Use direct IDML file
        $idml_file_id = get_post_meta($publication_id, '_wp2id_publication_direct_idml_file', true);
        $template_file_path = get_attached_file($idml_file_id);
    } else {
        // Use template file (existing logic)
        $template_file_id = get_post_meta($template_id, '_wp2id_template_idml_file', true);
        $template_file_path = get_attached_file($template_file_id);
    }
    
    // Continue with existing export process
}
```

## File Changes Required

### 1. Core Files
- `class-wp2id-publication.php` - Main publication class
- `metabox-template-select.php` - Template selection view
- `wp2id-publication.js` - Frontend JavaScript
- `metabox-publication.css` - Additional styling for dialog and tags display

### 2. New/Modified Methods
```php
// In WP2ID_Publication class
public function handle_direct_idml_upload()
public function extract_direct_idml_tags($publication_id, $idml_file_id)
public function extract_detailed_tags($idml_file_id) // Detailed tag analysis
public function ajax_extract_direct_idml_tags() // AJAX handler for tag extraction
public function get_publication_idml_source($publication_id)
public function validate_direct_idml_file($file_id)
public function render_direct_idml_tags_metabox($publication_id) // Dynamic metabox rendering
```

### 3. JavaScript Functions
```javascript
// Mode switching
function toggleUploadMode(mode)
function handleDirectIdmlUpload()
function validateIdmlFile(file)
function extractTagsFromDirectIdml(publicationId, fileId)

// Progress dialog functions
function showTagExtractionDialog()
function updateExtractionProgress(percent, message)
function hideTagExtractionDialog()

// Tags display functions
function displayExtractedTags(detailedTags)
function createTagsTable(detailedTags)
function showDirectIdmlTagsMetabox()
```

## Security Considerations

### 1. File Validation
- **MIME type checking**: Ensure IDML files only
- **File size limits**: Reasonable limits for IDML files
- **File integrity**: Validate ZIP structure của IDML
- **Permission checking**: User capabilities

### 2. Data Sanitization
- **File path sanitization**: Prevent directory traversal
- **Meta data validation**: Validate extracted tags
- **Nonce verification**: All AJAX operations
- **Capability checking**: Upload permissions

## Backward Compatibility

### 1. Existing Publications
- **Default mode**: Publications without upload_mode default to 'template'
- **Migration**: Existing publications continue working
- **Fallback**: Graceful handling của missing fields

### 2. Export Compatibility
- **Dual support**: Export works với both modes
- **Tag format**: Consistent tag format across modes
- **Error handling**: Clear errors cho invalid configurations

## Testing Strategy

### 1. Unit Tests
- **File upload validation**
- **Tag extraction accuracy**
- **Mode switching logic**
- **Export process với both modes**

### 2. Integration Tests
- **End-to-end workflow**: Upload → Extract → Map → Export
- **UI interaction**: Mode switching và conditional display
- **Error scenarios**: Invalid files, extraction failures

### 3. User Acceptance Tests
- **Workflow comparison**: Template vs Direct IDML workflows
- **Performance testing**: Large IDML file handling
- **Browser compatibility**: Upload interface across browsers

## Performance Considerations

### 1. File Processing
- **Async extraction**: Tag extraction in background
- **Progress indicators**: User feedback during processing
- **Memory management**: Large IDML file handling
- **Cleanup**: Temporary file cleanup

### 2. Caching
- **Tag caching**: Cache extracted tags
- **File validation caching**: Cache validation results
- **Progressive loading**: Load UI components as needed

## Implementation Status ✅ COMPLETED

### ✅ Backend Implementation (admin/class-wp2id-publication.php)
- Added AJAX action for direct IDML tag extraction
- Added new meta fields in save_publication_metaboxes method
- Modified process_idml_export to support both template and direct IDML modes
- Modified ajax_get_template_tags to support both modes
- Added preview restriction for direct IDML mode in ajax_preview_publication
- Added ajax_extract_direct_idml_tags method with full tag extraction logic

### ✅ Frontend Implementation (admin/views/metabox-template-select.php)
- Added radio button mode selection (Template vs Direct IDML)
- Added conditional display sections for each mode
- Added IDML upload interface with WordPress Media Library integration
- Added dynamic tags metabox with detailed tag table display
- Added complete styling for all new UI elements

### ✅ JavaScript Implementation (assets/js/wp2id-publication.js)
- Added initUploadModeSwitching() function
- Added toggleUploadMode() function for conditional display
- Added initDirectIdmlUpload() function
- Added handleDirectIdmlUpload() with WordPress Media Library integration
- Added showTagExtractionDialog() with progress indicators
- Added extractTagsFromDirectIdml() with AJAX tag extraction
- Added displayExtractedTags() and createTagsTable() for dynamic tag display
- Added all helper functions for validation, progress updates, and UI management

### ✅ CSS Implementation (admin/assets/css/metabox-publication.css)  
- Added tag extraction dialog styles with progress bar
- Added upload mode selection styling
- Added tags metabox and table styling
- Added responsive design adjustments
- Added tag type badges and ID styling

### ✅ Feature Verification
- Radio button mode selection ✅
- WordPress Media Library integration ✅
- AJAX tag extraction with progress dialog ✅
- Dynamic tags table display ✅
- Preview disabled for direct IDML mode ✅
- Export support for both modes ✅
- Complete UI/UX with conditional display ✅
- New meta fields and data persistence ✅

## Success Metrics

### 1. Functionality
- [ ] Radio button mode selection works
- [ ] IDML upload interface functional
- [ ] Tag extraction dialog displays properly
- [ ] Progress indication during extraction
- [ ] Tag extraction successful
- [ ] Tags table displays after extraction
- [ ] Export works với direct IDML
- [ ] Preview properly disabled

### 2. User Experience
- [ ] Intuitive UI flow
- [ ] Clear feedback messages during extraction
- [ ] Smooth progress indication
- [ ] Tags table readable and informative
- [ ] Performance acceptable
- [ ] Error handling informative

### 3. Technical
- [ ] Backward compatibility maintained
- [ ] Security standards met
- [ ] Code quality standards
- [ ] Documentation complete

## Future Enhancements

### 1. Advanced Features
- **IDML validation**: Advanced structure validation
- **Template conversion**: Convert direct IDML to template
- **Batch processing**: Multiple IDML files
- **Version control**: IDML file versioning

### 2. UI Improvements
- **Drag & drop upload**: Enhanced upload UX
- **Preview generation**: Limited preview for direct IDML
- **Progress tracking**: Real-time processing feedback
- **Comparison tools**: Compare template vs direct modes

## Dependencies

### 1. Existing Classes
- `WP2ID_IDML_Template` - Tag extraction logic
- `WP2ID_IDML_Reader` - IDML file processing
- `WP2ID_Permission_Manager` - Security checks

### 2. WordPress APIs
- **Media Library**: File upload handling
- **AJAX**: Async operations
- **Meta API**: Data storage
- **Hooks**: Integration points

## Risk Assessment

### 1. Technical Risks
- **File corruption**: IDML file integrity issues
- **Memory usage**: Large file processing
- **Compatibility**: Different IDML versions
- **Performance**: Tag extraction speed

### 2. User Experience Risks
- **Confusion**: Mode selection complexity
- **Workflow disruption**: Changes to familiar process
- **Error recovery**: Handling failed uploads
- **Learning curve**: New feature adoption

## Mitigation Strategies

### 1. Technical Mitigation
- **Robust validation**: Multi-layer file checking
- **Error logging**: Comprehensive error tracking
- **Fallback mechanisms**: Graceful degradation
- **Performance monitoring**: Track processing times

### 2. UX Mitigation
- **Clear documentation**: User guides và tooltips
- **Progressive disclosure**: Hide complexity initially
- **Consistent patterns**: Follow existing UI patterns
- **User feedback**: Beta testing với real users

## UI/UX Flow Implementation

### 1. File Upload → Tag Extraction → Display Workflow
```javascript
// Complete workflow implementation
function handleDirectIdmlUpload() {
    var frame = wp.media({
        title: 'Select IDML File',
        library: { type: 'application/octet-stream' },
        multiple: false
    });
    
    frame.on('select', function() {
        var attachment = frame.state().get('selection').first().toJSON();
        
        // Update UI with selected file
        $('#idml-filename').text(attachment.filename);
        $('#selected-idml-info').show();
        
        // Show processing dialog
        showTagExtractionDialog();
        
        // Start tag extraction via AJAX
        extractTagsFromDirectIdml(wp2id_publication_admin.postId, attachment.id);
    });
    
    frame.open();
}

function showTagExtractionDialog() {
    var dialogHtml = 
        '<div id="tag-extraction-dialog" title="Processing IDML File">' +
        '<div class="extraction-progress">' +
        '<div class="wp2id-spinner">' +
        '<div class="spinner is-active"></div>' +
        '</div>' +
        '<p id="extraction-status">Analyzing IDML file structure...</p>' +
        '<div class="progress-container">' +
        '<div class="progress-bar">' +
        '<div class="progress-fill" style="width: 0%"></div>' +
        '</div>' +
        '<span class="progress-text">0%</span>' +
        '</div>' +
        '</div>' +
        '</div>';
    
    $('body').append(dialogHtml);
    
    $('#tag-extraction-dialog').dialog({
        modal: true,
        resizable: false,
        width: 450,
        height: 250,
        closeOnEscape: false,
        open: function() {
            $('.ui-dialog-titlebar-close').hide(); // Hide close button
        }
    });
}

function extractTagsFromDirectIdml(publicationId, fileId) {
    // Simulate progress updates
    updateExtractionProgress(20, 'Extracting IDML structure...');
    
    setTimeout(function() {
        updateExtractionProgress(50, 'Analyzing XML tags...');
    }, 1000);
    
    setTimeout(function() {
        updateExtractionProgress(80, 'Processing tag details...');
    }, 2000);
    
    // Actual AJAX call
    $.ajax({
        url: wp2id_publication_admin.ajaxurl,
        type: 'POST',
        data: {
            action: 'wp2id_extract_direct_idml_tags',
            nonce: wp2id_publication_admin.nonce,
            publication_id: publicationId,
            idml_file_id: fileId
        },
        success: function(response) {
            if (response.success) {
                updateExtractionProgress(100, 'Extraction completed!');
                
                setTimeout(function() {
                    hideTagExtractionDialog();
                    displayExtractedTags(response.data.detailed_tags);
                }, 500);
            } else {
                hideTagExtractionDialog();
                alert('Error: ' + response.data.message);
            }
        },
        error: function() {
            hideTagExtractionDialog();
            alert('Failed to extract tags. Please try again.');
        }
    });
}

function updateExtractionProgress(percent, message) {
    $('#extraction-status').text(message);
    $('.progress-fill').css('width', percent + '%');
    $('.progress-text').text(percent + '%');
}

function hideTagExtractionDialog() {
    $('#tag-extraction-dialog').dialog('close');
    $('#tag-extraction-dialog').remove();
}

function displayExtractedTags(detailedTags) {
    if (!detailedTags || Object.keys(detailedTags).length === 0) {
        $('#direct-idml-tags-content').html('<p>No tags found in the IDML file.</p>');
        $('#direct-idml-tags-metabox').show();
        return;
    }
    
    var tableHtml = createTagsTable(detailedTags);
    $('#direct-idml-tags-content').html(tableHtml);
    $('#direct-idml-tags-metabox').show();
    
    // Scroll to tags metabox
    $('html, body').animate({
        scrollTop: $('#direct-idml-tags-metabox').offset().top - 50
    }, 500);
}

function createTagsTable(detailedTags) {
    var tableHtml = 
        '<div class="wp2id-tags-details">' +
        '<div class="wp2id-tags-details-table">' +
        '<table class="wp-list-table widefat fixed striped">' +
        '<thead>' +
        '<tr>' +
        '<th scope="col">Tag Name</th>' +
        '<th scope="col">Type</th>' +
        '<th scope="col">Length</th>' +
        '<th scope="col">Page</th>' +
        '<th scope="col">Content Preview</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>';
    
    for (var tagName in detailedTags) {
        var details = detailedTags[tagName];
        var sourceStory = details.source_story || '';
        var internalId = details.internal_id || '';
        var tagType = details.type || 'text';
        var charCount = details.length || '0';
        var wordCount = details.word_count || '0';
        var pageInfo = details.page_info || {};
        var contentPreview = details.content || '';
        
        // Build tag ID display
        var tagIdDisplay = sourceStory;
        if (internalId) {
            tagIdDisplay += '/' + internalId;
        }
        
        // Build length display
        var lengthDisplay = charCount + ' chars';
        if (tagType !== 'image' && parseInt(wordCount) > 0) {
            lengthDisplay += '<br><small>' + wordCount + ' words</small>';
        }
        
        // Build page display
        var pageDisplay = '-';
        if (pageInfo.page_numbers && pageInfo.page_numbers.length > 0) {
            var pages = pageInfo.page_numbers.slice().sort(function(a, b) { return a - b; });
            if (pages.length > 3) {
                pageDisplay = pages[0] + '-' + pages[pages.length - 1];
            } else {
                pageDisplay = pages.join(', ');
            }
        }
        
        // Build content preview
        var contentDisplay = '';
        if (contentPreview && contentPreview.length > 0) {
            if (contentPreview.length > 100) {
                contentDisplay = contentPreview.substring(0, 100) + '...';
            } else {
                contentDisplay = contentPreview;
            }
        }
        
        tableHtml += 
            '<tr>' +
            '<td class="tag-id"><code class="id-tag">' + tagIdDisplay + '</code></td>' +
            '<td class="tag-type">' +
            '<span class="tag-type-badge tag-type-' + tagType.toLowerCase() + '">' +
            tagType.charAt(0).toUpperCase() + tagType.slice(1) +
            '</span>' +
            '</td>' +
            '<td class="tag-length">' + lengthDisplay + '</td>' +
            '<td class="tag-page">' + pageDisplay + '</td>' +
            '<td class="tag-content">' + contentDisplay + '</td>' +
            '</tr>';
    }
    
    tableHtml += 
        '</tbody>' +
        '</table>' +
        '</div>' +
        '</div>';
    
    return tableHtml;
}
```

### 2. CSS Styling for Dialog and Tags Display
```css
/* Tag extraction dialog styles */
#tag-extraction-dialog {
    text-align: center;
    padding: 20px;
}

.extraction-progress {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 15px;
}

.wp2id-spinner .spinner {
    float: none;
    margin: 0 auto;
}

.progress-container {
    width: 100%;
    display: flex;
    align-items: center;
    gap: 10px;
}

.progress-bar {
    flex: 1;
    height: 20px;
    background-color: #e0e0e0;
    border-radius: 10px;
    overflow: hidden;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, #0073aa, #00a0d2);
    transition: width 0.3s ease;
    border-radius: 10px;
}

.progress-text {
    font-weight: bold;
    min-width: 35px;
}

/* Direct IDML tags metabox styles */
#direct-idml-tags-metabox {
    background: #fff;
    border: 1px solid #c3c4c7;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
    margin-top: 20px;
    padding: 0;
}

#direct-idml-tags-metabox h3 {
    background: #f6f7f7;
    border-bottom: 1px solid #c3c4c7;
    margin: 0;
    padding: 12px 15px;
    font-size: 14px;
    line-height: 1.4;
}

#direct-idml-tags-content {
    padding: 15px;
}

/* Reuse existing tag table styles from template */
.wp2id-tags-details-table .tag-type-badge {
    padding: 2px 8px;
    border-radius: 3px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.tag-type-text {
    background-color: #0073aa;
    color: white;
}

.tag-type-image {
    background-color: #00a0d2;
    color: white;
}

.id-tag {
    background: #f0f0f1;
    padding: 2px 6px;
    border-radius: 3px;
    font-family: Consolas, Monaco, monospace;
    font-size: 12px;
}
```
