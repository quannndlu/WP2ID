# Tag System Documentation

The WP2ID plugin supports two different tag extraction systems for IDML templates:

## 1. Tag-Based System

The Tag-Based System uses InDesign's native tagging system to extract content from IDML files. This system is based on the tag structure within InDesign documents.

### Advantages:
- Integrates with InDesign's native tagging structure
- Better for complex document structures
- Maintains proper styling and formatting

## 2. Custom Tag #[Tag Name]# System

The Custom Tag system extracts content enclosed within hash symbols (`#`) from the IDML document. For example, `#title_1#` or `#product_description#`.

### Advantages:
- Simple and easy to understand
- Works well for content placeholders
- Intuitive for content authors who are not InDesign experts

## How to Configure the Tag System

1. Go to your WordPress admin panel
2. Navigate to 'Templates' in the WP2ID menu
3. Edit an existing template or create a new one
4. In the 'Template Data' section, select your preferred tag system:
   - **Tag-Based System**: Uses InDesign's native tag structure
   - **Custom Tag #[Tag Name]#**: Extracts content within # symbols

5. Upload your IDML file
6. Save the template

## Viewing Extracted Tags

After saving a template with an IDML file, you can view the extracted tags in the 'Extracted Tags' section. This shows all tags found in the document based on your selected tag system.

If you change the tag system, you need to save the template again to refresh the list of extracted tags.

## Best Practices

### For Tag-Based System:
- Create proper tag structures in InDesign
- Use consistent tag naming conventions
- Organize tags in a logical hierarchy

### For Custom Tag #[Tag Name]# System:
- Use clear, descriptive tag names like `#article_title#`, `#author_name#`
- Avoid spaces in tag names (use underscores instead)
- Be consistent with your naming conventions
- Ensure each tag has unique opening and closing `#` symbols

## Examples

**Custom Tag Examples:**
- `#title_1#` - Main title
- `#product_description#` - Product description text
- `#author_bio#` - Author biography

By selecting the appropriate tag system for your workflow, you can efficiently extract and manage content from your InDesign templates.
