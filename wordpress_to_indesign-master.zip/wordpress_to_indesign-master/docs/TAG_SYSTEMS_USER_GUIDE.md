# WP2ID Tag Systems - User Guide

## Two Tag Systems Available

### 1. Tag-Based System (Default)
Uses InDesign's native tagging system with XMLElement nodes.

**When to use:**
- Working with complex InDesign documents
- Need precise control over styling and formatting
- Templates created by InDesign professionals

**Example in IDML:**
```xml
<XMLElement MarkupTag="XMLTag/product_title">
    <Content>Product Title Placeholder</Content>
</XMLElement>
```

### 2. Custom Tag #[Tag Name]# System
Uses simple hash-enclosed tag format for content placeholders.

**When to use:**
- Simple content replacement needs
- Templates created by non-InDesign experts
- Quick and intuitive content authoring

**Example in IDML:**
```xml
<Content>Welcome to #[product_name]# which costs #[price]#!</Content>
```

## How to Configure Tag System

1. Go to **Templates** in WordPress admin
2. Edit or create a template
3. In the **Template Data** section:
   - Select **Tag-Based System** for XMLElement tags
   - Select **Custom Tag #[Tag Name]#** for hash-enclosed tags
4. Upload your IDML file
5. Click **Extract Tags** to see available tags
6. Save the template

## Tag Naming Guidelines

### For Custom Tag System:
- Use descriptive names: `#[product_title]#`, `#[main_content]#`
- Avoid spaces: Use underscores instead (`#[product_image]#`)
- Be consistent with naming convention
- Image tags should contain "image" or "feature": `#[featured_image]#`

### For Tag-Based System:
- Tags are extracted from XMLElement MarkupTag attributes
- Follow InDesign tag naming conventions
- Use hierarchical naming if needed: `product/title`, `content/main`

## Content Mapping

When creating publications, you can map WordPress content to template tags:

### Available WordPress Fields:
- **Title** - Post title
- **Content** - Post content (formatted for InDesign)
- **Excerpt** - Post excerpt or auto-generated summary
- **Featured Image** - Post thumbnail
- **Author** - Post author name
- **Date** - Post publication date
- **Category** - Post categories
- **Custom Fields** - Any post meta fields

### Image Handling:
- Image tags are automatically detected (contain "image" or "feature")
- WordPress featured images are copied to IDML and links updated
- Supports JPG, PNG, and other common image formats

## Best Practices

### Template Creation:
1. Choose tag system based on your workflow needs
2. Use consistent tag naming throughout template
3. Test with sample content before finalizing
4. Keep tag names short but descriptive

### Content Preparation:
1. Ensure featured images are set for posts with image tags
2. Write meaningful excerpts for excerpt tags
3. Use structured content for better formatting
4. Preview publications before final export

### Troubleshooting:
1. Enable debug logging in WP2ID settings
2. Check wp-content/debug.log for detailed processing info
3. Verify tag names match exactly between template and mappings
4. Test with simple content first, then add complexity

## Template Examples

### Simple Product Template (Custom Tags):
```
Product Name: #[product_name]#
Price: #[price]#
Description: #[description]#
Image: #[product_image]#
```

### Article Template (Tag-Based):
```xml
<XMLElement MarkupTag="XMLTag/article_title">
    <Content>Article Title</Content>
</XMLElement>
<XMLElement MarkupTag="XMLTag/article_content">
    <Content>Article content goes here...</Content>
</XMLElement>
<XMLElement MarkupTag="XMLTag/featured_image">
    <XMLAttribute Name="href" Value="placeholder.jpg"/>
</XMLElement>
```

## Migration Between Systems

To change tag systems for existing templates:
1. Edit the template in WordPress admin
2. Change the **Tag System** setting
3. Click **Extract Tags** to refresh available tags
4. Update publication mappings if tag names changed
5. Test export with sample content

Remember: Changing tag systems requires updating the IDML template file to use the appropriate tag format.
