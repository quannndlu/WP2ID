1. Đọc mapping có dạng 
wp2id_post_mappings: Array
(
    [179] => Array
        (
            [image] => Back_Image_1
        )

    [191] => Array
        (
            [title] => Page_3_Title_2
            [excerpt] => Page_3_Exp_2
            [image] => Page_3_Image_2
            [content] => Array
                (
                    [0] => Array
                        (
                            [tag] => Page_3_Content_3
                            [start] => 
                            [end] => 
                        )

                )

        )

    [235] => Array
        (
            [title] => Page_3_Title_1
            [excerpt] => Page_3_Exp_1
            [image] => Page_3_Image_1
            [content] => Array
                (
                    [0] => Array
                        (
                            [tag] => Page_3_Content_1
                            [start] => 0
                            [end] => 300
                        )

                    [1] => Array
                        (
                            [tag] => Page_2_Content_2
                            [start] => 301
                            [end] => 600
                        )

                )

        )

    [269] => Array
        (
            [title] => Page_2_Title
            [image] => Page_2_Image
            [author] => Page_2_Author
            [content] => Array
                (
                    [0] => Array
                        (
                            [tag] => Page_2_Content_1
                            [start] => 
                            [end] => 200
                        )

                    [1] => Array
                        (
                            [tag] => Page_2_Content_2
                            [start] => 201
                            [end] => 400
                        )

                    [2] => Array
                        (
                            [tag] => Page_2_Content_3
                            [start] => 401
                            [end] => 600
                        )

                    [3] => Array
                        (
                            [tag] => Page_2_Content_4
                            [start] => 601
                            [end] => 800
                        )

                )

        )

    [278] => Array
        (
            [title] => Cover_Title
            [excerpt] => Cover_Exp
            [image] => Cover_Image
            [date] => Cover_Date
            [content] => Array
                (
                    [0] => Array
                        (
                            [tag] => Cover_Des
                            [start] => 0
                            [end] => 200
                        )

                )

        )

2. Thay đổi nội dung dựa vào các mapping. 
3. Đổi tên các ảnh thành tên tag và đưa vào folder images để sẵn sàng tải về.
4. Thay đổi hình ảnh theo các bước sau: 
4.1 Tìm các Spread có các element được gắn tag. 
4.2 Thay đổi uri hình ảnh thành uri mới trong Spread 
4.2 Thay uri này trong Links.xml nếu tồn tại, chưa tồn tại tạo mới. 
4.3 Thay uri mới trong metadata.xml nếu tồn tại, chưa tồn tại tạo mới. Thay ở 2 tag là Manifest và Ingradients
5. Thay uri mới trong BackingStory.xml nếu tồn tại, chưa tồn tại tạo mới. Đảm bảo chỉ có duy nhất 1 element với 1 tag name. 
5. Nén thành file zip có file idml và thư mục images. 


REF:
- Trong mapping, key được ánh xạ là các thuộc tính của post. image là feature image, value trong mapping ánh xạ tag / cách 
- Chỉ thay đổi các element có tag name được mapping. Chỉ cần mapping có tồn tại thì sẽ thay đổi không cần kiểm tra thêm gì.  
- Đảm bảo có 1 element với 1 tag name được liên kết với nhau.  
- Hình ảnh phải hiển thị trong Links Panel của Indesign (4.2 đến 5)
