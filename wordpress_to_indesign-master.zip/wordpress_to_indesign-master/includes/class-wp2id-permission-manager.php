<?php
/**
 * WP2ID Permission Manager
 *
 * Handles role-based permissions for the WP2ID plugin
 *
 * @since      1.0.0
 * @package    WP2ID
 * @subpackage WP2ID/includes
 */

if (!defined('WPINC')) {
    die;
}

/**
 * The permission manager class.
 *
 * This class defines all functionality for managing user permissions
 * within the WP2ID plugin.
 */
class WP2ID_Permission_Manager
{
    /**
     * Available permissions in the plugin
     */
    const PERMISSIONS = [
        'access_search_results' => 'Access Search Results',
        'access_work_area' => 'Access Work Area',
        'remove_posts' => 'Remove Posts from Publications',
        'export_publications' => 'Export Publications'
    ];

    /**
     * Default permissions for WordPress roles
     */
    const DEFAULT_PERMISSIONS = [
        'administrator' => [
            'access_search_results',
            'access_work_area', 
            'remove_posts',
            'export_publications'
        ],
        'editor' => [
            'access_search_results',
            'access_work_area',
            'remove_posts',
            'export_publications'
        ],
        'author' => [
            'access_search_results',
            'access_work_area'
        ],
        'contributor' => [
            'access_search_results'
        ],
        'subscriber' => []
    ];

    /**
     * Initialize the class
     */
    public function __construct()
    {
        // Initialize default permissions on plugin activation
        add_action('wp_loaded', array($this, 'maybe_initialize_permissions'));
    }

    /**
     * Initialize default permissions if not already set
     */
    public function maybe_initialize_permissions()
    {
        $initialized = get_option('wp2id_permissions_initialized', false);
        
        if (!$initialized) {
            $this->reset_to_defaults();
            update_option('wp2id_permissions_initialized', true);
        }
    }

    /**
     * Check if current user has a specific permission
     *
     * @param string $permission Permission to check
     * @return bool
     */
    public static function current_user_can($permission)
    {
        $current_user = wp_get_current_user();
        
        if (!$current_user || !$current_user->exists()) {
            return false;
        }

        return self::user_can($current_user, $permission);
    }

    /**
     * Check if a user has a specific permission
     *
     * @param WP_User $user User object
     * @param string $permission Permission to check
     * @return bool
     */
    public static function user_can($user, $permission)
    {
        if (!$user || !$user->exists()) {
            return false;
        }

        // Super admins always have all permissions
        // if (is_super_admin($user->ID)) {
        //     return true;
        // }

        // Get saved permissions
        $role_permissions = get_option('wp2id_role_permissions', []);
        
        // Check each role the user has
        foreach ($user->roles as $role) {
            if (isset($role_permissions[$role]) && 
                in_array($permission, $role_permissions[$role])) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get permissions for a specific role
     *
     * @param string $role Role name
     * @return array
     */
    public static function get_role_permissions($role)
    {
        $role_permissions = get_option('wp2id_role_permissions', []);
        return isset($role_permissions[$role]) ? $role_permissions[$role] : [];
    }

    /**
     * Set permissions for a role
     *
     * @param string $role Role name
     * @param array $permissions Array of permission names
     * @return bool
     */
    public static function set_role_permissions($role, $permissions)
    {
        $role_permissions = get_option('wp2id_role_permissions', []);
        $role_permissions[$role] = array_values(array_intersect($permissions, array_keys(self::PERMISSIONS)));
        
        return update_option('wp2id_role_permissions', $role_permissions);
    }

    /**
     * Get all available permissions
     *
     * @return array
     */
    public static function get_available_permissions()
    {
        return self::PERMISSIONS;
    }

    /**
     * Reset permissions to default values
     */
    public function reset_to_defaults()
    {
        update_option('wp2id_role_permissions', self::DEFAULT_PERMISSIONS);
    }

    /**
     * Get all WordPress roles
     *
     * @return array
     */
    public static function get_wordpress_roles()
    {
        global $wp_roles;
        
        if (!isset($wp_roles)) {
            $wp_roles = new WP_Roles();
        }
        
        return $wp_roles->get_names();
    }

    /**
     * Check if user can access publication features
     *
     * @return bool
     */
    public static function can_access_publications()
    {
        return current_user_can('edit_posts') && 
               (self::current_user_can('access_search_results') || 
                self::current_user_can('access_work_area'));
    }
}
