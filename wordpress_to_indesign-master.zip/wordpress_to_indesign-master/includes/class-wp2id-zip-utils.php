<?php

/**
 * ZIP File Utilities
 *
 * @link       https://yourwebsite.com
 * @since      1.0.0
 *
 * @package    WP2ID
 * @subpackage WP2ID/includes
 */

/**
 * ZIP File Utility Functions
 *
 * This class contains utility methods for handling ZIP file operations
 * within the WordPress to InDesign export process.
 *
 * @package    WP2ID
 * @subpackage WP2ID/includes
 * @author     Hoàng Bách <tinhp.wk@gmail.com>
 */
class WP2ID_ZIP_Utils
{

    /**
     * Create a ZIP archive from a directory
     * 
     * @param string $source_dir Directory to zip
     * @param string $destination Path to save the ZIP file
     * @return boolean True if successful, false otherwise
     */
    public static function zip_directory($source_dir, $destination)
    {
        if (!extension_loaded('zip')) {
            error_log('ZIP extension not loaded');
            return false;
        }

        // Ensure source directory exists
        if (!is_dir($source_dir)) {
            error_log('Source is not a directory: ' . $source_dir);
            return false;
        }

        // Get real path of source directory
        $source_dir_real = realpath($source_dir);
        if ($source_dir_real === false) {
            error_log('Invalid source directory path: ' . $source_dir);
            return false;
        }

        $zip = new ZipArchive();
        if (!$zip->open($destination, ZipArchive::CREATE)) {
            error_log('Failed to create ZIP archive at: ' . $destination);
            return false;
        }

        $source_dir = str_replace('\\', '/', $source_dir_real);

        if (is_dir($source_dir)) {
            $iterator = new RecursiveDirectoryIterator($source_dir);
            $iterator->setFlags(RecursiveDirectoryIterator::SKIP_DOTS);
            $files = new RecursiveIteratorIterator($iterator, RecursiveIteratorIterator::SELF_FIRST);

            foreach ($files as $file) {
                // Check if $file is an object (SplFileInfo) or a string
                if (is_object($file)) {
                    // Handle as SplFileInfo object
                    $file_path = str_replace('\\', '/', $file->getPathname());
                    $relative_path = substr($file_path, strlen($source_dir) + 1);
                    $real_path = $file_path;
                } else {
                    // Handle as string
                    $real_path = str_replace('\\', '/', $file);
                    $relative_path = substr($real_path, strlen($source_dir) + 1);
                }

                if (is_dir($real_path)) {
                    $zip->addEmptyDir($relative_path);
                } else if (is_file($real_path)) {
                    $zip->addFile($real_path, $relative_path);
                }
            }
        } else {
            $zip->addFile($source_dir, basename($source_dir));
        }

        return $zip->close();
    }

    /**
     * Extract HTML content from ZIP file
     * 
     * @param string $zip_file_path Path to the ZIP file
     * @return string|false HTML content or false on failure
     */
    public static function extract_html_from_zip($zip_file_path)
    {
        if (!class_exists('ZipArchive')) {
            return false;
        }

        $zip = new ZipArchive();
        if ($zip->open($zip_file_path) !== true) {
            return false;
        }

        $html_content = '';
        
        // Look for HTML files in the ZIP
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $filename = $zip->getNameIndex($i);
            
            // Check if it's an HTML file
            if (preg_match('/\.(html|htm)$/i', $filename)) {
                $content = $zip->getFromIndex($i);
                if ($content !== false) {
                    $html_content = $content;
                    break; // Use the first HTML file found
                }
            }
        }

        $zip->close();
        
        return $html_content ?: false;
    }

    /**
     * Create an accessible preview by extracting ZIP template and mapping content
     * 
     * @param string $zip_file_path Path to template ZIP file
     * @param int $template_id Template ID
     * @param array $post_ids Array of post IDs
     * @param int $publication_id Publication ID
     * @return array Result with success status and preview URL
     */
    public static function create_accessible_preview($zip_file_path, $template_id, $post_ids, $publication_id)
    {
        // Create unique preview directory
        $upload_dir = wp_upload_dir();
        $preview_id = 'preview_' . time() . '_' . uniqid();
        $preview_dir = $upload_dir['basedir'] . '/wp2id-previews/' . $preview_id;
        $preview_url_base = $upload_dir['baseurl'] . '/wp2id-previews/' . $preview_id;

        // Create preview directory
        if (!wp_mkdir_p($preview_dir)) {
            return array(
                'success' => false,
                'message' => 'Failed to create preview directory.'
            );
        }

        // Extract entire ZIP to preview directory
        $zip = new ZipArchive();
        if ($zip->open($zip_file_path) !== true) {
            return array(
                'success' => false,
                'message' => 'Failed to open template ZIP file.'
            );
        }

        // Extract all files
        $zip->extractTo($preview_dir);
        $zip->close();

        // Find the main HTML file (index.html or first HTML file)
        $main_html_file = self::find_main_html_file($preview_dir);
        if (!$main_html_file) {
            return array(
                'success' => false,
                'message' => 'No HTML template file found in ZIP.'
            );
        }

        // Get post mappings and apply content mapping to ALL HTML files
        $post_mappings = get_post_meta($publication_id, '_wp2id_post_mappings', true);
        if (!empty($post_mappings)) {
            self::process_all_html_files($preview_dir, $post_mappings, $post_ids, $template_id);
        }

        // Calculate the preview URL (get relative path from preview_dir)
        $relative_path = str_replace($preview_dir, '', $main_html_file);
        $relative_path = ltrim($relative_path, '/'); // Remove leading slash
        $preview_url = $preview_url_base . '/' . $relative_path;

        // Clean up old preview directories (keep only last 10)
        self::cleanup_old_previews($upload_dir['basedir'] . '/wp2id-previews');

        return array(
            'success' => true,
            'preview_url' => $preview_url,
            'preview_dir' => $preview_dir
        );
    }

    /**
     * Find the main HTML file in extracted directory
     * 
     * @param string $extract_dir Directory path to search
     * @return string|false Path to main HTML file or false if not found
     */
    private static function find_main_html_file($extract_dir)
    {
        // First, look for index.html
        $index_files = array('index.html', 'index.htm', 'main.html', 'default.html');
        
        foreach ($index_files as $index_file) {
            $full_path = $extract_dir . '/' . $index_file;
            if (file_exists($full_path)) {
                return $full_path;
            }
            
            // Also check in subdirectories using safe method
            $found_file = self::find_file_recursive($extract_dir, $index_file);
            if ($found_file) {
                return $found_file;
            }
        }

        // If no index file found, look for any HTML file using safe method
        return self::find_html_file_recursive($extract_dir);
    }

    /**
     * Process all HTML files in the preview directory with content replacement
     * 
     * @param string $preview_dir Base preview directory
     * @param array $post_mappings Post mappings configuration
     * @param array $post_ids Array of post IDs to include
     * @param int $template_id Template ID for tag system detection
     */
    private static function process_all_html_files($preview_dir, $post_mappings, $post_ids, $template_id)
    {
        if (class_exists('WP2ID_Debug')) {
            WP2ID_Debug::log("Processing all HTML files in directory: " . $preview_dir, 'Preview');
        }
        
        // Find all HTML files recursively
        $html_files = self::find_all_html_files_recursive($preview_dir);
        
        if (empty($html_files)) {
            if (class_exists('WP2ID_Debug')) {
                WP2ID_Debug::log("No HTML files found in preview directory", 'Preview');
            }
            return;
        }
        
        if (class_exists('WP2ID_Debug')) {
            WP2ID_Debug::log("Found " . count($html_files) . " HTML files to process", 'Preview');
        }
        
        // Process each HTML file
        foreach ($html_files as $html_file) {
            if (class_exists('WP2ID_Debug')) {
                WP2ID_Debug::log("Processing HTML file: " . $html_file, 'Preview');
            }
            
            try {
                $html_content = file_get_contents($html_file);
                if ($html_content === false) {
                    if (class_exists('WP2ID_Debug')) {
                        WP2ID_Debug::log("Failed to read HTML file: " . $html_file, 'Preview');
                    }
                    continue;
                }
                
                $mapped_html = WP2ID_Content_Utils::map_content_to_html_with_template($html_content, $post_mappings, $post_ids, $template_id);
                
                if (file_put_contents($html_file, $mapped_html) === false) {
                    if (class_exists('WP2ID_Debug')) {
                        WP2ID_Debug::log("Failed to write mapped content to: " . $html_file, 'Preview');
                    }
                } else {
                    if (class_exists('WP2ID_Debug')) {
                        WP2ID_Debug::log("Successfully processed: " . $html_file, 'Preview');
                    }
                }
                
            } catch (Exception $e) {
                if (class_exists('WP2ID_Debug')) {
                    WP2ID_Debug::log("Error processing HTML file '$html_file': " . $e->getMessage(), 'Preview');
                }
            }
        }
    }

    /**
     * Find all HTML files recursively in a directory
     * 
     * @param string $dir Directory to search in
     * @return array Array of full paths to HTML files
     */
    private static function find_all_html_files_recursive($dir)
    {
        $html_files = array();
        
        if (!is_dir($dir)) {
            return $html_files;
        }

        try {
            $files = array_diff(scandir($dir), array('.', '..'));
            
            foreach ($files as $file) {
                $path = $dir . DIRECTORY_SEPARATOR . $file;
                
                if (is_dir($path)) {
                    // Recursively search subdirectories
                    $subdirectory_files = self::find_all_html_files_recursive($path);
                    $html_files = array_merge($html_files, $subdirectory_files);
                } else {
                    // Check if it's an HTML file
                    $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                    if (in_array($extension, array('html', 'htm'))) {
                        $html_files[] = $path;
                    }
                }
            }
        } catch (Exception $e) {
            if (class_exists('WP2ID_Debug')) {
                WP2ID_Debug::log("Error searching for HTML files in '$dir': " . $e->getMessage(), 'Preview');
            }
        }
        
        return $html_files;
    }

    /**
     * Clean up old preview directories to prevent storage accumulation
     * 
     * @param string $previews_dir Base previews directory
     * @param int $keep_count Number of recent previews to keep
     */
    private static function cleanup_old_previews($previews_dir, $keep_count = 10)
    {
        if (!is_dir($previews_dir)) {
            return;
        }

        $preview_dirs = array();
        $iterator = new DirectoryIterator($previews_dir);
        
        foreach ($iterator as $dir) {
            if ($dir->isDot() || !$dir->isDir()) {
                continue;
            }
            
            if (strpos($dir->getFilename(), 'preview_') === 0) {
                $preview_dirs[] = array(
                    'path' => $dir->getPathname(),
                    'mtime' => $dir->getMTime()
                );
            }
        }

        // Sort by modification time (newest first)
        usort($preview_dirs, function($a, $b) {
            return $b['mtime'] - $a['mtime'];
        });

        // Remove old directories beyond the keep count
        for ($i = $keep_count; $i < count($preview_dirs); $i++) {
            self::recursive_rmdir($preview_dirs[$i]['path']);
        }
    }

    /**
     * Recursively remove directory and its contents
     * 
     * @param string $dir Directory path to remove
     */
    private static function recursive_rmdir($dir)
    {
        if (!is_dir($dir)) {
            return;
        }

        try {
            // Use a safer approach to avoid RecursiveDirectoryIterator issues
            self::safe_rmdir_recursive($dir);
        } catch (Exception $e) {
            // Log error but don't throw - cleanup should be non-blocking
            if (class_exists('WP2ID_Debug')) {
                WP2ID_Debug::log("Preview cleanup warning: " . $e->getMessage(), 'Preview');
            }
        }
    }

    /**
     * Safely remove directory recursively without RecursiveDirectoryIterator issues
     * 
     * @param string $dir Directory path to remove
     */
    private static function safe_rmdir_recursive($dir)
    {
        if (!is_dir($dir)) {
            return;
        }

        $files = array_diff(scandir($dir), array('.', '..'));
        
        foreach ($files as $file) {
            $path = $dir . DIRECTORY_SEPARATOR . $file;
            
            if (is_dir($path)) {
                self::safe_rmdir_recursive($path);
            } else {
                if (file_exists($path)) {
                    @unlink($path);
                }
            }
        }
        
        if (is_dir($dir)) {
            @rmdir($dir);
        }
    }

    /**
     * Safely find a file recursively without RecursiveDirectoryIterator issues
     * 
     * @param string $dir Directory to search in
     * @param string $filename Filename to search for
     * @return string|false Full path to file if found, false otherwise
     */
    private static function find_file_recursive($dir, $filename)
    {
        if (!is_dir($dir)) {
            return false;
        }

        try {
            $files = array_diff(scandir($dir), array('.', '..'));
            
            foreach ($files as $file) {
                $path = $dir . DIRECTORY_SEPARATOR . $file;
                
                if (is_dir($path)) {
                    $result = self::find_file_recursive($path, $filename);
                    if ($result) {
                        return $result;
                    }
                } else {
                    if (strtolower($file) === strtolower($filename)) {
                        return $path;
                    }
                }
            }
        } catch (Exception $e) {
            if (class_exists('WP2ID_Debug')) {
                WP2ID_Debug::log("Error searching for file '$filename' in '$dir': " . $e->getMessage(), 'Preview');
            }
        }
        
        return false;
    }

    /**
     * Safely find any HTML file recursively without RecursiveDirectoryIterator issues
     * 
     * @param string $dir Directory to search in
     * @return string|false Full path to first HTML file found, false otherwise
     */
    private static function find_html_file_recursive($dir)
    {
        if (!is_dir($dir)) {
            return false;
        }

        try {
            $files = array_diff(scandir($dir), array('.', '..'));
            
            foreach ($files as $file) {
                $path = $dir . DIRECTORY_SEPARATOR . $file;
                
                if (is_dir($path)) {
                    $result = self::find_html_file_recursive($path);
                    if ($result) {
                        return $result;
                    }
                } else {
                    $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                    if (in_array($extension, array('html', 'htm'))) {
                        return $path;
                    }
                }
            }
        } catch (Exception $e) {
            if (class_exists('WP2ID_Debug')) {
                WP2ID_Debug::log("Error searching for HTML files in '$dir': " . $e->getMessage(), 'Preview');
            }
        }
        
        return false;
    }
}
