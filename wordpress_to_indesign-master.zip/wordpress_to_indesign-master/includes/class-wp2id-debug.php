<?php
/**
 * Utility functions for debugging and logging.
 *
 * @since      1.0.0
 * @package    WP2ID
 * @subpackage WP2ID/includes
 */

if (!defined('WPINC')) {
    die;
}

/**
 * WP2ID Debugging functions
 */
class WP2ID_Debug {
    
    /**
     * Log a message to the WordPress debug log if debug logging is enabled
     *
     * @since    1.0.0
     * @param    mixed     $message   The message to log
     * @param    string    $prefix    Optional prefix for the log entry
     * @return   void
     */
    public static function log($message, $prefix = 'WP2ID') {
        // Check if our custom debug setting is enabled
        $options = get_option('wp2id_debug_settings');
        $is_logging_enabled = isset($options['enable_error_logs']) && $options['enable_error_logs'] === true;
        
        // Only log if our custom setting is enabled
        if ($is_logging_enabled) {
            // Format message for array/object types
            if (is_array($message) || is_object($message)) {
                $message = print_r($message, true);
            }
            
            // Add prefix for better identification in logs
            $log_message = "[{$prefix}] " . $message;
            
            // Use WordPress error_log function
            error_log($log_message);
        }
    }
}
