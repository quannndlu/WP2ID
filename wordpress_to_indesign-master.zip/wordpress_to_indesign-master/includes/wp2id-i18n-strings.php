<?php
/**
 * Define translatable strings used throughout the plugin.
 *
 * @since      1.0.0
 * @package    WP2ID
 * @subpackage WP2ID/includes
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Translatable string constants
 */
if ( ! defined( 'WP2ID_TEXT_DOMAIN' ) ) {
    define( 'WP2ID_TEXT_DOMAIN', 'wp2id' );
}

/**
 * Get a translatable string.
 *
 * @since    1.0.0
 * @param    string   $key    The string identifier.
 * @return   string   The translated string.
 */
function wp2id_get_string( $key ) {
    $strings = array(
        'general_settings'      => __( 'General Settings', 'wp2id' ),
        'advanced_settings'     => __( 'Advanced Settings', 'wp2id' ),
        'enable_feature'        => __( 'Enable Feature', 'wp2id' ),
        'settings_saved'        => __( 'Settings saved successfully.', 'wp2id' ),
        'settings_error'        => __( 'Error saving settings.', 'wp2id' ),
        'invalid_nonce'         => __( 'Security check failed. Please refresh the page and try again.', 'wp2id' ),
        'permission_denied'     => __( 'You do not have permission to perform this action.', 'wp2id' ),
        'something_went_wrong'  => __( 'Something went wrong. Please try again.', 'wp2id' ),
        'tag_system'            => __( 'Tag System', 'wp2id' ),
        'tag_based_system'      => __( 'Tag-Based System', 'wp2id' ),
        'custom_tag_system'     => __( 'Custom Tag #[Tag Name]#', 'wp2id' ),
    );
    
    return isset( $strings[ $key ] ) ? $strings[ $key ] : '';
}
