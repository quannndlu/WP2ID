<?php
/**
 * WP2ID HTML Preview Content Replacer
 *
 * This class handles replacing template content in HTML preview with WordPress content
 * while preserving InDesign's complex span structure and styling.
 *
 * @since      1.0.0
 * @package    WP2ID
 * @subpackage WP2ID/includes
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * HTML Preview Content Replacer Class
 *
 * Handles the complex task of replacing template content in HTML exports
 * with WordPress content while maintaining layout and styling integrity.
 *
 * @package    WP2ID
 * @subpackage WP2ID/includes
 */
class WP2ID_HTML_Preview {

    /**
     * The HTML content to process.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $html_content    The HTML content.
     */
    private $html_content;
    
    /**
     * DOM Document for HTML manipulation.
     *
     * @since    1.0.0
     * @access   private
     * @var      DOMDocument    $dom    DOM Document for HTML processing.
     */
    private $dom;
    
    /**
     * XPath object for DOM queries.
     *
     * @since    1.0.0
     * @access   private
     * @var      DOMXPath    $xpath    XPath object for complex queries.
     */
    private $xpath;
    
    /**
     * Template tag details for content mapping.
     *
     * @since    1.0.0
     * @access   private
     * @var      array    $template_tags    Template tag details from database.
     */
    private $template_tags;
    
    /**
     * Error messages.
     *
     * @since    1.0.0
     * @access   private
     * @var      array    $errors    Array of error messages.
     */
    private $errors = array();

    /**
     * Initialize the HTML preview processor.
     *
     * @since    1.0.0
     * @param    string    $html_content    The HTML content to process.
     * @param    array     $template_tags   Template tag details from get_template_tags_details_v2().
     */
    public function __construct( $html_content = '', $template_tags = array() ) {
        $this->html_content = $html_content;
        $this->template_tags = $template_tags;
        
        if ( ! empty( $html_content ) ) {
            $this->initialize_dom();
        }
    }
    
    /**
     * Initialize DOM document and XPath.
     *
     * @since    1.0.0
     * @access   private
     */
    private function initialize_dom() {
        $this->dom = new DOMDocument();
        libxml_use_internal_errors( true );
        
        // Load HTML with options to preserve structure
        $this->dom->loadHTML( 
            $this->html_content, 
            LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD 
        );
        
        libxml_clear_errors();
        $this->xpath = new DOMXPath( $this->dom );
    }
    
    /**
     * Replace template content with WordPress content.
     *
     * @since    1.0.0
     * @param    array     $content_mappings    Array of tag_name => wordpress_content mappings.
     * @return   string|false                   Modified HTML content or false on failure.
     */
    public function replace_content( $content_mappings ) {
        if ( empty( $this->dom ) ) {
            $this->errors[] = __( 'DOM not initialized. Please provide HTML content.', 'wp2id' );
            return false;
        }
        
        if ( empty( $content_mappings ) ) {
            $this->errors[] = __( 'No content mappings provided.', 'wp2id' );
            return false;
        }
        
        $replacement_count = 0;
        
        foreach ( $content_mappings as $tag_name => $wordpress_content ) {
            $replaced = $this->replace_tag_content( $tag_name, $wordpress_content );
            
            if ( $replaced ) {
                $replacement_count++;
            }
        }
        
        if ( $replacement_count > 0 ) {
            return $this->dom->saveHTML();
        } else {
            $this->errors[] = __( 'No content was replaced. Check tag mappings.', 'wp2id' );
            return false;
        }
    }
    
    /**
     * Replace content for a specific template tag.
     *
     * @since    1.0.0
     * @access   private
     * @param    string    $tag_name           Template tag name.
     * @param    string    $wordpress_content  WordPress content to insert.
     * @return   bool                          True if replacement successful, false otherwise.
     */
    private function replace_tag_content( $tag_name, $wordpress_content ) {
        // Strategy 1: Direct ID mapping
        $element = $this->find_element_by_id( $tag_name );
        
        if ( $element ) {
            return $this->update_element_content( $element, $wordpress_content, 'id_mapping' );
        }
        
        // Strategy 2: Class-based mapping
        $element = $this->find_element_by_class( $tag_name );
        
        if ( $element ) {
            return $this->update_element_content( $element, $wordpress_content, 'class_mapping' );
        }
        
        // Strategy 3: Content-based search
        $element = $this->find_element_by_content( $tag_name );
        
        if ( $element ) {
            return $this->update_element_content( $element, $wordpress_content, 'content_mapping' );
        }
        
        // Strategy 4: Fuzzy matching
        $element = $this->find_element_by_fuzzy_match( $tag_name );
        
        if ( $element ) {
            return $this->update_element_content( $element, $wordpress_content, 'fuzzy_mapping' );
        }
        
        // Log failure
        error_log( "WP2ID_HTML_Preview: Could not find element for tag '{$tag_name}'" );
        return false;
    }
    
    /**
     * Find element by exact ID match.
     *
     * @since    1.0.0
     * @access   private
     * @param    string    $tag_name    Template tag name.
     * @return   DOMElement|null        Found element or null.
     */
    private function find_element_by_id( $tag_name ) {
        $nodes = $this->xpath->query( "//*[@id='{$tag_name}']" );
        
        if ( $nodes->length > 0 ) {
            return $nodes->item( 0 );
        }
        
        return null;
    }
    
    /**
     * Find element by class name match.
     *
     * @since    1.0.0
     * @access   private
     * @param    string    $tag_name    Template tag name.
     * @return   DOMElement|null        Found element or null.
     */
    private function find_element_by_class( $tag_name ) {
        // Try exact class match first
        $nodes = $this->xpath->query( "//*[@class='{$tag_name}']" );
        
        if ( $nodes->length > 0 ) {
            return $nodes->item( 0 );
        }
        
        // Try partial class match
        $nodes = $this->xpath->query( "//*[contains(@class, '{$tag_name}')]" );
        
        if ( $nodes->length > 0 ) {
            return $nodes->item( 0 );
        }
        
        return null;
    }
    
    /**
     * Find element by content similarity.
     *
     * @since    1.0.0
     * @access   private
     * @param    string    $tag_name    Template tag name.
     * @return   DOMElement|null        Found element or null.
     */
    private function find_element_by_content( $tag_name ) {
        if ( empty( $this->template_tags[ $tag_name ] ) ) {
            return null;
        }
        
        $template_content = $this->template_tags[ $tag_name ]['content'] ?? '';
        
        if ( empty( $template_content ) ) {
            return null;
        }
        
        // Clean template content for comparison
        $search_content = $this->clean_content_for_search( $template_content );
        
        if ( strlen( $search_content ) < 10 ) {
            return null; // Too short for reliable matching
        }
        
        // Search in all text-containing elements
        $text_elements = $this->xpath->query( '//span[text()] | //div[text()] | //p[text()]' );
        
        foreach ( $text_elements as $element ) {
            $element_content = $this->clean_content_for_search( $element->textContent );
            
            // Check for content similarity
            if ( $this->calculate_content_similarity( $search_content, $element_content ) > 0.8 ) {
                return $element;
            }
        }
        
        return null;
    }
    
    /**
     * Find element by fuzzy matching (name patterns, structure).
     *
     * @since    1.0.0
     * @access   private
     * @param    string    $tag_name    Template tag name.
     * @return   DOMElement|null        Found element or null.
     */
    private function find_element_by_fuzzy_match( $tag_name ) {
        // Try variations of the tag name
        $variations = $this->generate_tag_variations( $tag_name );
        
        foreach ( $variations as $variation ) {
            // Try ID match with variation
            $element = $this->find_element_by_id( $variation );
            if ( $element ) {
                return $element;
            }
            
            // Try class match with variation
            $element = $this->find_element_by_class( $variation );
            if ( $element ) {
                return $element;
            }
        }
        
        return null;
    }
    
    /**
     * Update element content while preserving styling.
     *
     * @since    1.0.0
     * @access   private
     * @param    DOMElement    $element             Element to update.
     * @param    string        $new_content         New content to insert.
     * @param    string        $mapping_method      Method used to find element.
     * @return   bool                               True if update successful.
     */
    private function update_element_content( $element, $new_content, $mapping_method ) {
        try {
            // Check content length against template capacity
            $warning = $this->check_content_capacity( $element, $new_content );
            
            if ( $warning ) {
                error_log( "WP2ID_HTML_Preview: Content capacity warning - {$warning}" );
            }
            
            // Preserve styling by updating only text content
            if ( $this->has_child_elements( $element ) ) {
                // Complex element with child nodes - update text nodes only
                $this->update_text_nodes( $element, $new_content );
            } else {
                // Simple element - replace all content
                $element->textContent = $new_content;
            }
            
            // Log successful replacement
            error_log( "WP2ID_HTML_Preview: Replaced content using {$mapping_method} method" );
            
            return true;
            
        } catch ( Exception $e ) {
            error_log( "WP2ID_HTML_Preview: Error updating element content - " . $e->getMessage() );
            return false;
        }
    }
    
    /**
     * Check if new content exceeds template capacity.
     *
     * @since    1.0.0
     * @access   private
     * @param    DOMElement    $element        Element being updated.
     * @param    string        $new_content    New content to check.
     * @return   string|null                   Warning message or null if OK.
     */
    private function check_content_capacity( $element, $new_content ) {
        $element_id = $element->getAttribute( 'id' );
        $element_class = $element->getAttribute( 'class' );
        
        // Try to find matching template tag
        $tag_name = $element_id ?: $element_class;
        
        if ( ! empty( $tag_name ) && isset( $this->template_tags[ $tag_name ] ) ) {
            $template_capacity = $this->template_tags[ $tag_name ]['length'] ?? 0;
            $new_content_length = strlen( $new_content );
            
            if ( $new_content_length > $template_capacity && $template_capacity > 0 ) {
                return "Content length ({$new_content_length}) exceeds template capacity ({$template_capacity}) for tag '{$tag_name}'";
            }
        }
        
        return null;
    }
    
    /**
     * Check if element has child elements.
     *
     * @since    1.0.0
     * @access   private
     * @param    DOMElement    $element    Element to check.
     * @return   bool                      True if has child elements.
     */
    private function has_child_elements( $element ) {
        foreach ( $element->childNodes as $child ) {
            if ( $child->nodeType === XML_ELEMENT_NODE ) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Update only text nodes in an element with child elements.
     *
     * @since    1.0.0
     * @access   private
     * @param    DOMElement    $element       Element to update.
     * @param    string        $new_content   New content to insert.
     */
    private function update_text_nodes( $element, $new_content ) {
        // Find all text nodes
        $text_nodes = [];
        
        foreach ( $element->childNodes as $child ) {
            if ( $child->nodeType === XML_TEXT_NODE && trim( $child->textContent ) !== '' ) {
                $text_nodes[] = $child;
            }
        }
        
        if ( empty( $text_nodes ) ) {
            // No text nodes found, create one
            $text_node = $this->dom->createTextNode( $new_content );
            $element->appendChild( $text_node );
        } else {
            // Replace first text node, remove others
            $text_nodes[0]->textContent = $new_content;
            
            for ( $i = 1; $i < count( $text_nodes ); $i++ ) {
                $element->removeChild( $text_nodes[ $i ] );
            }
        }
    }
    
    /**
     * Clean content for search comparison.
     *
     * @since    1.0.0
     * @access   private
     * @param    string    $content    Content to clean.
     * @return   string                Cleaned content.
     */
    private function clean_content_for_search( $content ) {
        // Remove HTML tags
        $content = strip_tags( $content );
        
        // Normalize whitespace
        $content = preg_replace( '/\s+/', ' ', $content );
        
        // Trim and convert to lowercase
        return strtolower( trim( $content ) );
    }
    
    /**
     * Calculate content similarity between two strings.
     *
     * @since    1.0.0
     * @access   private
     * @param    string    $content1    First content string.
     * @param    string    $content2    Second content string.
     * @return   float                  Similarity ratio (0-1).
     */
    private function calculate_content_similarity( $content1, $content2 ) {
        if ( empty( $content1 ) || empty( $content2 ) ) {
            return 0;
        }
        
        // Use similar_text for basic similarity
        similar_text( $content1, $content2, $percent );
        
        return $percent / 100;
    }
    
    /**
     * Generate tag name variations for fuzzy matching.
     *
     * @since    1.0.0
     * @access   private
     * @param    string    $tag_name    Original tag name.
     * @return   array                  Array of tag name variations.
     */
    private function generate_tag_variations( $tag_name ) {
        $variations = [];
        
        // Original name
        $variations[] = $tag_name;
        
        // Lowercase
        $variations[] = strtolower( $tag_name );
        
        // Uppercase
        $variations[] = strtoupper( $tag_name );
        
        // Snake case to camel case
        if ( strpos( $tag_name, '_' ) !== false ) {
            $camel_case = lcfirst( str_replace( ' ', '', ucwords( str_replace( '_', ' ', $tag_name ) ) ) );
            $variations[] = $camel_case;
        }
        
        // Camel case to snake case
        if ( preg_match( '/[A-Z]/', $tag_name ) ) {
            $snake_case = strtolower( preg_replace( '/([A-Z])/', '_$1', $tag_name ) );
            $variations[] = ltrim( $snake_case, '_' );
        }
        
        // Remove duplicates
        return array_unique( $variations );
    }
    
    /**
     * Get the last error message.
     *
     * @since    1.0.0
     * @return   string    Last error message or empty string if no errors.
     */
    public function get_last_error() {
        return empty( $this->errors ) ? '' : end( $this->errors );
    }
    
    /**
     * Get all error messages.
     *
     * @since    1.0.0
     * @return   array    Array of error messages.
     */
    public function get_errors() {
        return $this->errors;
    }
    
    /**
     * Get content replacement statistics.
     *
     * @since    1.0.0
     * @param    array     $content_mappings    Content mappings used.
     * @return   array                          Statistics about the replacement process.
     */
    public function get_replacement_statistics( $content_mappings ) {
        $stats = [
            'total_mappings' => count( $content_mappings ),
            'successful_replacements' => 0,
            'failed_replacements' => 0,
            'capacity_warnings' => 0,
            'mapping_methods' => []
        ];
        
        // This would be called after replacement to gather statistics
        // Implementation would track success/failure during actual replacement
        
        return $stats;
    }
}
