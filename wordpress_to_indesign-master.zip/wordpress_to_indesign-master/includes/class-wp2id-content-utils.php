<?php

/**
 * Content Replacement Utilities
 *
 * @link       https://yourwebsite.com
 * @since      1.0.0
 *
 * @package    WP2ID
 * @subpackage WP2ID/includes
 */

/**
 * Content Replacement Utility Functions
 *
 * This class contains utility methods for handling content replacement and mapping
 * within the WordPress to InDesign export process.
 *
 * @package    WP2ID
 * @subpackage WP2ID/includes
 * @author     Hoàng Bách <tinhp.wk@gmail.com>
 */
class WP2ID_Content_Utils
{

    /**
     * Map WordPress content to HTML placeholders with template support
     * 
     * @param string $html_content Original HTML content
     * @param array $post_mappings Post mappings configuration
     * @param array $post_ids Array of post IDs to include
     * @param int $template_id Template ID for tag system detection
     * @return string Modified HTML with WordPress content
     */
    public static function map_content_to_html_with_template($html_content, $post_mappings, $post_ids, $template_id)
    {
        // Get template tags for placeholder identification
        $template_tags = get_post_meta($template_id, '_wp2id_template_tags', true);
        
        if (empty($template_tags)) {
            return $html_content; // Return original if no tags
        }

        // Deserialize if needed
        if (is_serialized($template_tags)) {
            $template_tags = maybe_unserialize($template_tags);
        }

        // Get template tag system
        $template_tag_system = get_post_meta($template_id, '_wp2id_template_tag_system', true);
        if (empty($template_tag_system)) {
            $template_tag_system = 'tag-based'; // Default to tag-based system only
        }
        
        // Ensure only tag-based system is used
        if ($template_tag_system !== 'tag-based') {
            error_log('WARNING: Content Utils only supports tag-based system, forcing tag-based for template: ' . $template_id);
            $template_tag_system = 'tag-based';
        }

        if (class_exists('WP2ID_Debug')) {
            WP2ID_Debug::log("Starting HTML content mapping for " . count($post_ids) . " posts", 'Preview');
        }

        $modified_html = $html_content;

        // Process each mapped post
        foreach ($post_ids as $post_id) {
            if (!isset($post_mappings[$post_id])) {
                continue;
            }

            $post = get_post($post_id);
            if (!$post) {
                continue;
            }

            // ...existing code...
            
            $mappings = $post_mappings[$post_id];

            // Map each content type
            foreach ($mappings as $content_type => $tag_mapping) {

                // Handle different mapping structures
                if (is_array($tag_mapping)) {
                    // Check if this is a content array with multiple mappings (new format)
                    if ($content_type === 'content' && isset($tag_mapping[0]) && is_array($tag_mapping[0])) {
                        // Handle content with positions - process each individual mapping
                        foreach ($tag_mapping as $individual_mapping) {
                            $tag_name = $individual_mapping['tag'] ?? '';
                            $replacement_content = '';
                            
                            // Get content based on positions if specified
                            $content = $post->post_content;
                            
                            // Check if we have valid start/end positions
                            $has_start = isset($individual_mapping['start']) && $individual_mapping['start'] !== '';
                            $has_end = isset($individual_mapping['end']) && $individual_mapping['end'] !== '';
                            
                            if ($has_start && $has_end) {
                                $start = intval($individual_mapping['start']);
                                $end = intval($individual_mapping['end']);
                                
                                if ($start >= 0 && $end > $start) {
                                    // Extract content slice
                                    $raw_content_slice = substr($content, $start, $end - $start);
                                    
                                    // Clean up the content slice
                                    $replacement_content = wp_strip_all_tags($raw_content_slice);
                                    
                                    // Remove extra whitespace and normalize
                                    $replacement_content = preg_replace('/\s+/', ' ', $replacement_content);
                                    $replacement_content = trim($replacement_content);
                                } else {
                                    // Clean and use full content
                                    $replacement_content = wp_strip_all_tags($content);
                                    $replacement_content = preg_replace('/\s+/', ' ', $replacement_content);
                                    $replacement_content = trim($replacement_content);
                                }
                            } else if ($has_start && !$has_end) {
                                // Start position only - take from start to end of content
                                $start = intval($individual_mapping['start']);
                                $raw_content_slice = substr($content, $start);
                                $replacement_content = wp_strip_all_tags($raw_content_slice);
                                $replacement_content = preg_replace('/\s+/', ' ', $replacement_content);
                                $replacement_content = trim($replacement_content);
                            } else {
                                // No valid positions - use full content  
                                $replacement_content = wp_strip_all_tags($content);
                                $replacement_content = preg_replace('/\s+/', ' ', $replacement_content);
                                $replacement_content = trim($replacement_content);
                            }
                            
                            // Process this individual tag replacement immediately
                            if ($replacement_content && $tag_name) {
                                $modified_html = self::replace_content_in_html($modified_html, $tag_name, $replacement_content, $template_tag_system);
                            }
                        }
                        // Continue to next mapping since we processed all content mappings
                        continue;
                    } else {
                        // Regular array mapping (old format)
                        $tag_name = $tag_mapping['tag'] ?? '';
                        $replacement_content = '';
                    }
                } else {
                    // Direct tag name (string)
                    $tag_name = $tag_mapping;
                    $replacement_content = '';
                }

                // Get content based on type (skip if we already processed content above)
                if ($content_type !== 'content' || empty($replacement_content)) {
                    switch ($content_type) {
                        case 'title':
                            $replacement_content = esc_html($post->post_title);
                            break;
                            
                        case 'content':
                            $content = $post->post_content;
                            // Handle content positions if specified (legacy format)
                            if (isset($tag_mapping['positions']) && is_array($tag_mapping['positions'])) {
                                $replacement_content = '';
                                foreach ($tag_mapping['positions'] as $position) {
                                    if (isset($position['start_pos']) && isset($position['end_pos'])) {
                                        $start = intval($position['start_pos']);
                                        $end = intval($position['end_pos']);
                                        if ($start >= 0 && $end > $start) {
                                            $content_slice = substr($content, $start, $end - $start);
                                            $clean_slice = wp_strip_all_tags($content_slice);
                                            $replacement_content .= trim($clean_slice) . ' ';
                                        }
                                    }
                                }
                                // Clean up final content
                                $replacement_content = preg_replace('/\s+/', ' ', trim($replacement_content));
                            } else {
                                // Clean and normalize full content
                                $replacement_content = wp_strip_all_tags($content);
                                $replacement_content = preg_replace('/\s+/', ' ', $replacement_content);
                                $replacement_content = trim($replacement_content);
                            }
                            break;
                        
                        case 'excerpt':
                            $replacement_content = $post->post_excerpt ?: wp_trim_excerpt('', $post);
                            break;
                            
                        case 'author':
                            $author = get_userdata($post->post_author);
                            $replacement_content = $author ? esc_html($author->display_name) : '';
                            break;
                            
                        case 'date':
                            $replacement_content = get_the_date('', $post);
                            break;
                            
                        case 'category':
                            $categories = get_the_category($post->ID);
                            if ($categories) {
                                $category_names = array_map(function($cat) { return $cat->name; }, $categories);
                                $replacement_content = implode(', ', $category_names);
                            }
                            break;
                            
                        case 'image':
                            if (has_post_thumbnail($post->ID)) {
                                $replacement_content = get_the_post_thumbnail($post->ID, 'medium');
                            }
                            break;
                    }
                }

                // Replace placeholder in HTML using the appropriate tag system
                if ($replacement_content && $tag_name) {
                    // Special handling for image content type
                    if ($content_type === 'image') {
                        // Find and replace entire <img> tags that have alt attribute containing the tag name
                        $img_patterns = array(
                            '/<img[^>]*alt[^>]*' . preg_quote($tag_name, '/') . '[^>]*>/i',
                            '/<img[^>]*title[^>]*' . preg_quote($tag_name, '/') . '[^>]*>/i'
                        );
                        
                        foreach ($img_patterns as $pattern) {
                            if (preg_match($pattern, $modified_html)) {
                                $modified_html = preg_replace($pattern, $replacement_content, $modified_html);
                                break;
                            }
                        }
                        
                    } else {
                        // Use helper method for text replacement
                        $modified_html = self::replace_content_in_html($modified_html, $tag_name, $replacement_content, $template_tag_system);
                    }
                } else {
                }
            }
        }

        return $modified_html;
    }

    /**
     * Process stories with content mappings
     * 
     * @param array $designmap IDML designmap data
     * @param array $post_mappings Post mappings data
     * @param string $idml_extract_dir IDML extraction directory
     * @param string $images_dir Images directory path
     * @param array &$media_files Media files array (passed by reference)
     * @param string $template_tag_system Template tag system (only 'tag-based' supported)
     * @param string $folder_name Name of the export folder/ZIP archive
     * @return array Result array with success status
     */
    public static function process_stories_with_mappings($designmap, $post_mappings, $idml_extract_dir, $images_dir, &$media_files, $template_tag_system = 'tag-based', $folder_name = '')
    {
        // Ensure only tag-based system is used
        if ($template_tag_system !== 'tag-based') {
            error_log('WARNING: process_stories_with_mappings only supports tag-based system, forcing tag-based');
            $template_tag_system = 'tag-based';
        }
        
        if (class_exists('WP2ID_Debug')) {
            WP2ID_Debug::log('Starting story processing for ' . count($post_mappings) . ' mapped posts using tag-based system', 'IDML_Export');
        }
        
        // First, identify which stories contain tags that match our mappings
        $mapped_tags = array();
        foreach ($post_mappings as $post_id => $post_data) {
            foreach ($post_data as $field => $tag_name) {
                if (is_array($tag_name)) {
                    // Handle array case (e.g., content mapping)
                    foreach ($tag_name as $content_mapping) {
                        if (isset($content_mapping['tag'])) {
                            $mapped_tags[] = $content_mapping['tag'];
                        }
                    }
                } else if (is_string($tag_name)) {
                    $mapped_tags[] = $tag_name;
                }
            }
        }
        $mapped_tags = array_unique($mapped_tags);

        // Find stories that contain tags matching our mappings (XMLElement patterns only)
        $target_stories = array();
        foreach ($designmap['stories'] as $story_id => $story_info) {
            $story_path = $story_info['src'];
            $full_story_path = $idml_extract_dir . '/' . $story_path;

            if (!file_exists($full_story_path)) {
                continue;
            }

            $story_xml = file_get_contents($full_story_path);
            if (!$story_xml) {
                continue;
            }

            // For tag-based system, look for XMLElement patterns
            foreach ($mapped_tags as $tag) {
                $search_pattern = 'MarkupTag="XMLTag/' . $tag . '"';
                $found = strpos($story_xml, $search_pattern);

                if ($found !== false) {
                    $target_stories[$story_id] = $story_info;
                    break; // Found at least one matching tag, no need to check others
                }
            }
        }

        if (class_exists('WP2ID_Debug')) {
            WP2ID_Debug::log('Processing ' . count($target_stories) . ' stories with matching tags', 'IDML_Export');
        }

        // Process only the target stories
        foreach ($target_stories as $story_id => $story_info) {
            $story_path = $story_info['src'];
            $full_story_path = $idml_extract_dir . '/' . $story_path;

            // Load the story XML file directly
            $story_xml = file_get_contents($full_story_path);
            if (!$story_xml) {
                continue;
            }

            // Process the story XML using the utility class - make sure we're passing a string
            try {
                $modified_content = WP2ID_IDML_Utils::process_story_content($story_xml, $post_mappings, $images_dir, $media_files, $idml_extract_dir, $template_tag_system, $folder_name);

                // Save the modified story file
                if ($modified_content !== false) {
                    file_put_contents($full_story_path, $modified_content);
                }
            } catch (Exception $e) {
                // Continue with other stories even if one fails
            }
        }

        return array('success' => true);
    }

    /**
     * Process template image replacements in spread files based on post mappings
     * This method follows the mapping structure to determine which images need replacement
     *
     * @param string $idml_extract_dir The IDML extraction directory path
     * @param array $media_files Array of media files that were processed
     * @param string $export_folder_name Name of the export folder
     * @param array $post_mappings Post mappings structure from wp2id_post_mappings
     * @return void
     */
    public static function process_template_image_replacements($idml_extract_dir, $media_files, $export_folder_name, $post_mappings = array())
    {
        if (class_exists('WP2ID_Debug')) {
            WP2ID_Debug::log('Starting template image replacement process', 'IDML_Export');
        }
        
        // Check if we have any media files to work with
        if (empty($media_files)) {
            return;
        }

        // Check if we have post mappings to work with
        if (empty($post_mappings)) {
            return;
        }

        // Extract image tag names from mappings according to flow documentation
        $image_tag_names = array();
        foreach ($post_mappings as $post_id => $post_data) {
            if (isset($post_data['image']) && !empty($post_data['image'])) {
                $image_tag_name = $post_data['image'];
                if (!in_array($image_tag_name, $image_tag_names)) {
                    $image_tag_names[] = $image_tag_name;
                }
            }
        }

        if (empty($image_tag_names)) {
            return;
        }

        // For each image tag found in mappings, try to find and replace it
        foreach ($image_tag_names as $tag_name) {
            // Find spreads that contain elements with this tag
            if (self::template_image_exists_in_spreads($idml_extract_dir, $tag_name)) {
                // Get the corresponding standardized image filename from media_files
                $replacement_image = self::get_replacement_image_by_tag($media_files, $tag_name);
                
                if ($replacement_image) {
                    // Update URI in spread files
                    WP2ID_IDML_Utils::update_spread_image_links($idml_extract_dir, $tag_name, $replacement_image);
                    
                    // Update URI in Links.xml if it exists, create if it doesn't
                    WP2ID_IDML_Utils::update_links_xml($replacement_image, $idml_extract_dir);
                    
                    // Update URI in BackingStory.xml if it exists, create if it doesn't
                    WP2ID_IDML_Utils::replace_tag_in_backing_story($tag_name, $replacement_image, $idml_extract_dir);
                }
            }
        }
    }

    /**
     * Check if a template image exists in any spread files
     *
     * @param string $idml_extract_dir The IDML extraction directory path
     * @param string $template_name Template image name to search for
     * @return bool True if template image is found, false otherwise
     */
    private static function template_image_exists_in_spreads($idml_extract_dir, $template_name)
    {
        $spreads_dir = $idml_extract_dir . '/Spreads';
        
        if (!is_dir($spreads_dir)) {
            return false;
        }

        $spread_files = glob($spreads_dir . '/Spread_*.xml');
        
        foreach ($spread_files as $spread_file) {
            $spread_content = file_get_contents($spread_file);
            if ($spread_content && strpos($spread_content, $template_name) !== false) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * Get the replacement image filename that corresponds to a specific tag name
     * This looks for standardized filenames that match the tag name pattern
     *
     * @param array $media_files Array of media files
     * @param string $tag_name The tag name to find corresponding image for
     * @return string|null Basename of replacement image or null if none found
     */
    private static function get_replacement_image_by_tag($media_files, $tag_name)
    {
        if (empty($media_files) || empty($tag_name)) {
            return null;
        }

        // Look for standardized filename that matches the tag name
        foreach ($media_files as $source_path => $destination_path) {
            $filename = basename($destination_path);
            $name_without_ext = pathinfo($filename, PATHINFO_FILENAME);
            
            // Check if the filename (without extension) matches the tag name
            if ($name_without_ext === $tag_name) {
                return $filename;
            }
        }
        
        // Fallback: return the first available media file if no exact match found
        if (!empty($media_files)) {
            $first_media_file = reset($media_files);
            return basename($first_media_file);
        }

        return null;
    }

    /**
     * Replace content in HTML using tag-based system
     * 
     * @param string $html_content HTML content to modify
     * @param string $tag_name Tag name to replace
     * @param string $replacement_content Content to replace with
     * @param string $template_tag_system Template tag system (only 'tag-based' supported)
     * @return string Modified HTML content
     */
    private static function replace_content_in_html($html_content, $tag_name, $replacement_content, $template_tag_system)
    {
        // Only support tag-based system - replace standard placeholder tags
        $search_patterns = array(
            '{{' . $tag_name . '}}',
            '{' . $tag_name . '}',
            '[' . $tag_name . ']'
        );
        
        foreach ($search_patterns as $pattern) {
            $html_content = str_replace($pattern, $replacement_content, $html_content);
        }
        
        return $html_content;
    }
}
