<?php
/**
 * Plugin utility functions.
 *
 * @since      1.0.0
 * @package    WP2ID
 * @subpackage WP2ID/includes
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Utility class for the plugin.
 */
class WP2ID_Utilities {

    /**
     * Get plugin settings with defaults.
     *
     * @since    1.0.0
     * @return   array    Plugin settings.
     */
    public static function get_settings() {
        $defaults = array(
            'enable_feature' => 0
        );
        
        $settings = get_option( 'wp2id_settings', array() );
        
        return wp_parse_args( $settings, $defaults );
    }

    /**
     * Get a specific plugin setting.
     *
     * @since    1.0.0
     * @param    string   $key        The setting key.
     * @param    mixed    $default    Default value if setting doesn't exist.
     * @return   mixed    The setting value.
     */
    public static function get_setting( $key, $default = false ) {
        $settings = self::get_settings();
        
        return isset( $settings[$key] ) ? $settings[$key] : $default;
    }

    /**
     * Log message to debug file if debugging is enabled.
     *
     * @since    1.0.0
     * @param    mixed    $message    The message to log.
     * @return   void
     */
    public static function log( $message ) {
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            if ( is_array( $message ) || is_object( $message ) ) {
                error_log( print_r( $message, true ) );
            } else {
                error_log( $message );
            }
        }
    }

    /**
     * Get asset URL.
     *
     * @since    1.0.0
     * @param    string   $path       Path to the asset.
     * @return   string   Full URL to the asset.
     */
    public static function get_asset_url( $path ) {
        return plugin_dir_url( dirname( __FILE__ ) ) . 'assets/' . $path;
    }

    /**
     * Format date according to WordPress settings.
     *
     * @since    1.0.0
     * @param    string   $date       The date to format.
     * @param    string   $format     The format to use (optional).
     * @return   string   Formatted date.
     */
    public static function format_date( $date, $format = '' ) {
        if ( empty( $format ) ) {
            $format = get_option( 'date_format' );
        }
        
        return date_i18n( $format, strtotime( $date ) );
    }
}
