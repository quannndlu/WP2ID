<?php
/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * @since      1.0.0
 * @package    WP2ID
 * @subpackage WP2ID/includes
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * The core plugin class.
 */
class WP2ID {

    /**
     * The loader that's responsible for maintaining and registering all hooks.
     *
     * @since    1.0.0
     * @access   protected
     * @var      WP2ID_Loader    $loader    Maintains and registers all hooks for the plugin.
     */
    protected $loader;

    /**
     * The unique identifier of this plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string    $plugin_name    The string used to uniquely identify this plugin.
     */
    protected $plugin_name;

    /**
     * The current version of the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string    $version    The current version of the plugin.
     */
    protected $version;

    /**
     * Define the core functionality of the plugin.
     *
     * @since    1.0.0
     */
    public function __construct() {
        if ( defined( 'WP2ID_VERSION' ) ) {
            $this->version = WP2ID_VERSION;
        } else {
            $this->version = '1.0.2';
        }
        $this->plugin_name = 'wp2id';

        $this->load_dependencies();
        $this->set_locale();
        $this->define_admin_hooks();
        $this->define_public_hooks();
    }

    /**
     * Load the required dependencies for this plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function load_dependencies() {

        /**
         * The class responsible for orchestrating the actions and filters of the
         * core plugin.
         */
        require_once WP2ID_PLUGIN_DIR . 'includes/class-wp2id-loader.php';

        /**
         * The class responsible for defining internationalization functionality
         * of the plugin.
         */
        require_once WP2ID_PLUGIN_DIR . 'includes/class-wp2id-i18n.php';

        /**
         * The class responsible for defining all actions that occur in the admin area.
         */
        require_once WP2ID_PLUGIN_DIR . 'admin/class-wp2id-admin.php';

        /**
         * The class responsible for defining all actions that occur in the public-facing
         * side of the site.
         */
        require_once WP2ID_PLUGIN_DIR . 'public/class-wp2id-public.php';

        /**
         * The class providing security utilities.
         */
        
        /**
         * The class responsible for debugging utilities.
         */
        require_once WP2ID_PLUGIN_DIR . 'includes/class-wp2id-debug.php';
        require_once WP2ID_PLUGIN_DIR . 'includes/class-wp2id-security.php';

        /**
         * The class providing general utilities.
         */
        require_once WP2ID_PLUGIN_DIR . 'includes/class-wp2id-utilities.php';
        
        /**
         * The class for managing user permissions.
         */
        require_once WP2ID_PLUGIN_DIR . 'includes/class-wp2id-permission-manager.php';
        
        /**
         * The class for handling settings page.
         */
        require_once WP2ID_PLUGIN_DIR . 'admin/class-wp2id-settings.php';
        
        /**
         * The class for handling template custom post type.
         */
        require_once WP2ID_PLUGIN_DIR . 'admin/class-wp2id-template.php';
        
        /**
         * The class for reading IDML files.
         */
        require_once WP2ID_PLUGIN_DIR . 'includes/class-wp2id-idml-reader.php';
        
        /**
         * The class for handling IDML templates.
         */
        require_once WP2ID_PLUGIN_DIR . 'includes/class-wp2id-idml-template.php';

        /**
         * The class for handling publication custom post type.
         */
        require_once WP2ID_PLUGIN_DIR . 'admin/class-wp2id-publication.php';

        $this->loader = new WP2ID_Loader();
    }

    /**
     * Define the locale for this plugin for internationalization.
     *
     * @since    1.0.0
     * @access   private
     */
    private function set_locale() {
        $plugin_i18n = new WP2ID_i18n();

        $this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );
    }

    /**
     * Register all of the hooks related to the admin area functionality
     * of the plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_admin_hooks() {
        $plugin_admin = new WP2ID_Admin( $this->get_plugin_name(), $this->get_version() );

        $this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
        $this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );
        
        // Register AJAX handler for tag extraction
        $this->loader->add_action( 'wp_ajax_wp2id_extract_tags', $plugin_admin, 'ajax_extract_tags' );
        
        // Initialize Template custom post type
        $plugin_template = new WP2ID_Template( $this->get_plugin_name(), $this->get_version() );
        
        // Register the Custom Post Type
        $this->loader->add_action( 'init', $plugin_template, 'register_cpt_template' );
        
        // Register metaboxes
        $this->loader->add_action( 'add_meta_boxes', $plugin_template, 'register_template_metaboxes' );
        
        // Save metabox data
        $this->loader->add_action( 'save_post', $plugin_template, 'save_template_metabox' );
        
        // Add custom columns to admin list table
        $this->loader->add_filter( 'manage_wp2id-template_posts_columns', $plugin_template, 'set_custom_template_columns' );
        $this->loader->add_action( 'manage_wp2id-template_posts_custom_column', $plugin_template, 'custom_template_column_content', 10, 2 );
        
        // Add filter to prevent file type check for IDML files
        $this->loader->add_filter( 'wp_check_filetype_and_ext', $plugin_template, 'disable_file_type_check', 10, 5 );

        // Initialize Publication custom post type
        $plugin_publication = new WP2ID_Publication( $this->get_plugin_name(), $this->get_version() );
        
        // Register the Publication Custom Post Type
        $this->loader->add_action( 'init', $plugin_publication, 'register_cpt_publication' );
        
        // Register metaboxes
        $this->loader->add_action( 'add_meta_boxes', $plugin_publication, 'register_publication_metaboxes' );
        
        // Save metabox data
        $this->loader->add_action( 'save_post', $plugin_publication, 'save_publication_metaboxes', 10, 2 );
        
        // Register AJAX handlers
        $this->loader->add_action( 'wp_ajax_wp2id_search_posts', $plugin_publication, 'ajax_search_posts' );
        $this->loader->add_action( 'wp_ajax_wp2id_get_post', $plugin_publication, 'ajax_get_post' );
        $this->loader->add_action( 'wp_ajax_wp2id_get_post_details', $plugin_publication, 'ajax_get_post_details' );

        // Initialize Settings page
        $plugin_settings = new WP2ID_Settings( $this->get_plugin_name(), $this->get_version() );
        
        // Register settings page
        $this->loader->add_action( 'admin_menu', $plugin_settings, 'register_settings_page' );
        
        // Register settings
        $this->loader->add_action( 'admin_init', $plugin_settings, 'register_settings' );
        
        // Enqueue settings styles
        $this->loader->add_action( 'admin_enqueue_scripts', $plugin_settings, 'enqueue_admin_styles' );

        // Initialize Permission Manager
        $permission_manager = new WP2ID_Permission_Manager();
    }

    /**
     * Register all of the hooks related to the public-facing functionality
     * of the plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_public_hooks() {
        $plugin_public = new WP2ID_Public( $this->get_plugin_name(), $this->get_version() );

        $this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
        $this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );
    }

    /**
     * Run the loader to execute all of the hooks with WordPress.
     *
     * @since    1.0.0
     */
    public function run() {
        $this->loader->run();
    }

    /**
     * The name of the plugin used to uniquely identify it within the context of
     * WordPress and to define internationalization functionality.
     *
     * @since     1.0.0
     * @return    string    The name of the plugin.
     */
    public function get_plugin_name() {
        return $this->plugin_name;
    }

    /**
     * The reference to the class that orchestrates the hooks with the plugin.
     *
     * @since     1.0.0
     * @return    WP2ID_Loader    Orchestrates the hooks of the plugin.
     */
    public function get_loader() {
        return $this->loader;
    }

    /**
     * Retrieve the version number of the plugin.
     *
     * @since     1.0.0
     * @return    string    The version number of the plugin.
     */
    public function get_version() {
        return $this->version;
    }
}
