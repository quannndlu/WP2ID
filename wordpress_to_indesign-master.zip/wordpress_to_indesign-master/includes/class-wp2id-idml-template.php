<?php
/**
 * IDML Template Handler Class
 *
 * This class handles IDML templates for the WP2ID plugin.
 *
 * @since      1.0.0
 * @package    WP2ID
 * @subpackage WP2ID/includes
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * IDML Template Handler Class
 *
 * This class provides methods for working with IDML templates in WordPress,
 * including retrieving template information and generating content based on templates.
 *
 * @package    WP2ID
 * @subpackage WP2ID/includes
 */
class WP2ID_IDML_Template {

    /**
     * The ID of the template post.
     *
     * @since    1.0.0
     * @access   private
     * @var      int    $template_id    The ID of the template post.
     */
    private $template_id;
    
    /**
     * The path to the IDML file.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $idml_path    The path to the IDML file.
     */
    private $idml_path;
    
    /**
     * The path to the ZIP file (if available).
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $zip_path    The path to the ZIP file.
     */
    private $zip_path;
    
    /**
     * The IDML reader instance.
     *
     * @since    1.0.0
     * @access   private
     * @var      WP2ID_IDML_Reader    $reader    The IDML reader instance.
     */
    private $reader;
    
    /**
     * Error messages.
     *
     * @since    1.0.0
     * @access   private
     * @var      array    $errors    Array of error messages.
     */
    private $errors = array();

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param    int      $template_id    The ID of the template post.
     */
    public function __construct( $template_id = null ) {
        if ( $template_id ) {
            $this->set_template( $template_id );
        }
    }
    
    /**
     * Set the template by ID.
     *
     * @since    1.0.0
     * @param    int      $template_id    The ID of the template post.
     * @return   bool                    True on success, false on failure.
     */
    public function set_template( $template_id ) {
        // Check if the template post exists and is of the correct post type
        $post = get_post( $template_id );
        
        if ( ! $post || $post->post_type !== 'wp2id-template' ) {
            $this->errors[] = sprintf( __( 'Invalid template ID: %d', 'wp2id' ), $template_id );
            return false;
        }
        
        $this->template_id = $template_id;
        
        // Get the IDML file
        $idml_file_id = get_post_meta( $template_id, '_wp2id_template_idml_file', true );
        if ( ! $idml_file_id ) {
            $this->errors[] = sprintf( __( 'No IDML file associated with template ID: %d', 'wp2id' ), $template_id );
            return false;
        }
        
        $idml_file_path = get_attached_file( $idml_file_id );
        if ( ! $idml_file_path || ! file_exists( $idml_file_path ) ) {
            $this->errors[] = sprintf( __( 'IDML file not found for template ID: %d', 'wp2id' ), $template_id );
            return false;
        }
        
        $this->idml_path = $idml_file_path;
        
        // Get the ZIP file (if available)
        $zip_file_id = get_post_meta( $template_id, '_wp2id_template_zip_file', true );
        if ( $zip_file_id ) {
            $zip_file_path = get_attached_file( $zip_file_id );
            if ( $zip_file_path && file_exists( $zip_file_path ) ) {
                $this->zip_path = $zip_file_path;
            }
        }
        
        return true;
    }
    
    /**
     * Alias of set_template for backward compatibility
     *
     * @since    1.0.0
     * @param    int      $template_id    The ID of the template post.
     * @return   bool                    True on success, false on failure.
     */
    public function set_template_id( $template_id ) {
        return $this->set_template( $template_id );
    }
    
    /**
     * Get the last error message.
     *
     * @since    1.0.0
     * @return   string    The last error message.
     */
    public function get_last_error() {
        return end( $this->errors );
    }
    
    /**
     * Get all error messages.
     *
     * @since    1.0.0
     * @return   array    All error messages.
     */
    public function get_all_errors() {
        return $this->errors;
    }
    
    /**
     * Get the template structure using the IDML reader.
     *
     * @since    1.0.0
     * @return   array|bool    Array of template structure or false on failure.
     */
    public function get_template_structure() {
        if ( ! $this->idml_path ) {
            $this->errors[] = __( 'No IDML file path set.', 'wp2id' );
            return false;
        }
        
        // Load the IDML reader class
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wp2id-idml-reader.php';
        
        // Create a new instance of the IDML reader
        $this->reader = new WP2ID_IDML_Reader( $this->idml_path );
        
        // Extract the IDML file
        if ( ! $this->reader->extract() ) {
            $this->errors[] = $this->reader->get_last_error();
            return false;
        }
        
        // Read the designmap (main structure of the document)
        $designmap = $this->reader->read_designmap();
        if ( ! $designmap ) {
            $this->errors[] = $this->reader->get_last_error();
            $this->reader->cleanup();
            return false;
        }
        
        // Read styles
        $styles = $this->reader->read_styles();
        if ( ! $styles ) {
            $this->errors[] = $this->reader->get_last_error();
            $this->reader->cleanup();
            return false;
        }
        
        // Clean up temporary files
        $this->reader->cleanup();
        
        return array(
            'designmap' => $designmap,
            'styles' => $styles,
        );
    }
    
    /**
     * Get the template metadata.
     *
     * @since    1.0.0
     * @return   array|bool    Array of template metadata or false on failure.
     */
    public function get_template_metadata() {
        if ( ! $this->idml_path ) {
            $this->errors[] = __( 'No IDML file path set.', 'wp2id' );
            return false;
        }
        
        // Load the IDML reader class if not already loaded
        if ( ! class_exists( 'WP2ID_IDML_Reader' ) ) {
            require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wp2id-idml-reader.php';
        }
        
        // Create a new instance of the IDML reader
        $reader = new WP2ID_IDML_Reader( $this->idml_path );
        
        // Extract the IDML file
        if ( ! $reader->extract() ) {
            $this->errors[] = $reader->get_last_error();
            return false;
        }
        
        // Read metadata
        $metadata = $reader->read_metadata();
        if ( ! $metadata ) {
            $this->errors[] = $reader->get_last_error();
            $reader->cleanup();
            return false;
        }
        
        // Clean up temporary files
        $reader->cleanup();
        
        return $metadata;
    }
    
    /**
     * Get template stories.
     *
     * @since    1.0.0
     * @return   array|bool    Array of template stories or false on failure.
     */
    public function get_template_stories() {
        if ( ! $this->idml_path ) {
            $this->errors[] = __( 'No IDML file path set.', 'wp2id' );
            return false;
        }
        
        // Load the IDML reader class if not already loaded
        if ( ! class_exists( 'WP2ID_IDML_Reader' ) ) {
            require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wp2id-idml-reader.php';
        }
        
        // Create a new instance of the IDML reader
        $reader = new WP2ID_IDML_Reader( $this->idml_path );
        
        // Extract the IDML file
        if ( ! $reader->extract() ) {
            $this->errors[] = $reader->get_last_error();
            return false;
        }
        
        // Read the designmap
        $reader->read_designmap();
        
        // Read all stories
        $stories = $reader->read_all_stories();
        if ( ! $stories ) {
            $this->errors[] = $reader->get_last_error();
            $reader->cleanup();
            return false;
        }
        
        // Clean up temporary files
        $reader->cleanup();
        
        return $stories;
    }
    
    /**
     * Get the template styles.
     *
     * @since    1.0.0
     * @return   array|bool    Array of template styles or false on failure.
     */
    public function get_template_styles() {
        if ( ! $this->idml_path ) {
            $this->errors[] = __( 'No IDML file path set.', 'wp2id' );
            return false;
        }
        
        // Load the IDML reader class if not already loaded
        if ( ! class_exists( 'WP2ID_IDML_Reader' ) ) {
            require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wp2id-idml-reader.php';
        }
        
        // Create a new instance of the IDML reader
        $reader = new WP2ID_IDML_Reader( $this->idml_path );
        
        // Extract the IDML file
        if ( ! $reader->extract() ) {
            $this->errors[] = $reader->get_last_error();
            return false;
        }
        
        // Read styles
        $styles = $reader->read_styles();
        if ( ! $styles ) {
            $this->errors[] = $reader->get_last_error();
            $reader->cleanup();
            return false;
        }
        
        // Clean up temporary files
        $reader->cleanup();
        
        return $styles;
    }
    
    /**
     * Get a list of available templates.
     *
     * @since    1.0.0
     * @param    array    $args    Arguments to pass to WP_Query.
     * @return   array             Array of template information.
     */
    public static function get_available_templates( $args = array() ) {
        $default_args = array(
            'post_type' => 'wp2id-template',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'orderby' => 'title',
            'order' => 'ASC',
        );
        
        $args = wp_parse_args( $args, $default_args );
        
        $templates = array();
        $query = new WP_Query( $args );
        
        if ( $query->have_posts() ) {
            while ( $query->have_posts() ) {
                $query->the_post();
                
                $template_id = get_the_ID();
                $idml_file_id = get_post_meta( $template_id, '_wp2id_template_idml_file', true );
                $zip_file_id = get_post_meta( $template_id, '_wp2id_template_zip_file', true );
                
                $templates[] = array(
                    'id' => $template_id,
                    'title' => get_the_title(),
                    'date' => get_the_date(),
                    'author' => get_the_author_meta( 'display_name' ),
                    'idml_file_id' => $idml_file_id,
                    'idml_file_name' => $idml_file_id ? basename( get_attached_file( $idml_file_id ) ) : '',
                    'idml_file_url' => $idml_file_id ? wp_get_attachment_url( $idml_file_id ) : '',
                    'zip_file_id' => $zip_file_id,
                    'zip_file_name' => $zip_file_id ? basename( get_attached_file( $zip_file_id ) ) : '',
                    'zip_file_url' => $zip_file_id ? wp_get_attachment_url( $zip_file_id ) : '',
                );
            }
        }
        
        wp_reset_postdata();
        
        return $templates;
    }
    
    /**
     * Create a new template.
     *
     * @since    1.0.0
     * @param    string    $title       The template title.
     * @param    int       $idml_file_id The ID of the IDML file attachment.
     * @param    int       $zip_file_id  The ID of the ZIP file attachment (optional).
     * @return   int|WP_Error           The template ID or WP_Error on failure.
     */
    public static function create_template( $title, $idml_file_id, $zip_file_id = null ) {
        // Check if the IDML file exists
        if ( ! get_post( $idml_file_id ) || get_post_type( $idml_file_id ) !== 'attachment' ) {
            return new WP_Error( 'invalid_idml', __( 'Invalid IDML file ID.', 'wp2id' ) );
        }
        
        // Check if the ZIP file exists (if provided)
        if ( $zip_file_id && ( ! get_post( $zip_file_id ) || get_post_type( $zip_file_id ) !== 'attachment' ) ) {
            return new WP_Error( 'invalid_zip', __( 'Invalid ZIP file ID.', 'wp2id' ) );
        }
        
        // Create a new template post
        $template_id = wp_insert_post( array(
            'post_title' => $title,
            'post_type' => 'wp2id-template',
            'post_status' => 'publish',
        ) );
        
        if ( is_wp_error( $template_id ) ) {
            return $template_id;
        }
        
        // Save the IDML file ID
        update_post_meta( $template_id, '_wp2id_template_idml_file', $idml_file_id );
        
        // Save the ZIP file ID (if provided)
        if ( $zip_file_id ) {
            update_post_meta( $template_id, '_wp2id_template_zip_file', $zip_file_id );
        }
        
        return $template_id;
    }
    
    /**
     * Extract custom tags from the IDML template based on the selected tag system.
     * After extraction, tags are saved to the database.
     *
     * @since    1.0.0
     * @param    bool      $save_to_db     Whether to save extracted tags to the database.
     * @return   array|bool                Array of extracted tags or false on failure.
     */
    public function extract_template_tags( $save_to_db = true ) {
        error_log( __METHOD__ . ' called' );
        if ( ! $this->idml_path ) {
            $this->errors[] = __( 'No IDML file path set.', 'wp2id' );
            return false;
        }
        
        // Load the IDML reader class if not already loaded
        if ( ! class_exists( 'WP2ID_IDML_Reader' ) ) {
            require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wp2id-idml-reader.php';
        }
        
        // Create a new instance of the IDML reader if not already created
        if ( ! isset( $this->reader ) ) {
            $this->reader = new WP2ID_IDML_Reader( $this->idml_path );
        }
        
        // Extract the IDML file
        if ( ! $this->reader->extract() ) {
            $this->errors[] = $this->reader->get_last_error();
            return false;
        }
        error_log( 'IDML file extracted successfully' );
        // Read all stories from the IDML document
        $stories = $this->reader->read_all_stories();
        if ( ! $stories ) {
            $this->errors[] = $this->reader->get_last_error();
            $this->reader->cleanup();
            return false;
        }
        
        // Get the tag system setting
        $tag_system = get_post_meta( $this->template_id, '_wp2id_template_tag_system', true );
        if ( empty( $tag_system ) ) {
            $tag_system = 'tag-based'; // Default to tag-based system
        }
        error_log( 'Using tag system: ' . $tag_system );
        
        // Read all spreads from the IDML document (for images with alt text)
        $spreads = $this->reader->read_all_spreads();
        if ( ! $spreads ) {
            error_log( 'No spreads found or error reading spreads' );
            // Continue anyway, we can still extract tags from stories
        } else {
            error_log( 'Found ' . count( $spreads ) . ' spreads in the IDML document' );
        }
        
        error_log('Starting tag extraction with ' . $tag_system . ' system for template ID: ' . $this->template_id);
        
        // Extract custom tags based on the selected tag system
        $start_time = microtime(true);
        $tags = $this->reader->extract_custom_tags( $stories, $tag_system, $spreads );
        $extraction_time = microtime(true) - $start_time;
        
        error_log('Tag extraction completed in ' . round($extraction_time, 2) . ' seconds');
        
        // Phase 2: Extract detailed tag information
        $detailed_start_time = microtime(true);
        $detailed_tags = $this->reader->extract_custom_tags_detailed( $stories, $tag_system, $spreads );
        $detailed_extraction_time = microtime(true) - $detailed_start_time;
        
        error_log('Detailed tag extraction completed in ' . round($detailed_extraction_time, 2) . ' seconds');
        
        // Clean up temporary files
        $this->reader->cleanup();
        
        // Save tags to database if requested
        if ( $save_to_db && $this->template_id ) {
            // Clear existing data first
            delete_post_meta( $this->template_id, '_wp2id_template_tags' );
            delete_post_meta( $this->template_id, '_wp2id_template_tags_details' );
            
            // Simplified storage: Save all detailed tags
            if ( !empty( $detailed_tags ) ) {
                // Save detailed tags information (complete tag details)
                update_post_meta( $this->template_id, '_wp2id_template_tags_details', $detailed_tags );
                error_log( 'Saved ' . count( $detailed_tags ) . ' detailed tags to _wp2id_template_tags_details for template ' . $this->template_id );
                
                // Create basic tags list from detailed tags (for backward compatibility)
                update_post_meta( $this->template_id, '_wp2id_template_tags', $tags );
                error_log( 'Saved ' . count( $tags ) . ' tag names to _wp2id_template_tags for template ' . $this->template_id );
                
            } else {
                error_log('WARNING: No detailed tags were found to save to database!');
            }
        }
        
        
        // Return the basic tags list (array of meaningful tag names) if save_to_db is true
        // Or return filtered tags if save_to_db is false (for backwards compatibility)
        if ( $save_to_db ) {
            // For database saves, return the basic tags list that was saved
            $saved_basic_tags = get_post_meta( $this->template_id, '_wp2id_template_tags', true );
            return is_array( $saved_basic_tags ) ? $saved_basic_tags : array();
        } else {
            // For non-database calls, return the filtered basic tags (no IDs)
            $filtered_tags = array();
            if ( !empty( $tags ) ) {
                foreach ( $tags as $tag_name ) {
                    if ( !preg_match('/^di2i[a-z0-9]+$/i', $tag_name) ) {
                        $filtered_tags[] = $tag_name;
                    }
                }
            }
            return $filtered_tags;
        }
    }
    
    /**
     * Get template tags from the database.
     * 
     * This method retrieves the saved tag names without re-extracting them from the IDML file.
     * If no tags are found in the database and $extract_if_empty is true, it will extract them.
     *
     * @since    1.0.0
     * @param    bool      $extract_if_empty    Whether to extract tags if none found in database.
     * @return   array                          Array of template tag names (simple array of strings).
     */
    public function get_template_tags( $extract_if_empty = true ) {
        if ( ! $this->template_id ) {
            $this->errors[] = __( 'No template ID set.', 'wp2id' );
            return array();
        }
        
        // Get basic tags list from database (should be array of strings)
        $tags = get_post_meta( $this->template_id, '_wp2id_template_tags', true );
        
        // If no tags found and extraction is requested, extract them
        if ( empty( $tags ) && $extract_if_empty ) {
            // Extract templates which will populate both basic and detailed tags
            $extraction_result = $this->extract_template_tags( true );
            
            if ( $extraction_result !== false ) {
                // Re-get the basic tags that should now be saved
                $tags = get_post_meta( $this->template_id, '_wp2id_template_tags', true );
            } else {
                return array();
            }
        }
        
        // Ensure we return an array of strings (tag names only)
        return is_array( $tags ) ? $tags : array();
    }
    
    /**
     * Get detailed template tags information.
     * 
     * This method retrieves the detailed tag information including content length,
     * type, and actual content from the database.
     *
     * @since    1.0.0
     * @param    bool      $extract_if_empty    Whether to extract tags if none found in database.
     * @return   array                          Array of detailed template tags information.
     */
    public function get_template_tags_details_v2( $extract_if_empty = true ) {
        if ( ! $this->template_id ) {
            $this->errors[] = __( 'No template ID set.', 'wp2id' );
            return array();
        }
        
        // Get detailed tags from database
        $detailed_tags = get_post_meta( $this->template_id, '_wp2id_template_tags_details', true );
        
        // If no detailed tags found and extraction is requested, extract them
        if ( empty( $detailed_tags ) && $extract_if_empty ) {
            error_log( 'No detailed tags found in database, triggering extraction for template ' . $this->template_id );
            
            // Trigger full extraction which will save both basic and detailed tags
            $extraction_result = $this->extract_template_tags( true );
            
            if ( $extraction_result !== false ) {
                // Get the detailed tags that should now be saved
                $detailed_tags = get_post_meta( $this->template_id, '_wp2id_template_tags_details', true );
                error_log( 'After extraction, found ' . count( $detailed_tags ) . ' detailed tags' );
            } else {
                error_log( 'Failed to extract template tags: ' . $this->get_last_error() );
                return array();
            }
        }
        
        return is_array( $detailed_tags ) ? $detailed_tags : array();
    }
}
