<?php

/**
 * IDML and ZIP Utilities
 *
 * @link       https://yourwebsite.com
 * @since      1.0.0
 *
 * @package    WP2ID
 * @subpackage WP2ID/includes
 */

/**
 * IDML and ZIP Utility Functions
 *
 * This class contains utility methods for handling IDML files and ZIP operations
 * within the WordPress to InDesign export process.
 *
 * @package    WP2ID
 * @subpackage WP2ID/includes
 * @author     Hoàng Bách <tinhp.wk@gmail.com>
 */
class WP2ID_IDML_Utils
{

    /**
     * Create a ZIP archive from a directory (moved to WP2ID_ZIP_Utils)
     * 
     * @deprecated Use WP2ID_ZIP_Utils::zip_directory() instead
     * @param string $source_dir Directory to zip
     * @param string $destination Path to save the ZIP file
     * @return boolean True if successful, false otherwise
     */
    public static function zip_directory($source_dir, $destination)
    {
        return WP2ID_ZIP_Utils::zip_directory($source_dir, $destination);
    }

    /**
     * Clean up temporary files from export process
     * 
     * @param string $dir Directory to remove
     * @return boolean True on success, false on failure
     */
    public static function cleanup_export_temp_files($dir)
    {
        if (!is_dir($dir)) {
            error_log('Not a directory or directory does not exist: ' . $dir);
            return false;
        }

        try {
            $it = new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS);
            $files = new RecursiveIteratorIterator($it, RecursiveIteratorIterator::CHILD_FIRST);

            foreach ($files as $file) {
                try {
                    if ($file->isDir()) {
                        rmdir($file->getPathname());
                    } else {
                        unlink($file->getPathname());
                    }
                } catch (Exception $e) {
                    error_log('Failed to remove file: ' . $file->getPathname() . ' - ' . $e->getMessage());
                }
            }

            return rmdir($dir);
        } catch (Exception $e) {
            error_log('Failed to clean up directory: ' . $dir . ' - ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Construct image URL for InDesign
     * 
     * @param string $filename The image filename or path
     * @param string $folder_name Optional. Kept for backward compatibility but not used
     * @return string The constructed relative file URL
     */
    public static function construct_image_url($filename, $folder_name = '')
    {
        // If filename already has file:// or http prefix, return as-is
        if (strpos($filename, 'file://') === 0 || strpos($filename, 'http') === 0) {
            // Log for debugging
            if (class_exists('WP2ID_Debug')) {
                WP2ID_Debug::log("Image URL already formatted, returning as-is: {$filename}", 'ImagePathConverter');
            }
            return $filename;
        }

        // Clean the filename - remove any path separators and get just the basename
        $clean_filename = basename($filename);

        // Use relative path: file:///images/filename.jpg
        $relative_path = 'file:///images/' . $clean_filename;

        // Include debug logging for troubleshooting
        if (class_exists('WP2ID_Debug')) {
            WP2ID_Debug::log("Generated relative image path: {$relative_path}", 'ImagePathConverter');
        }

        return $relative_path;
    }

    /**
     * Format WordPress content for InDesign
     * 
     * @param string $content Raw WordPress content
     * @return string Formatted content for InDesign
     */
    public static function format_content_for_indesign($content)
    {
        // Ensure content is a string
        if (!is_string($content)) {
            if (is_array($content) || is_object($content)) {
                $content = json_encode($content);
            } elseif ($content === null) {
                $content = '';
            } else {
                $content = (string)$content;
            }
        }

        // Strip shortcodes
        $content = strip_shortcodes($content);

        // Apply filters to allow other plugins to modify content
        $content = apply_filters('wp2id_pre_format_content', $content);

        // Handle common WordPress formatting elements
        $content = str_replace(
            ['<h1>', '<h2>', '<h3>', '<h4>', '<h5>', '<h6>'],
            [
                '<ParaStyle:Heading 1>',
                '<ParaStyle:Heading 2>',
                '<ParaStyle:Heading 3>',
                '<ParaStyle:Heading 4>',
                '<ParaStyle:Heading 5>',
                '<ParaStyle:Heading 6>'
            ],
            $content
        );
        $content = str_replace(['</h1>', '</h2>', '</h3>', '</h4>', '</h5>', '</h6>'], "\r", $content);

        // Convert paragraph and line breaks to InDesign-friendly format
        $content = str_replace('<p>', '<ParaStyle:Body Text>', $content);
        $content = str_replace('</p>', "\r", $content);
        $content = str_replace(['<br>', '<br />'], "\r", $content);

        // Handle lists
        $content = str_replace('<ul>', "", $content);
        $content = str_replace('</ul>', "\r", $content);
        $content = str_replace('<ol>', "", $content);
        $content = str_replace('</ol>', "\r", $content);
        $content = str_replace('<li>', '<ParaStyle:Bullet>• ', $content);
        $content = str_replace('</li>', "\r", $content);

        // Handle basic formatting
        $content = str_replace(['<strong>', '<b>'], '<CharStyle:Bold>', $content);
        $content = str_replace(['</strong>', '</b>'], '<CharStyle:>', $content);
        $content = str_replace(['<em>', '<i>'], '<CharStyle:Italic>', $content);
        $content = str_replace(['</em>', '</i>'], '<CharStyle:>', $content);

        // Strip remaining HTML tags
        $content = strip_tags($content);

        // Apply post-processing filter
        $content = apply_filters('wp2id_post_format_content', $content);

        return $content;
    }

    /**
     * Process story content and replace tags with actual content
     * 
     * @param string|array $content The story XML content or array with story data
     * @param array $mappings The post mappings data
     * @param string $images_dir Directory to store images
     * @param array &$media_files Array to track media files
     * @param string $idml_extract_dir IDML extract directory path
     * @param string $template_tag_system Template tag system (only 'tag-based' is supported)
     * @param string $folder_name Name of the export folder/ZIP archive
     * @return string|false Modified content or false on failure
     */
    public static function process_story_content($content, $mappings, $images_dir, &$media_files, $idml_extract_dir, $template_tag_system = 'tag-based', $folder_name = '')
    {
        // Add debugging to track content type and mappings
        WP2ID_Debug::log('process_story_content called - content type: ' . gettype($content), 'IDML_Export');
        WP2ID_Debug::log('process_story_content - mappings count: ' . count($mappings), 'IDML_Export');
        WP2ID_Debug::log('process_story_content - using tag system: ' . $template_tag_system, 'IDML_Export');

        // Only support tag-based system
        if ($template_tag_system !== 'tag-based') {
            error_log('WARNING: IDML Utils only supports tag-based system, forcing tag-based. Received: ' . $template_tag_system);
            $template_tag_system = 'tag-based';
        }

        if (empty($content)) {
            WP2ID_Debug::log('process_story_content - empty content', 'IDML_Export');
            return false;
        }

        // Content should be the raw IDML story XML string
        if (!is_string($content)) {
            WP2ID_Debug::log('process_story_content - content is not a string: ' . gettype($content), 'IDML_Export');
            return false;
        }

        // Load the IDML story XML content directly
        try {
            $doc = new DOMDocument();
            $doc->preserveWhiteSpace = false;
            $doc->formatOutput = true;

            // Load the XML content - this should be a complete IDML story document
            $load_result = $doc->loadXML($content);

            if (!$load_result) {
                WP2ID_Debug::log('Failed to load XML content. Content preview: ' . substr($content, 0, 200), 'IDML_Export');
                return false;
            }

            WP2ID_Debug::log('Successfully loaded XML document. Root element: ' . $doc->documentElement->nodeName, 'IDML_Export');

            // Create XPath object for querying
            $xpath = new DOMXPath($doc);

            // Register namespaces used in IDML
            $xpath->registerNamespace('idPkg', 'http://ns.adobe.com/AdobeInDesign/idml/1.0/packaging');

            // Process each mapping - handle the correct structure
            foreach ($mappings as $post_id => $post_mappings) {
                // Skip if no post ID or invalid structure
                if (empty($post_id) || !is_array($post_mappings)) {
                    continue;
                }

                $post = get_post($post_id);
                if (!$post) {
                    continue;
                }

                WP2ID_Debug::log("Processing mappings for post ID: {$post_id}", 'IDML_Export');

                // Process each field mapping for this post
                foreach ($post_mappings as $field => $tag_name) {
                    if (empty($tag_name)) {
                        continue;
                    }

                    WP2ID_Debug::log("Processing field '{$field}' with tag_name: " . (is_array($tag_name) ? 'ARRAY(' . print_r($tag_name, true) . ')' : $tag_name), 'IDML_Export');

                    // Get the content based on field type
                    $replacement_content = '';

                    WP2ID_Debug::log("About to process field: '{$field}' for tag: " . (is_array($tag_name) ? 'ARRAY(' . print_r($tag_name, true) . ')' : $tag_name), 'IDML_Export');

                    try {
                        switch ($field) {
                            case 'title':
                                $replacement_content = $post->post_title;
                                WP2ID_Debug::log("Got title content for '" . (is_array($tag_name) ? 'ARRAY' : $tag_name) . "': " . substr($replacement_content, 0, 100), 'IDML_Export');
                                break;

                            case 'content':
                                // Handle content array structure or direct content
                                if (is_array($tag_name)) {
                                    // Content has multiple tag mappings with start/end positions
                                    $raw_content = self::format_content_for_indesign($post->post_content);
                                    $content_length = strlen($raw_content);

                                    foreach ($tag_name as $content_mapping) {
                                        if (isset($content_mapping['tag'])) {
                                            $content_tag = $content_mapping['tag'];

                                            // Handle start/end positions with defaults
                                            $start_pos = 0;
                                            $end_pos = $content_length;

                                            if (isset($content_mapping['start']) && $content_mapping['start'] !== '') {
                                                $start_pos = max(0, intval($content_mapping['start']));
                                            }

                                            if (isset($content_mapping['end']) && $content_mapping['end'] !== '') {
                                                $end_pos = min($content_length, intval($content_mapping['end']));
                                            }

                                            // Ensure end is not less than start
                                            if ($end_pos < $start_pos) {
                                                $end_pos = $start_pos;
                                            }

                                            // Extract content slice
                                            $slice_length = $end_pos - $start_pos;
                                            $content_slice = substr($raw_content, $start_pos, $slice_length);

                                            // Clean up the content
                                            $content_replacement = trim($content_slice);
                                            $content_replacement = preg_replace('/\s+/', ' ', $content_replacement);

                                            WP2ID_Debug::log("Content mapping for tag '{$content_tag}': start={$start_pos}, end={$end_pos}, slice_length={$slice_length}, content: " . substr($content_replacement, 0, 100) . "...", 'IDML_Export');

                                            self::replace_tag_in_story($doc, $xpath, $content_tag, $content_replacement, $template_tag_system, $folder_name, $idml_extract_dir);
                                        }
                                    }
                                    continue 2; // Skip the main replacement since we handled it above
                                } else {
                                    $replacement_content = self::format_content_for_indesign($post->post_content);
                                    WP2ID_Debug::log("Got content for tag: " . (is_array($tag_name) ? 'ARRAY' : $tag_name) . ": " . substr($replacement_content, 0, 100) . "...", 'IDML_Export');
                                }
                                break;

                            case 'excerpt':
                                $replacement_content = $post->post_excerpt ? $post->post_excerpt : wp_trim_excerpt('', $post);
                                WP2ID_Debug::log("Got excerpt content for '" . (is_array($tag_name) ? 'ARRAY' : $tag_name) . "': " . substr($replacement_content, 0, 100), 'IDML_Export');
                                break;

                            case 'date':
                            case 'post_date':
                                WP2ID_Debug::log("Processing date field - post_date: {$post->post_date}", 'IDML_Export');
                                $date_format = get_option('date_format');
                                WP2ID_Debug::log("WordPress date format: {$date_format}", 'IDML_Export');
                                $timestamp = strtotime($post->post_date);
                                WP2ID_Debug::log("Converted timestamp: {$timestamp}", 'IDML_Export');
                                $replacement_content = date_i18n($date_format, $timestamp);
                                WP2ID_Debug::log("Got date content for '" . (is_array($tag_name) ? 'ARRAY' : $tag_name) . "': " . $replacement_content, 'IDML_Export');
                                break;

                            case 'author':
                            case 'post_author':
                                WP2ID_Debug::log("Processing author field - post_author ID: {$post->post_author}", 'IDML_Export');
                                $author = get_userdata($post->post_author);
                                if ($author) {
                                    WP2ID_Debug::log("Found author object - display_name: {$author->display_name}, user_login: {$author->user_login}", 'IDML_Export');
                                    $replacement_content = $author->display_name;
                                } else {
                                    WP2ID_Debug::log("Author not found for ID: {$post->post_author}", 'IDML_Export');
                                    $replacement_content = '';
                                }
                                WP2ID_Debug::log("Got author content for '" . (is_array($tag_name) ? 'ARRAY' : $tag_name) . "': " . $replacement_content, 'IDML_Export');
                                break;

                            case 'category':
                            case 'categories':
                                $categories = get_the_category($post->ID);
                                $cat_names = array();
                                foreach ($categories as $category) {
                                    $cat_names[] = $category->name;
                                }
                                $replacement_content = implode(', ', $cat_names);
                                WP2ID_Debug::log("Got category content for '" . (is_array($tag_name) ? 'ARRAY' : $tag_name) . "': " . $replacement_content, 'IDML_Export');
                                break;

                            case 'tags':
                            case 'post_tags':
                                $tags = get_the_tags($post->ID);
                                $tag_names = array();
                                if ($tags) {
                                    foreach ($tags as $tag) {
                                        $tag_names[] = $tag->name;
                                    }
                                }
                                $replacement_content = implode(', ', $tag_names);
                                WP2ID_Debug::log("Got tags content for '" . (is_array($tag_name) ? 'ARRAY' : $tag_name) . "': " . $replacement_content, 'IDML_Export');
                                break;

                            case 'slug':
                            case 'post_name':
                                $replacement_content = $post->post_name;
                                WP2ID_Debug::log("Got slug content for '" . (is_array($tag_name) ? 'ARRAY' : $tag_name) . "': " . $replacement_content, 'IDML_Export');
                                break;

                            case 'url':
                            case 'permalink':
                                $replacement_content = get_permalink($post->ID);
                                WP2ID_Debug::log("Got URL content for '" . (is_array($tag_name) ? 'ARRAY' : $tag_name) . "': " . $replacement_content, 'IDML_Export');
                                break;

                            case 'image':
                            case 'featured_image':
                                WP2ID_Debug::log("=== PROCESSING IMAGE FIELD WITH STANDARDIZED NAMING ===", 'IDML_Export');

                                $featured_image_id = get_post_thumbnail_id($post_id);
                                if ($featured_image_id) {
                                    $attachment_path = get_attached_file($featured_image_id);
                                    if ($attachment_path && file_exists($attachment_path)) {
                                        // Get original file extension
                                        $original_extension = pathinfo($attachment_path, PATHINFO_EXTENSION);
                                        $original_filename = basename($attachment_path);

                                        // Use tag name as filename instead of original filename
                                        $tag_for_filename = is_array($tag_name) ? 'array_tag' : $tag_name;
                                        $standardized_filename = sanitize_file_name($tag_for_filename) . '.' . $original_extension;
                                        $image_file = $images_dir . '/' . $standardized_filename;

                                        // Copy with new standardized filename
                                        if (copy($attachment_path, $image_file)) {
                                            // Track this media file with standardized name
                                            $media_files[$attachment_path] = $image_file;

                                            WP2ID_Debug::log("Successfully renamed image from '{$original_filename}' to '{$standardized_filename}' based on tag name '" . (is_array($tag_name) ? 'ARRAY' : $tag_name) . "'", 'IDML_Export');

                                            // For images, use the standardized filename for replacement
                                            $replacement_content = $standardized_filename;
                                        } else {
                                            WP2ID_Debug::log("Failed to copy image file from '{$attachment_path}' to '{$image_file}'", 'IDML_Export');
                                            // Fall back to original filename
                                            $replacement_content = basename($attachment_path);
                                        }
                                    } else {
                                        WP2ID_Debug::log("No featured image found for post ID: {$post_id}", 'IDML_Export');
                                        $replacement_content = '';
                                    }
                                } else {
                                    WP2ID_Debug::log("No featured image ID found for post ID: {$post_id}", 'IDML_Export');
                                    $replacement_content = '';
                                }
                                break;

                            default:
                                // For custom fields with meta_ prefix
                                if (strpos($field, 'meta_') === 0) {
                                    $meta_key = substr($field, 5);
                                    $replacement_content = get_post_meta($post_id, $meta_key, true);
                                    WP2ID_Debug::log("Got meta field '{$meta_key}' content for '" . (is_array($tag_name) ? 'ARRAY' : $tag_name) . "': " . substr($replacement_content, 0, 100), 'IDML_Export');
                                } else {
                                    // Unhandled field type - log it for debugging
                                    WP2ID_Debug::log("UNHANDLED FIELD TYPE: '{$field}' for tag '" . (is_array($tag_name) ? 'ARRAY' : $tag_name) . "'. Consider adding support for this field.", 'IDML_Export');

                                    // Try to get it as a post property if it exists
                                    if (property_exists($post, $field)) {
                                        $replacement_content = $post->$field;
                                        WP2ID_Debug::log("Found as post property '{$field}': " . substr($replacement_content, 0, 100), 'IDML_Export');
                                    } else {
                                        // Try as a meta field without meta_ prefix
                                        $replacement_content = get_post_meta($post_id, $field, true);
                                        if (!empty($replacement_content)) {
                                            WP2ID_Debug::log("Found as meta field '{$field}': " . substr($replacement_content, 0, 100), 'IDML_Export');
                                        }
                                    }
                                }
                                break;
                        }

                        WP2ID_Debug::log("After processing field '{$field}': replacement_content = '" . $replacement_content . "' (length: " . strlen($replacement_content) . ")", 'IDML_Export');
                    } catch (Exception $e) {
                        WP2ID_Debug::log("ERROR processing field '{$field}' for tag '" . (is_array($tag_name) ? 'ARRAY' : $tag_name) . "': " . $e->getMessage(), 'IDML_Export');
                        $replacement_content = '';
                    }

                    // Find tag in content and replace it (if not already handled above)
                    if (!empty($replacement_content) && is_string($tag_name)) {
                        WP2ID_Debug::log("=== CALLING replace_tag_in_story for '{$tag_name}' ===", 'IDML_Export');
                        self::replace_tag_in_story($doc, $xpath, $tag_name, $replacement_content, $template_tag_system, $folder_name, $idml_extract_dir);

                        // For image tags, also check BackingStory.xml and update spread files
                        WP2ID_Debug::log("=== TESTING IMAGE DETECTION FOR: '{$tag_name}' ===", 'IDML_Export');
                        $is_image_tag = (stripos($tag_name, 'image') !== false
                            || stripos($tag_name, 'feature') !== false
                            || stripos($tag_name, 'img') !== false
                            || stripos($tag_name, 'thumbnail') !== false
                            || stripos($tag_name, 'Img') !== false);
                        WP2ID_Debug::log("Checking if '{$tag_name}' is image tag - contains 'image': " . (stripos($tag_name, 'image') !== false ? 'YES' : 'NO') . ", contains 'feature': " . (stripos($tag_name, 'feature') !== false ? 'YES' : 'NO') . ", is_image_tag: " . ($is_image_tag ? 'YES' : 'NO'), 'IDML_Export');
                        if ($is_image_tag) {
                            WP2ID_Debug::log("=== Image tag detected, updating BackingStory.xml and spread files ===", 'IDML_Export');
                            self::replace_tag_in_backing_story($tag_name, $replacement_content, $idml_extract_dir);

                            // Also update spread files - this is critical for images to show in InDesign Panel Links
                            WP2ID_Debug::log("=== Updating spread files for image replacement ===", 'IDML_Export');
                            self::update_spread_image_links($idml_extract_dir, $tag_name, $replacement_content);
                        } else {
                            WP2ID_Debug::log("=== NOT an image tag, skipping BackingStory.xml and spread files ===", 'IDML_Export');
                        }
                    } else {
                        if (empty($replacement_content)) {
                            WP2ID_Debug::log("Skipping tag '" . (is_array($tag_name) ? 'ARRAY' : $tag_name) . "' - empty replacement content", 'IDML_Export');
                        } else if (!is_string($tag_name)) {
                            WP2ID_Debug::log("Skipping tag - tag_name is not a string: " . gettype($tag_name), 'IDML_Export');
                        }
                    }
                }
            }

            return $doc->saveXML();
        } catch (Exception $e) {
            WP2ID_Debug::log('Error processing story content: ' . $e->getMessage(), 'IDML_Export');
            return false;
        }
    }

    /**
     * Replace a tag in story XML with content
     * 
     * @param DOMDocument $doc The XML document
     * @param DOMXPath $xpath XPath object for querying
     * @param string $tag The tag to replace
     * @param string $content The content to insert
     * @param string $template_tag_system Template tag system (only 'tag-based' is supported)
     * @param string $folder_name Name of the export folder/ZIP archive
     * @param string $idml_extract_dir IDML extract directory path
     * @return void
     */
    public static function replace_tag_in_story(&$doc, $xpath, $tag, $content, $template_tag_system = 'tag-based', $folder_name = '', $idml_extract_dir = '')
    {
        WP2ID_Debug::log("=== replace_tag_in_story START ===", 'IDML_Export');
        WP2ID_Debug::log("Looking for tag: {$tag} using system: {$template_tag_system}", 'IDML_Export');

        // Only support tag-based system
        if ($template_tag_system !== 'tag-based') {
            error_log('WARNING: IDML Utils only supports tag-based system, received: ' . $template_tag_system);
            $template_tag_system = 'tag-based';
        }

        // Make sure content is a string
        if (!is_string($content)) {
            if (is_array($content) || is_object($content)) {
                $content = json_encode($content);
            } else {
                $content = (string)$content;
            }
        }

        // Log the tag and replacement value to debug log
        WP2ID_Debug::log("Replacing tag '{$tag}' with content (length " . strlen($content) . "): " . substr($content, 0, 100) . (strlen($content) > 100 ? '...' : ''), 'IDML_Export');

        // Check if this is an image tag (contains "image" keyword)
        $is_image_tag = (stripos($tag, 'image') !== false || stripos($tag, 'feature') !== false);

        // Handle tag-based system (XMLElement processing only)
        self::replace_xml_tag_in_story($doc, $xpath, $tag, $content, $is_image_tag, $folder_name, $idml_extract_dir);

        WP2ID_Debug::log("=== replace_tag_in_story COMPLETE ===", 'IDML_Export');
    }

    /**
     * Replace XML tags in the tag-based system
     * 
     * @param DOMDocument $doc The XML document
     * @param DOMXPath $xpath XPath object for querying
     * @param string $tag The tag to replace
     * @param string $content The content to insert
     * @param bool $is_image_tag Whether this is an image tag
     * @param string $folder_name Name of the export folder/ZIP archive
     * @param string $idml_extract_dir IDML extract directory path
     * @return void
     */
    private static function replace_xml_tag_in_story(&$doc, $xpath, $tag, $content, $is_image_tag, $folder_name = '', $idml_extract_dir = '')
    {
        WP2ID_Debug::log("=== replace_xml_tag_in_story START ===", 'IDML_Export');

        // Find XMLElement nodes with MarkupTag attribute containing the tag
        $query = "//XMLElement[@MarkupTag='XMLTag/{$tag}']";
        $nodes = $xpath->query($query);

        if ($nodes->length === 0) {
            // Try alternative search patterns in case the tag format is different
            $alt_queries = [
                "//XMLElement[contains(@MarkupTag, '{$tag}')]",
                "//*[contains(text(), '{$tag}')]" // Fallback to original search
            ];

            foreach ($alt_queries as $alt_query) {
                $nodes = $xpath->query($alt_query);
                if ($nodes->length > 0) {
                    WP2ID_Debug::log("Found {$nodes->length} nodes with alternative query: {$alt_query}", 'IDML_Export');
                    break;
                }
            }
        }

        if ($nodes->length === 0) {
            // No nodes found with this tag
            WP2ID_Debug::log("No nodes found containing tag: {$tag}", 'IDML_Export');
            return;
        }

        WP2ID_Debug::log("Found {$nodes->length} XMLElement nodes with tag: {$tag}", 'IDML_Export');

        foreach ($nodes as $xmlElement) {
            if ($is_image_tag) {
                // For image tags, look for XMLAttribute with Name="href" and update its Value
                $hrefAttributes = $xpath->query('.//XMLAttribute[@Name="href"]', $xmlElement);

                if ($hrefAttributes->length > 0) {
                    $hrefAttribute = $hrefAttributes->item(0);
                    if ($hrefAttribute instanceof DOMElement) {
                        $old_href = $hrefAttribute->getAttribute('Value');

                        // For images, construct a file URL path
                        $image_url = self::construct_image_url($content, $folder_name);
                        $hrefAttribute->setAttribute('Value', $image_url);

                        WP2ID_Debug::log("SUCCESSFULLY replaced image href in XMLElement. Old: '" . substr($old_href, 0, 50) . "' New: '" . substr($image_url, 0, 50) . "'", 'IDML_Export');

                        // IMPORTANT: Add the image link to Links.xml so it appears in InDesign's Links panel
                        if (!empty($idml_extract_dir)) {
                            WP2ID_Debug::log("Adding image link to Links.xml for: " . $content, 'IDML_Export');
                            self::add_link_to_links_xml($idml_extract_dir, $content);
                        } else {
                            WP2ID_Debug::log("Warning: idml_extract_dir not available, cannot update Links.xml", 'IDML_Export');
                        }
                    }
                } else {
                    WP2ID_Debug::log("No XMLAttribute with Name='href' found in image XMLElement", 'IDML_Export');
                }
            } else {
                // For text tags, replace content as before
                $content = htmlspecialchars($content, ENT_XML1 | ENT_QUOTES, 'UTF-8');

                // Find Content nodes within this XMLElement and replace their text
                $contentNodes = $xpath->query('.//Content', $xmlElement);

                if ($contentNodes->length > 0) {
                    // Replace the content of the first Content node
                    $contentNode = $contentNodes->item(0);
                    $old_content = $contentNode->nodeValue;
                    $contentNode->nodeValue = $content;
                    WP2ID_Debug::log("SUCCESSFULLY replaced content in XMLElement. Old: '" . substr($old_content, 0, 50) . "' New: '" . substr($content, 0, 50) . "'", 'IDML_Export');
                } else {
                    // If no Content nodes, try to add content as text directly
                    WP2ID_Debug::log("No Content nodes found in XMLElement, adding text directly", 'IDML_Export');
                    $xmlElement->nodeValue = $content;
                }
            }
        }

        WP2ID_Debug::log("=== replace_xml_tag_in_story COMPLETE ===", 'IDML_Export');
    }

    /**
     * Replace a tag in BackingStory.xml for image frame references
     * 
     * @param string $tag The tag name to replace
     * @param string $content The content to replace with (e.g., image filename)
     * @param string $idml_extract_dir The IDML extraction directory path
     * @param string $folder_name Kept for backward compatibility but not used
     * @return void
     */
    public static function replace_tag_in_backing_story($tag, $content, $idml_extract_dir, $folder_name = '')
    {
        WP2ID_Debug::log("Processing tag '{$tag}' in BackingStory.xml", 'BackingStoryUpdater');

        $backing_story_path = $idml_extract_dir . '/XML/BackingStory.xml';

        if (!file_exists($backing_story_path)) {
            WP2ID_Debug::log("BackingStory.xml not found at: {$backing_story_path}", 'BackingStoryUpdater');
            return;
        }

        $backing_story_xml = file_get_contents($backing_story_path);
        if (!$backing_story_xml) {
            WP2ID_Debug::log("Failed to read BackingStory.xml", 'BackingStoryUpdater');
            return;
        }

        try {
            $doc = new DOMDocument();
            $doc->preserveWhiteSpace = false;
            $doc->formatOutput = true;

            if (!$doc->loadXML($backing_story_xml)) {
                WP2ID_Debug::log("Failed to parse BackingStory.xml", 'BackingStoryUpdater');
                return;
            }

            $xpath = new DOMXPath($doc);
            $xpath->registerNamespace('idPkg', 'http://ns.adobe.com/AdobeInDesign/idml/1.0/packaging');

            // Find XMLElement nodes with MarkupTag attribute containing the tag
            $query = "//XMLElement[@MarkupTag='XMLTag/{$tag}']";
            $nodes = $xpath->query($query);

            if ($nodes->length === 0) {
                // Try alternative query patterns if the direct tag match fails
                $alt_queries = [
                    "//XMLElement[contains(@MarkupTag, '{$tag}')]"
                ];

                foreach ($alt_queries as $alt_query) {
                    $nodes = $xpath->query($alt_query);
                    if ($nodes->length > 0) {
                        WP2ID_Debug::log("Found {$nodes->length} nodes with alternative query: {$alt_query}", 'BackingStoryUpdater');
                        break;
                    }
                }
            }

            if ($nodes->length === 0) {
                WP2ID_Debug::log("No matching nodes found for tag: {$tag}", 'BackingStoryUpdater');
                return;
            }

            WP2ID_Debug::log("Processing {$nodes->length} XMLElement nodes for tag: {$tag}", 'BackingStoryUpdater');

            $modified = false;
            foreach ($nodes as $xmlElement) {
                // Look for existing XMLAttribute with Name="href" 
                $hrefAttributes = $xpath->query('.//XMLAttribute[@Name="href"]', $xmlElement);

                if ($hrefAttributes->length > 0) {
                    // Update existing href attribute
                    $hrefAttribute = $hrefAttributes->item(0);
                    if ($hrefAttribute instanceof DOMElement) {
                        $image_url = self::construct_image_url($content);
                        $hrefAttribute->setAttribute('Value', $image_url);

                        // Also update Links.xml if it exists
                        self::update_links_xml($content, $idml_extract_dir);

                        $modified = true;
                    }
                } else {
                    // Create new XMLAttribute element for href if it doesn't exist
                    WP2ID_Debug::log("Creating new href attribute for node", 'BackingStoryUpdater');

                    $new_href_attr = $doc->createElement('XMLAttribute');
                    if ($xmlElement instanceof DOMElement) {
                        $new_href_attr->setAttribute('Self', $xmlElement->getAttribute('Self') . 'XMLAttributenhref');
                        $new_href_attr->setAttribute('Name', 'href');

                        // Construct image URL
                        $image_url = self::construct_image_url($content);
                        $new_href_attr->setAttribute('Value', $image_url);

                        // Add the XMLAttribute as the first child of XMLElement
                        if ($xmlElement->hasChildNodes()) {
                            $xmlElement->insertBefore($new_href_attr, $xmlElement->firstChild);
                        } else {
                            $xmlElement->appendChild($new_href_attr);
                        }

                        $modified = true;
                    }
                }
            }

            // Save the modified BackingStory.xml if any changes were made
            if ($modified) {
                $result = file_put_contents($backing_story_path, $doc->saveXML());
                if ($result === false) {
                    WP2ID_Debug::log("Failed to save modified BackingStory.xml", 'BackingStoryUpdater');
                } else {
                    WP2ID_Debug::log("Successfully saved modified BackingStory.xml", 'BackingStoryUpdater');
                }
            }
        } catch (Exception $e) {
            WP2ID_Debug::log("Error processing BackingStory.xml: " . $e->getMessage(), 'BackingStoryUpdater');
        }
    }

    /**
     * Create Links directory and Links.xml file if they don't exist
     *
     * @param string $idml_extract_dir The IDML extraction directory path
     * @return void
     */
    public static function create_links_structure($idml_extract_dir)
    {
        $links_dir = $idml_extract_dir . '/Links';
        $links_xml_path = $links_dir . '/Links.xml';

        // Create Links directory if it doesn't exist
        if (!file_exists($links_dir)) {
            if (!wp_mkdir_p($links_dir)) {
                WP2ID_Debug::log("Failed to create Links directory: {$links_dir}", 'LinksCreator');
                return;
            }
            WP2ID_Debug::log("Created Links directory: {$links_dir}", 'LinksCreator');
        }

        // Create Links.xml file if it doesn't exist
        if (!file_exists($links_xml_path)) {
            $links_xml_content = self::generate_links_xml_content();

            $result = file_put_contents($links_xml_path, $links_xml_content);
            if ($result === false) {
                WP2ID_Debug::log("Failed to create Links.xml file: {$links_xml_path}", 'LinksCreator');
                return;
            }

            WP2ID_Debug::log("Created Links.xml file: {$links_xml_path}", 'LinksCreator');

            // Update designmap.xml to include reference to Links directory
            self::update_designmap_for_links($idml_extract_dir);
        }
    }

    /**
     * Generate the basic XML content for Links.xml file
     *
     * @return string The XML content for Links.xml
     */
    public static function generate_links_xml_content()
    {
        $xml_content = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n";
        $xml_content .= '<Document xmlns:idPkg="http://ns.adobe.com/AdobeInDesign/idml/1.0/packaging" DOMVersion="12.0">' . "\n";
        $xml_content .= '</Document>' . "\n";

        return $xml_content;
    }

    /**
     * Add a link entry to the Links.xml file
     *
     * @param string $idml_extract_dir The IDML extraction directory path
     * @param string $content The image filename
     * @param string $folder_name Kept for backward compatibility but not used
     * @return void
     */
    public static function add_link_to_links_xml($idml_extract_dir, $content, $folder_name = '')
    {
        $links_xml_path = $idml_extract_dir . '/Links/Links.xml';

        if (!file_exists($links_xml_path)) {
            WP2ID_Debug::log("Links.xml not found, cannot add link: {$links_xml_path}", 'LinksCreator');
            return;
        }

        $links_xml = file_get_contents($links_xml_path);
        if (!$links_xml) {
            WP2ID_Debug::log("Failed to read Links.xml", 'LinksCreator');
            return;
        }

        try {
            $doc = new DOMDocument();
            $doc->preserveWhiteSpace = false;
            $doc->formatOutput = true;

            if (!$doc->loadXML($links_xml)) {
                WP2ID_Debug::log("Failed to parse Links.xml", 'LinksCreator');
                return;
            }

            // Check if a link for this content already exists
            $xpath = new DOMXPath($doc);
            $image_url = self::construct_image_url($content);
            WP2ID_Debug::log("Attempting to add/check link for URI: {$image_url}", 'LinksCreator'); // New log
            $existing_links = $xpath->query("//Link[@LinkResourceURI=\'{$image_url}\']");

            if ($existing_links->length > 0) {
                WP2ID_Debug::log("Link already exists for: {$content} with URI: {$image_url}. Skipping addition.", 'LinksCreator'); // Modified log
                return;
            }

            // Generate a unique ID for the link
            $link_id = 'u' . uniqid();

            // Create new Link element
            $link_element = $doc->createElement('Link');
            $link_element->setAttribute('Self', $link_id);
            $link_element->setAttribute('LinkResourceURI', $image_url);
            $link_element->setAttribute('StoredState', 'Normal');
            $link_element->setAttribute('LinkClassType', 'ImportedGraphic');
            $link_element->setAttribute('LinkClientID', 'u' . uniqid());
            $link_element->setAttribute('LinkResourceModified', 'false');
            $link_element->setAttribute('LinkObjectModified', 'false');
            $link_element->setAttribute('ShowInUI', 'true');
            $link_element->setAttribute('CanEmbed', 'true');
            $link_element->setAttribute('CanUnembed', 'true');
            $link_element->setAttribute('CanPackage', 'true');

            // Create StoredState child element
            $stored_state = $doc->createElement('StoredState');
            $stored_state->setAttribute('LinkResourceURI', $image_url);
            $link_element->appendChild($stored_state);

            // Add the Link element to the Document root
            $document_element = $doc->documentElement;
            $document_element->appendChild($link_element);

            // Save the modified Links.xml
            $xml_output_for_save = $doc->saveXML(); // New: get XML content before saving
            if ($xml_output_for_save === false) { // New: check if saveXML itself failed
                WP2ID_Debug::log("Failed to generate XML string from DOMDocument for: {$content}", 'LinksCreator');
                return;
            }
            WP2ID_Debug::log("XML to be saved for {$content} (first 500 chars): " . substr($xml_output_for_save, 0, 500), 'LinksCreator'); // New log

            $result = file_put_contents($links_xml_path, $xml_output_for_save);
            if ($result === false) {
                WP2ID_Debug::log("Failed to save modified Links.xml for: {$content}. Check file permissions and path: {$links_xml_path}", 'LinksCreator'); // Modified log
            } else {
                WP2ID_Debug::log("Successfully added link to Links.xml for: {$content} with URI: {$image_url}. Links.xml size: " . filesize($links_xml_path), 'LinksCreator'); // Modified log
            }
        } catch (Exception $e) {
            WP2ID_Debug::log("Error adding link to Links.xml: " . $e->getMessage(), 'LinksCreator');
        }
    }

    /**
     * Update links in the Links.xml file if it exists, create it if it doesn't
     *
     * @param string $content The image filename
     * @param string $idml_extract_dir The IDML extraction directory path
     * @param string $folder_name Kept for backward compatibility but not used
     * @return void
     */
    public static function update_links_xml($content, $idml_extract_dir, $folder_name = '')
    {
        $links_path = $idml_extract_dir . '/Links/Links.xml';

        if (!file_exists($links_path)) {
            WP2ID_Debug::log("Links.xml not found, creating Links structure at: {$links_path}", 'LinkUpdater');
            // Create the Links directory and XML file structure
            self::create_links_structure($idml_extract_dir);

            // Add the link entry for this content
            self::add_link_to_links_xml($idml_extract_dir, $content);
            return;
        }

        WP2ID_Debug::log("Updating link paths in Links.xml", 'LinkUpdater');

        $links_xml = file_get_contents($links_path);
        if (!$links_xml) {
            WP2ID_Debug::log("Failed to read Links.xml", 'LinkUpdater');
            return;
        }

        try {
            $doc = new DOMDocument();
            $doc->preserveWhiteSpace = false;
            $doc->formatOutput = true;

            if (!$doc->loadXML($links_xml)) {
                WP2ID_Debug::log("Failed to parse Links.xml", 'LinkUpdater');
                return;
            }

            $xpath = new DOMXPath($doc);
            $modified = false;

            // Find Link nodes
            $links = $xpath->query("//Link");

            if ($links->length === 0) {
                WP2ID_Debug::log("No Link nodes found in Links.xml. Attempting to add new link.", 'LinkUpdater'); // Thay đổi log
                // Coi như trường hợp Links.xml không có nút Link nào giống như chưa có file
                // và tiến hành thêm link mới.
                self::add_link_to_links_xml($idml_extract_dir, $content);
                return; // Thêm return ở đây để tránh xử lý tiếp không cần thiết
            }

            WP2ID_Debug::log("Processing {$links->length} Link nodes", 'LinkUpdater');

            foreach ($links as $link) {
                // Update LinkResourceURI attribute if present
                if ($link instanceof DOMElement && $link->hasAttribute('LinkResourceURI')) {
                    $old_uri = $link->getAttribute('LinkResourceURI');
                    $image_url = self::construct_image_url($content);
                    $link->setAttribute('LinkResourceURI', $image_url);
                    $modified = true;
                }

                // Update StoredState/LinkResourceURI if present
                $stored_states = $xpath->query(".//StoredState", $link);
                foreach ($stored_states as $state) {
                    if ($state instanceof DOMElement && $state->hasAttribute('LinkResourceURI')) {
                        $image_url = self::construct_image_url($content);
                        $state->setAttribute('LinkResourceURI', $image_url);
                        $modified = true;
                    }
                }
            }

            // Save the modified Links.xml if any changes were made
            if ($modified) {
                $result = file_put_contents($links_path, $doc->saveXML());
                if ($result === false) {
                    WP2ID_Debug::log("Failed to save modified Links.xml", 'LinkUpdater');
                } else {
                    WP2ID_Debug::log("Successfully saved modified Links.xml", 'LinkUpdater');
                }
            }
        } catch (Exception $e) {
            WP2ID_Debug::log("Error processing Links.xml: " . $e->getMessage(), 'LinkUpdater');
        }
    }

    /**
     * Update designmap.xml to include reference to Links directory if it doesn't exist
     *
     * @param string $idml_extract_dir The IDML extraction directory path
     * @return void
     */
    public static function update_designmap_for_links($idml_extract_dir)
    {
        $designmap_path = $idml_extract_dir . '/designmap.xml';

        if (!file_exists($designmap_path)) {
            WP2ID_Debug::log("designmap.xml not found at: {$designmap_path}", 'DesignmapUpdater');
            return;
        }

        $designmap_xml = file_get_contents($designmap_path);
        if (!$designmap_xml) {
            WP2ID_Debug::log("Failed to read designmap.xml", 'DesignmapUpdater');
            return;
        }

        try {
            $doc = new DOMDocument();
            $doc->preserveWhiteSpace = false;
            $doc->formatOutput = true;

            if (!$doc->loadXML($designmap_xml)) {
                WP2ID_Debug::log("Failed to parse designmap.xml", 'DesignmapUpdater');
                return;
            }

            $xpath = new DOMXPath($doc);
            $xpath->registerNamespace('idPkg', 'http://ns.adobe.com/AdobeInDesign/idml/1.0/packaging');

            // Check if Links reference already exists
            $existing_links = $xpath->query("//idPkg:Links");
            if ($existing_links->length > 0) {
                WP2ID_Debug::log("Links reference already exists in designmap.xml", 'DesignmapUpdater');
                return;
            }

            // Find a good insertion point - typically after Resources but before other elements
            $preferences_elements = $xpath->query("//idPkg:Preferences");
            if ($preferences_elements->length > 0) {
                // Insert after Preferences element
                $preferences_element = $preferences_elements->item(0);
                $links_element = $doc->createElement('idPkg:Links');
                $links_element->setAttribute('src', 'Links/Links.xml');

                // Insert after preferences
                $next_sibling = $preferences_element->nextSibling;
                if ($next_sibling) {
                    $preferences_element->parentNode->insertBefore($links_element, $next_sibling);
                } else {
                    $preferences_element->parentNode->appendChild($links_element);
                }

                // Save the modified designmap.xml
                $result = file_put_contents($designmap_path, $doc->saveXML());
                if ($result === false) {
                    WP2ID_Debug::log("Failed to save modified designmap.xml", 'DesignmapUpdater');
                } else {
                    WP2ID_Debug::log("Successfully updated designmap.xml with Links reference", 'DesignmapUpdater');
                }
            } else {
                WP2ID_Debug::log("Could not find insertion point in designmap.xml", 'DesignmapUpdater');
            }
        } catch (Exception $e) {
            WP2ID_Debug::log("Error updating designmap.xml: " . $e->getMessage(), 'DesignmapUpdater');
        }
    }

    /**
     * Update metadata.xml with xmpMM:Manifest section based on linked images
     *
     * @param string $idml_extract_dir The IDML extraction directory path
     * @param string $folder_name Kept for backward compatibility but not used
     * @return void
     */
    public static function update_metadata_manifest($idml_extract_dir, $folder_name = '')
    {
        $metadata_xml_path = $idml_extract_dir . '/META-INF/metadata.xml';
        $links_xml_path = $idml_extract_dir . '/Links/Links.xml';

        if (!file_exists($metadata_xml_path)) {
            WP2ID_Debug::log("metadata.xml not found: {$metadata_xml_path}", 'MetadataManifest');
            return;
        }

        // Get list of linked images from Links.xml if it exists
        $linked_images = array();
        if (file_exists($links_xml_path)) {
            $linked_images = self::get_linked_images_from_links_xml($links_xml_path);
        }

        if (empty($linked_images)) {
            WP2ID_Debug::log("No linked images found, skipping metadata manifest update", 'MetadataManifest');
            return;
        }

        WP2ID_Debug::log("Found " . count($linked_images) . " linked images, updating metadata manifest", 'MetadataManifest');

        $metadata_xml = file_get_contents($metadata_xml_path);
        if (!$metadata_xml) {
            WP2ID_Debug::log("Failed to read metadata.xml", 'MetadataManifest');
            return;
        }

        try {
            $doc = new DOMDocument();
            $doc->preserveWhiteSpace = false;
            $doc->formatOutput = true;
            $doc->loadXML($metadata_xml);

            // Create XPath object for querying
            $xpath = new DOMXPath($doc);
            $xpath->registerNamespace('rdf', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#');
            $xpath->registerNamespace('xmpMM', 'http://ns.adobe.com/xap/1.0/mm/');
            $xpath->registerNamespace('stMfs', 'http://ns.adobe.com/xap/1.0/sType/ManifestItem#');
            $xpath->registerNamespace('stRef', 'http://ns.adobe.com/xap/1.0/sType/ResourceRef#');

            // Find the rdf:Description element that contains xmpMM namespace elements
            $description_nodes = $xpath->query('//rdf:Description[xmpMM:DocumentID]');

            if ($description_nodes->length === 0) {
                WP2ID_Debug::log("No rdf:Description with xmpMM:DocumentID found", 'MetadataManifest');
                return;
            }

            $description_node = $description_nodes->item(0);

            // Check if xmpMM:Manifest already exists
            $existing_manifest = $xpath->query('xmpMM:Manifest', $description_node);
            if ($existing_manifest->length > 0) {
                // Remove existing manifest to replace it
                $description_node->removeChild($existing_manifest->item(0));
                WP2ID_Debug::log("Removed existing xmpMM:Manifest", 'MetadataManifest');
            }

            // Create the xmpMM:Manifest element
            $manifest_element = $doc->createElementNS('http://ns.adobe.com/xap/1.0/mm/', 'xmpMM:Manifest');
            $bag_element = $doc->createElementNS('http://www.w3.org/1999/02/22-rdf-syntax-ns#', 'rdf:Bag');

            foreach ($linked_images as $image_url) {
                $li_element = $doc->createElementNS('http://www.w3.org/1999/02/22-rdf-syntax-ns#', 'rdf:li');
                $li_element->setAttribute('rdf:parseType', 'Resource');

                // Add linkForm
                $link_form = $doc->createElementNS('http://ns.adobe.com/xap/1.0/sType/ManifestItem#', 'stMfs:linkForm', 'ReferenceStream');
                $li_element->appendChild($link_form);

                // Add reference
                $reference = $doc->createElementNS('http://ns.adobe.com/xap/1.0/sType/ManifestItem#', 'stMfs:reference');
                $reference->setAttribute('rdf:parseType', 'Resource');
                $last_url = $doc->createElementNS('http://ns.adobe.com/xap/1.0/sType/ResourceRef#', 'stRef:lastURL', $image_url);
                $reference->appendChild($last_url);
                $li_element->appendChild($reference);

                // Add resolution information (default values)
                $placed_x_res = $doc->createElementNS('http://ns.adobe.com/xap/1.0/mm/', 'xmpMM:placedXResolution', '96.00');
                $placed_y_res = $doc->createElementNS('http://ns.adobe.com/xap/1.0/mm/', 'xmpMM:placedYResolution', '96.00');
                $placed_res_unit = $doc->createElementNS('http://ns.adobe.com/xap/1.0/mm/', 'xmpMM:placedResolutionUnit', 'Inches');

                $li_element->appendChild($placed_x_res);
                $li_element->appendChild($placed_y_res);
                $li_element->appendChild($placed_res_unit);

                $bag_element->appendChild($li_element);
            }

            $manifest_element->appendChild($bag_element);

            // Insert the manifest after xmpMM:RenditionClass if it exists, or after xmpMM:DocumentID
            $rendition_class = $xpath->query('xmpMM:RenditionClass', $description_node);
            if ($rendition_class->length > 0) {
                $insert_after = $rendition_class->item(0);
            } else {
                $document_id = $xpath->query('xmpMM:DocumentID', $description_node);
                $insert_after = $document_id->item(0);
            }

            // Insert the manifest after the reference element
            if ($insert_after->nextSibling) {
                $description_node->insertBefore($manifest_element, $insert_after->nextSibling);
            } else {
                $description_node->appendChild($manifest_element);
            }

            // Save the modified metadata.xml
            $result = file_put_contents($metadata_xml_path, $doc->saveXML());
            if ($result === false) {
                WP2ID_Debug::log("Failed to save modified metadata.xml", 'MetadataManifest');
            } else {
                WP2ID_Debug::log("Successfully updated metadata.xml with manifest for " . count($linked_images) . " images", 'MetadataManifest');
            }
        } catch (Exception $e) {
            WP2ID_Debug::log("Error updating metadata manifest: " . $e->getMessage(), 'MetadataManifest');
        }
    }

    /**
     * Get linked images from Links.xml file
     *
     * @param string $links_xml_path Path to Links.xml file
     * @return array Array of image URLs
     */
    public static function get_linked_images_from_links_xml($links_xml_path)
    {
        $linked_images = array();

        if (!file_exists($links_xml_path)) {
            return $linked_images;
        }

        $links_xml = file_get_contents($links_xml_path);
        if (!$links_xml) {
            return $linked_images;
        }

        try {
            $doc = new DOMDocument();
            $doc->loadXML($links_xml);

            $xpath = new DOMXPath($doc);
            $links = $xpath->query('//Link[@LinkResourceURI]');

            foreach ($links as $link) {
                if ($link instanceof DOMElement) {
                    $link_uri = $link->getAttribute('LinkResourceURI');
                    if (!empty($link_uri)) {
                        $linked_images[] = $link_uri;
                    }
                }
            }

            WP2ID_Debug::log("Extracted " . count($linked_images) . " image URLs from Links.xml", 'MetadataManifest');
        } catch (Exception $e) {
            WP2ID_Debug::log("Error reading Links.xml: " . $e->getMessage(), 'MetadataManifest');
        }

        return $linked_images;
    }

    /**
     * Update spread files to replace LinkResourceURI for image links using XMLContent mapping
     * This maps BackingStory.xml XMLContent IDs to Image Self IDs in spread files
     *
     * @param string $idml_extract_dir The IDML extraction directory path
     * @param string $tag_name The image tag name (e.g., "Page_3_Image_1")
     * @param string $new_image_name The new image name (e.g., "Page_3_Image_1.jpg")
     * @param string $folder_name Kept for backward compatibility but not used
     * @return void
     */
    public static function update_spread_image_links($idml_extract_dir, $tag_name, $new_image_name, $folder_name = '')
    {
        WP2ID_Debug::log("=== UPDATING SPREAD IMAGE LINKS ===", 'SpreadUpdater');
        WP2ID_Debug::log("Processing tag '{$tag_name}' with image '{$new_image_name}'", 'SpreadUpdater');

        // Step 1: Get XMLContent ID from BackingStory.xml for this tag
        $xml_content_id = self::get_xml_content_id_for_tag($idml_extract_dir, $tag_name);

        if (!$xml_content_id) {
            WP2ID_Debug::log("No XMLContent ID found for tag '{$tag_name}' in BackingStory.xml", 'SpreadUpdater');
            return;
        }

        WP2ID_Debug::log("Found XMLContent ID '{$xml_content_id}' for tag '{$tag_name}'", 'SpreadUpdater');

        // Step 2: Find and update Image elements with matching Self ID in spread files
        $spreads_dir = $idml_extract_dir . '/Spreads';

        if (!is_dir($spreads_dir)) {
            WP2ID_Debug::log("Spreads directory not found: {$spreads_dir}", 'SpreadUpdater');
            return;
        }

        $spread_files = glob($spreads_dir . '/Spread_*.xml');

        if (empty($spread_files)) {
            WP2ID_Debug::log("No spread files found in: {$spreads_dir}", 'SpreadUpdater');
            return;
        }

        WP2ID_Debug::log("Searching for Image Self='{$xml_content_id}' in " . count($spread_files) . " spread files", 'SpreadUpdater');

        $updates_made = 0;
        foreach ($spread_files as $spread_file) {
            $spread_basename = basename($spread_file);

            $spread_xml = file_get_contents($spread_file);
            if (!$spread_xml) {
                WP2ID_Debug::log("Failed to read spread file: {$spread_file}", 'SpreadUpdater');
                continue;
            }

            try {
                $doc = new DOMDocument();
                $doc->preserveWhiteSpace = false;
                $doc->formatOutput = true;

                if (!$doc->loadXML($spread_xml)) {
                    WP2ID_Debug::log("Failed to parse spread file: {$spread_file}", 'SpreadUpdater');
                    continue;
                }

                $xpath = new DOMXPath($doc);
                $modified = false;

                // Find Image element with Self ID matching XMLContent ID
                $image_query = "//Image[@Self='{$xml_content_id}']";
                $images = $xpath->query($image_query);

                if ($images->length > 0) {
                    WP2ID_Debug::log("FOUND Image Self='{$xml_content_id}' in {$spread_basename}!", 'SpreadUpdater');

                    foreach ($images as $image) {
                        // Find Link elements within this Image
                        $links = $xpath->query('.//Link[@LinkResourceURI]', $image);

                        foreach ($links as $link) {
                            if ($link instanceof DOMElement) {
                                $current_uri = $link->getAttribute('LinkResourceURI');
                                $new_image_url = self::construct_image_url($new_image_name);

                                WP2ID_Debug::log("Updating LinkResourceURI from '{$current_uri}' to '{$new_image_url}' in {$spread_basename}", 'SpreadUpdater');

                                $link->setAttribute('LinkResourceURI', $new_image_url);
                                $modified = true;
                                $updates_made++;
                            }
                        }
                    }
                }

                // Save the modified spread file if any changes were made
                if ($modified) {
                    $result = file_put_contents($spread_file, $doc->saveXML());
                    if ($result === false) {
                        WP2ID_Debug::log("Failed to save modified spread file: {$spread_file}", 'SpreadUpdater');
                    } else {
                        WP2ID_Debug::log("Successfully saved modified spread file: {$spread_basename}", 'SpreadUpdater');
                    }
                }
            } catch (Exception $e) {
                WP2ID_Debug::log("Error processing spread file {$spread_file}: " . $e->getMessage(), 'SpreadUpdater');
            }
        }

        if ($updates_made > 0) {
            WP2ID_Debug::log("Successfully updated {$updates_made} LinkResourceURI(s) for tag '{$tag_name}'", 'SpreadUpdater');
        } else {
            WP2ID_Debug::log("No Image elements found with Self='{$xml_content_id}' in any spread files", 'SpreadUpdater');
        }

        WP2ID_Debug::log("=== SPREAD IMAGE LINKS UPDATE COMPLETE ===", 'SpreadUpdater');
    }

    /**
     * Get XMLContent ID for a given tag name from BackingStory.xml
     *
     * @param string $idml_extract_dir The IDML extraction directory path
     * @param string $tag_name The tag name (e.g., "Page_3_Image_1")
     * @return string|false XMLContent ID or false if not found
     */
    private static function get_xml_content_id_for_tag($idml_extract_dir, $tag_name)
    {
        $backing_story_path = $idml_extract_dir . '/XML/BackingStory.xml';

        if (!file_exists($backing_story_path)) {
            WP2ID_Debug::log("BackingStory.xml not found at: {$backing_story_path}", 'SpreadUpdater');
            return false;
        }

        $backing_story_xml = file_get_contents($backing_story_path);
        if (!$backing_story_xml) {
            WP2ID_Debug::log("Failed to read BackingStory.xml", 'SpreadUpdater');
            return false;
        }

        try {
            $doc = new DOMDocument();
            $doc->loadXML($backing_story_xml);

            $xpath = new DOMXPath($doc);

            // Find XMLElement with MarkupTag containing the tag name
            $query = "//XMLElement[@MarkupTag='XMLTag/{$tag_name}']";
            $nodes = $xpath->query($query);

            if ($nodes->length > 0) {
                $xml_element = $nodes->item(0);
                if ($xml_element instanceof DOMElement) {
                    $xml_content_id = $xml_element->getAttribute('XMLContent');
                    WP2ID_Debug::log("Found XMLContent='{$xml_content_id}' for tag '{$tag_name}' in BackingStory.xml", 'SpreadUpdater');
                    return $xml_content_id;
                }
            }

            WP2ID_Debug::log("No XMLElement found for tag '{$tag_name}' in BackingStory.xml", 'SpreadUpdater');
            return false;
        } catch (Exception $e) {
            WP2ID_Debug::log("Error reading BackingStory.xml: " . $e->getMessage(), 'SpreadUpdater');
            return false;
        }
    }
}
