<?php
/**
 * The security utility functionality of the plugin.
 *
 * @since      1.0.0
 * @package    WP2ID
 * @subpackage WP2ID/includes
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Security utility class with methods to enhance plugin security.
 */
class WP2ID_Security {

    /**
     * Validate and sanitize a text input.
     *
     * @since    1.0.0
     * @param    string    $input       The input to validate.
     * @return   string    Sanitized input.
     */
    public static function sanitize_text_field( $input ) {
        return sanitize_text_field( $input );
    }

    /**
     * Validate and sanitize a textarea input.
     *
     * @since    1.0.0
     * @param    string    $input       The input to validate.
     * @return   string    Sanitized input.
     */
    public static function sanitize_textarea_field( $input ) {
        return sanitize_textarea_field( $input );
    }

    /**
     * Validate and sanitize an email input.
     *
     * @since    1.0.0
     * @param    string    $input       The input to validate.
     * @return   string    Sanitized email or empty string if invalid.
     */
    public static function sanitize_email( $input ) {
        $email = sanitize_email( $input );
        return is_email( $email ) ? $email : '';
    }

    /**
     * Validate and sanitize a URL input.
     *
     * @since    1.0.0
     * @param    string    $input       The input to validate.
     * @return   string    Sanitized URL.
     */
    public static function sanitize_url( $input ) {
        return esc_url_raw( $input );
    }

    /**
     * Verify a nonce for security.
     *
     * @since    1.0.0
     * @param    string    $nonce       The nonce to verify.
     * @param    string    $action      The action tied to the nonce.
     * @return   boolean   True if nonce is valid, false otherwise.
     */
    public static function verify_nonce( $nonce, $action ) {
        if ( ! isset( $nonce ) || ! wp_verify_nonce( $nonce, $action ) ) {
            return false;
        }
        return true;
    }

    /**
     * Check user capability.
     *
     * @since    1.0.0
     * @param    string    $capability  The capability to check.
     * @return   boolean   True if user has capability, false otherwise.
     */
    public static function user_can( $capability ) {
        if ( ! current_user_can( $capability ) ) {
            return false;
        }
        return true;
    }

    /**
     * Securely generate a random string.
     *
     * @since    1.0.0
     * @param    int       $length      The length of the string.
     * @return   string    A random string.
     */
    public static function generate_random_string( $length = 12 ) {
        if ( function_exists( 'random_bytes' ) ) {
            return bin2hex( random_bytes( $length / 2 ) );
        }
        if ( function_exists( 'openssl_random_pseudo_bytes' ) ) {
            return bin2hex( openssl_random_pseudo_bytes( $length / 2 ) );
        }
        // Fallback (not secure, but better than nothing)
        return substr( str_shuffle( MD5( microtime() ) ), 0, $length );
    }
}
