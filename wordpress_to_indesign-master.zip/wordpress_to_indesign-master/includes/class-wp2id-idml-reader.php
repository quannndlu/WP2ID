<?php
/**
 * IDML Reader Class
 *
 * This class handles reading and parsing IDML files for the WP2ID plugin.
 * IDML (InDesign Markup Language) files are ZIP archives containing XML files
 * that describe InDesign documents.
 *
 * @since      1.0.0
 * @package    WP2ID
 * @subpackage WP2ID/includes
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * IDML Reader Class
 *
 * This class provides methods for reading and extracting data from IDML files,
 * which are ZIP archives containing XML files that describe InDesign documents.
 *
 * @package    WP2ID
 * @subpackage WP2ID/includes
 */
class WP2ID_IDML_Reader {

    /**
     * The path to the IDML file.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $file_path    The path to the IDML file.
     */
    private $file_path;
    
    /**
     * The extracted contents of the IDML file.
     *
     * @since    1.0.0
     * @access   private
     * @var      array     $contents     The extracted contents of the IDML file.
     */
    private $contents;
    
    /**
     * Error messages.
     *
     * @since    1.0.0
     * @access   private
     * @var      array     $errors       Array of error messages.
     */
    private $errors = array();
    
    /**
     * DOM Document for parsing XML files.
     *
     * @since    1.0.0
     * @access   private
     * @var      DOMDocument    $dom    DOM Document for parsing XML.
     */
    private $dom;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param    string    $file_path    The path to the IDML file.
     */
    public function __construct( $file_path = null ) {
        if ( $file_path ) {
            $this->file_path = $file_path;
        }
        
        $this->dom = new DOMDocument('1.0', 'UTF-8');
        $this->dom->preserveWhiteSpace = false;
        $this->dom->formatOutput = true;
    }
    
    /**
     * Set the IDML file path.
     *
     * @since    1.0.0
     * @param    string    $file_path    The path to the IDML file.
     * @return   bool                    True on success, false on failure.
     */
    public function set_file_path( $file_path ) {
        if ( ! file_exists( $file_path ) ) {
            $this->errors[] = sprintf( __( 'File does not exist: %s', 'wp2id' ), $file_path );
            return false;
        }
        
        $this->file_path = $file_path;
        return true;
    }
    
    /**
     * Get the last error message.
     *
     * @since    1.0.0
     * @return   string    The last error message.
     */
    public function get_last_error() {
        return end( $this->errors );
    }
    
    /**
     * Get all error messages.
     *
     * @since    1.0.0
     * @return   array    All error messages.
     */
    public function get_all_errors() {
        return $this->errors;
    }
    
    /**
     * Extract the IDML file (ZIP archive).
     *
     * @since    1.0.0
     * @param    string    $extract_to    Path to extract the IDML file to. If not provided,
     *                                    a temporary directory will be created.
     * @return   bool                     True on success, false on failure.
     */
    public function extract( $extract_to = null ) {
        if ( ! $this->file_path ) {
            $this->errors[] = __( 'No IDML file path specified.', 'wp2id' );
            return false;
        }
        
        // Check if file exists
        if ( ! file_exists( $this->file_path ) ) {
            $this->errors[] = sprintf( __( 'IDML file does not exist: %s', 'wp2id' ), $this->file_path );
            return false;
        }
        
        // Check if it's a valid ZIP file
        $zip = new ZipArchive();
        if ( $zip->open( $this->file_path ) !== true ) {
            $this->errors[] = sprintf( __( 'Failed to open IDML file as ZIP archive: %s', 'wp2id' ), $this->file_path );
            return false;
        }
        
        // Create a temporary directory if extract_to is not provided
        if ( ! $extract_to ) {
            $extract_to = get_temp_dir() . 'wp2id_' . uniqid();
            if ( ! wp_mkdir_p( $extract_to ) ) {
                $this->errors[] = sprintf( __( 'Failed to create temporary directory: %s', 'wp2id' ), $extract_to );
                return false;
            }
        }
        
        // Extract the IDML file
        if ( ! $zip->extractTo( $extract_to ) ) {
            $this->errors[] = sprintf( __( 'Failed to extract IDML file: %s', 'wp2id' ), $this->file_path );
            $zip->close();
            return false;
        }
        
        $zip->close();
        
        $this->contents = array(
            'path' => $extract_to,
            'files' => $this->get_directory_contents( $extract_to ),
        );
        
        return true;
    }
    
    /**
     * Get the contents of a directory recursively.
     *
     * @since    1.0.0
     * @access   private
     * @param    string    $dir    Directory path.
     * @return   array             Directory contents.
     */
    private function get_directory_contents( $dir ) {
        $results = array();
        $files = scandir( $dir );
        
        foreach ( $files as $file ) {
            if ( $file === '.' || $file === '..' ) {
                continue;
            }
            
            $path = $dir . '/' . $file;
            
            if ( is_dir( $path ) ) {
                $results[$file] = $this->get_directory_contents( $path );
            } else {
                $results[] = $file;
            }
        }
        
        return $results;
    }
    
    /**
     * Read and parse the designmap.xml file, which is the main file in an IDML document.
     *
     * @since    1.0.0
     * @return   array|bool    Array of document information or false on failure.
     */
    public function read_designmap() {
        if ( ! isset( $this->contents ) ) {
            if ( ! $this->extract() ) {
                return false;
            }
        }
        
        $designmap_path = $this->contents['path'] . '/designmap.xml';
        
        if ( ! file_exists( $designmap_path ) ) {
            $this->errors[] = __( 'designmap.xml not found in the IDML file.', 'wp2id' );
            return false;
        }
        
        // Load the designmap.xml file
        $this->dom->load( $designmap_path );
        
        // Parse the designmap.xml file
        $document = array(
            'stories' => array(),
            'spreads' => array(),
            'styles' => array(),
            'fonts' => array(),
            'metadata' => array(),
        );
        
        // Get story references from the Document element's StoryList attribute
        $document_node = $this->dom->getElementsByTagName( 'Document' )->item(0);
        if ( $document_node && $document_node->hasAttribute( 'StoryList' ) ) {
            $story_list = $document_node->getAttribute( 'StoryList' );
            $story_ids = explode( ' ', trim( $story_list ) );
            
            foreach ( $story_ids as $story_id ) {
                if ( !empty( $story_id ) ) {
                    $document['stories'][$story_id] = array(
                        'src' => 'Stories/Story_' . $story_id . '.xml',
                        'self' => $story_id,
                    );
                }
            }
        }
        
        // Also check for explicit Story elements (fallback for different IDML formats)
        $story_nodes = $this->dom->getElementsByTagName( 'Story' );
        foreach ( $story_nodes as $story ) {
            $self = $story->getAttribute( 'Self' );
            $document['stories'][$self] = array(
                'src' => $story->getAttribute( 'src' ),
                'self' => $self,
            );
        }
        
        // Get spread references
        $spread_nodes = $this->dom->getElementsByTagName( 'Spread' );
        foreach ( $spread_nodes as $spread ) {
            $self = $spread->getAttribute( 'Self' );
            $document['spreads'][$self] = array(
                'src' => $spread->getAttribute( 'src' ),
                'self' => $self,
            );
        }
        
        // Get style references
        $style_nodes = $this->dom->getElementsByTagName( 'Style' );
        foreach ( $style_nodes as $style ) {
            $self = $style->getAttribute( 'Self' );
            $document['styles'][$self] = array(
                'name' => $style->getAttribute( 'Name' ),
                'self' => $self,
            );
        }
        
        return $document;
    }
    
    /**
     * Read and parse a specific story file from the IDML document.
     *
     * @since    1.0.0
     * @param    string    $story_path    The path to the story XML file within the IDML.
     * @return   array|bool               Array of story content or false on failure.
     */
    public function read_story( $story_path ) {
        if ( ! isset( $this->contents ) ) {
            if ( ! $this->extract() ) {
                return false;
            }
        }
        
        $full_path = $this->contents['path'] . '/' . $story_path;
        
        if ( ! file_exists( $full_path ) ) {
            $this->errors[] = sprintf( __( 'Story file not found: %s', 'wp2id' ), $story_path );
            return false;
        }
        
        // Load the story XML file
        $this->dom->load( $full_path );
        
        $story = array(
            'content' => '',
            'paragraphs' => array(),
            'characters' => array(),
            'xml_tags' => array(),
        );
        
        // Get Story root element and check for XML structure attributes
        $story_root = $this->dom->getElementsByTagName('Story')->item(0);
        if ($story_root) {
            // Check if story has MarkupTag attribute
            $markup_tag = $story_root->getAttribute('MarkupTag');
            if ($markup_tag && !empty($markup_tag)) {
                $story['xml_tags'][] = $markup_tag;
            }
        }
        
        // First, get XMLElements which contain the actual XML tag structure
        $xml_element_nodes = $this->dom->getElementsByTagName( 'XMLElement' );
        foreach ( $xml_element_nodes as $xml_element ) {
            $markup_tag = $xml_element->getAttribute('MarkupTag');
            if ($markup_tag && !empty($markup_tag)) {
                $story['xml_tags'][] = $markup_tag;
                
                // Process paragraphs within this XMLElement
                $paragraph_nodes = $xml_element->getElementsByTagName( 'ParagraphStyleRange' );
                foreach ( $paragraph_nodes as $paragraph ) {
                    $style_id = $paragraph->getAttribute( 'AppliedParagraphStyle' );
                    $paragraph_data = array(
                        'style_id' => $style_id,
                        'content' => '',
                        'char_styles' => array(),
                        'markup_tag' => $markup_tag, // XML tag from parent XMLElement
                        'xml_element' => $xml_element->getAttribute('Self'),
                    );
                    
                    $this->process_paragraph_content( $paragraph, $paragraph_data, $story );
                    $story['paragraphs'][] = $paragraph_data;
                }
            }
        }
        
        // Also get standalone paragraphs (not wrapped in XMLElement)
        $standalone_paragraphs = $this->dom->getElementsByTagName( 'ParagraphStyleRange' );
        foreach ( $standalone_paragraphs as $paragraph ) {
            // Skip if this paragraph is already inside an XMLElement
            $parent = $paragraph->parentNode;
            while ( $parent && $parent->nodeName !== 'Story' ) {
                if ( $parent->nodeName === 'XMLElement' ) {
                    continue 2; // Skip this paragraph as it's already processed above
                }
                $parent = $parent->parentNode;
            }
            
            $style_id = $paragraph->getAttribute( 'AppliedParagraphStyle' );
            $paragraph_data = array(
                'style_id' => $style_id,
                'content' => '',
                'char_styles' => array(),
            );
            
            // Check for XML structure attributes on standalone paragraph
            $markup_tag = $paragraph->getAttribute('MarkupTag');
            if ($markup_tag && !empty($markup_tag)) {
                $paragraph_data['markup_tag'] = $markup_tag;
                $story['xml_tags'][] = $markup_tag;
            }
            
            // Check for XMLElement attribute which references InDesign's XML tag system
            $xml_element = $paragraph->getAttribute('XMLElement');
            if ($xml_element && !empty($xml_element)) {
                $paragraph_data['xml_element'] = $xml_element;
                $story['xml_tags'][] = $xml_element;
            }
            
            // Check for any XML tag markers
            $marker_tag = $paragraph->getAttribute('AppliedMarker');
            if ($marker_tag && !empty($marker_tag)) {
                $paragraph_data['marker_tag'] = $marker_tag;
            }
            
            $this->process_paragraph_content( $paragraph, $paragraph_data, $story );
            $story['paragraphs'][] = $paragraph_data;
        }
        
        return $story;
    }
    
    /**
     * Read and parse all stories from the IDML document.
     *
     * @since    1.0.0
     * @return   array|bool    Array of stories or false on failure.
     */
    public function read_all_stories() {
        $designmap = $this->read_designmap();
        
        if ( ! $designmap ) {
            return false;
        }
        
        $stories = array();
        
        foreach ( $designmap['stories'] as $id => $story_info ) {
            $story = $this->read_story( $story_info['src'] );
            
            if ( $story ) {
                $stories[$id] = $story;
            }
        }
        
        return $stories;
    }
    
    /**
     * Read and parse the styles.xml file, which contains paragraph and character styles.
     *
     * @since    1.0.0
     * @return   array|bool    Array of styles or false on failure.
     */
    public function read_styles() {
        if ( ! isset( $this->contents ) ) {
            if ( ! $this->extract() ) {
                return false;
            }
        }
        
        $styles_path = $this->contents['path'] . '/Resources/Styles.xml';
        
        if ( ! file_exists( $styles_path ) ) {
            $this->errors[] = __( 'Styles.xml not found in the IDML file.', 'wp2id' );
            return false;
        }
        
        // Load the Styles.xml file
        $this->dom->load( $styles_path );
        
        $styles = array(
            'paragraph' => array(),
            'character' => array(),
        );
        
        // Get paragraph styles
        $para_style_nodes = $this->dom->getElementsByTagName( 'ParagraphStyle' );
        foreach ( $para_style_nodes as $style ) {
            $id = $style->getAttribute( 'Self' );
            $name = $style->getAttribute( 'Name' );
            
            $styles['paragraph'][$id] = array(
                'id' => $id,
                'name' => $name,
                'properties' => $this->parse_style_properties( $style ),
            );
        }
        
        // Get character styles
        $char_style_nodes = $this->dom->getElementsByTagName( 'CharacterStyle' );
        foreach ( $char_style_nodes as $style ) {
            $id = $style->getAttribute( 'Self' );
            $name = $style->getAttribute( 'Name' );
            
            $styles['character'][$id] = array(
                'id' => $id,
                'name' => $name,
                'properties' => $this->parse_style_properties( $style ),
            );
        }
        
        return $styles;
    }
    
    /**
     * Parse style properties from a style node.
     *
     * @since    1.0.0
     * @access   private
     * @param    DOMElement    $style_node    The style node.
     * @return   array                         Style properties.
     */
    private function parse_style_properties( $style_node ) {
        $properties = array();
        
        // Get properties
        $property_nodes = $style_node->getElementsByTagName( 'Property' );
        foreach ( $property_nodes as $property ) {
            $name = $property->getAttribute( 'Name' );
            $value = $property->nodeValue;
            
            $properties[$name] = $value;
        }
        
        return $properties;
    }
    
    /**
     * Read and parse metadata from the IDML document.
     *
     * @since    1.0.0
     * @return   array|bool    Array of metadata or false on failure.
     */
    public function read_metadata() {
        if ( ! isset( $this->contents ) ) {
            if ( ! $this->extract() ) {
                return false;
            }
        }
        
        $metadata_path = $this->contents['path'] . '/META-INF/metadata.xml';
        
        if ( ! file_exists( $metadata_path ) ) {
            $this->errors[] = __( 'metadata.xml not found in the IDML file.', 'wp2id' );
            return false;
        }
        
        // Load the metadata.xml file
        $this->dom->load( $metadata_path );
        
        $metadata = array();
        
        // Get basic metadata
        $root = $this->dom->documentElement;
        if ( $root->nodeName === 'x:xmpmeta' ) {
            $rdf_nodes = $this->dom->getElementsByTagNameNS( 'http://www.w3.org/1999/02/22-rdf-syntax-ns#', 'RDF' );
            
            if ( $rdf_nodes->length > 0 ) {
                $rdf = $rdf_nodes->item( 0 );
                $description_nodes = $rdf->getElementsByTagNameNS( 'http://www.w3.org/1999/02/22-rdf-syntax-ns#', 'Description' );
                
                foreach ( $description_nodes as $description ) {
                    foreach ( $description->attributes as $attr ) {
                        if ( $attr->namespaceURI && $attr->name !== 'xmlns:xmp' && $attr->name !== 'xmlns:pdf' ) {
                            $key = str_replace( 'xmlns:', '', $attr->name );
                            $metadata[$key] = $attr->value;
                        }
                    }
                    
                    // Get child elements
                    foreach ( $description->childNodes as $child ) {
                        if ( $child->nodeType === XML_ELEMENT_NODE ) {
                            $metadata[$child->localName] = $child->nodeValue;
                        }
                    }
                }
            }
        }
        
        return $metadata;
    }
    
    /**
     * Clean up temporary files.
     *
     * @since    1.0.0
     * @return   bool    True on success, false on failure.
     */
    public function cleanup() {
        if ( isset( $this->contents ) && isset( $this->contents['path'] ) ) {
            return $this->remove_directory( $this->contents['path'] );
        }
        
        return true;
    }
    
    /**
     * Remove a directory and all its contents recursively.
     *
     * @since    1.0.0
     * @access   private
     * @param    string    $dir    Directory path.
     * @return   bool              True on success, false on failure.
     */
    private function remove_directory( $dir ) {
        if ( ! is_dir( $dir ) ) {
            return false;
        }
        
        $files = scandir( $dir );
        foreach ( $files as $file ) {
            if ( $file === '.' || $file === '..' ) {
                continue;
            }
            
            $path = $dir . '/' . $file;
            
            if ( is_dir( $path ) ) {
                $this->remove_directory( $path );
            } else {
                unlink( $path );
            }
        }
        
        return rmdir( $dir );
    }
    
    /**
     * Extract XML tags from stories and spreads.
     * 
     * This method extracts only InDesign's native XML tag structure from the IDML content.
     * It reads the XML tags from Tags.xml and processes the story content to find XMLElement references.
     *
     * @since    1.0.0
     * @param    array     $stories      Array of stories from IDML.
     * @param    string    $tag_system   The tag system to use (only 'tag-based' is supported).
     * @param    array     $spreads      Optional. Array of spreads from IDML.
     * @return   array                   Array of extracted XML tags.
     */
    public function extract_custom_tags( $stories, $tag_system = 'tag-based', $spreads = array() ) {
        WP2ID_Debug::log(__METHOD__ . ' called with tag_system: ' . $tag_system, 'IDML_Reader');
        
        $tags = array();
        
        // Only process tag-based system (InDesign XML tags)
        if ( $tag_system !== 'tag-based' ) {
            error_log('WARNING: extract_custom_tags() only supports tag-based system, received: ' . $tag_system);
            return array();
        }
        
        // Get XML tags from Tags.xml file
        $xml_tags_map = array();
        $xml_tags = $this->read_xml_tags();
        
        // If we found XML tags, use them
        if ( $xml_tags && !empty( $xml_tags ) ) {
            foreach ( $xml_tags as $id => $tag_data ) {
                $tags[] = $tag_data['name'];
                $xml_tags_map[$id] = $tag_data['name'];
            }
            
            error_log('Found ' . count($xml_tags) . ' XML tags in Tags.xml');
        }
        
        // Process stories to find any XML structure or tags
        if ( !empty( $stories ) && is_array( $stories ) ) {
            foreach ( $stories as $story_id => $story ) {
                // Check if the story has XML tags information
                if ( !empty( $story['xml_tags'] ) ) {
                    foreach ( $story['xml_tags'] as $tag_ref ) {
                        if ( isset( $xml_tags_map[$tag_ref] ) ) {
                            $tags[] = $xml_tags_map[$tag_ref];
                        } else {
                            // If we don't have a mapping, just use the reference
                            $tags[] = str_replace('XMLTag/', '', $tag_ref);
                        }
                    }
                }
                
                // Process paragraphs for XML structure
                // if ( !empty( $story['paragraphs'] ) && is_array( $story['paragraphs'] ) ) {
                //     foreach ( $story['paragraphs'] as $paragraph ) {
                //         // Check for XML element references
                //         if ( !empty( $paragraph['xml_element'] ) ) {
                //             $tag_ref = $paragraph['xml_element'];
                //             if ( isset( $xml_tags_map[$tag_ref] ) ) {
                //                 $tags[] = $xml_tags_map[$tag_ref];
                //             } else {
                //                 // If we don't have a mapping, extract from reference
                //                 $tags[] = str_replace('XMLTag/', '', $tag_ref);
                //             }
                //         }
                        
                //         // Check for markup tags
                //         // if ( !empty( $paragraph['markup_tag'] ) ) {
                //         //     $tag_ref = $paragraph['markup_tag'];
                //         //     if ( isset( $xml_tags_map[$tag_ref] ) ) {
                //         //         $tags[] = $xml_tags_map[$tag_ref];
                //         //     } else {
                //         //         // If we don't have a mapping, extract from reference
                //         //         $tags[] = str_replace('XMLTag/', '', $tag_ref);
                //         //     }
                //         // }
                        
                //         // Check for marker tags
                //         // if ( !empty( $paragraph['marker_tag'] ) ) {
                //         //     $tag_ref = $paragraph['marker_tag'];
                //         //     if ( isset( $xml_tags_map[$tag_ref] ) ) {
                //         //         $tags[] = $xml_tags_map[$tag_ref];
                //         //     } else {
                //         //         // If we don't have a mapping, extract from reference
                //         //         $tags[] = str_replace('XMLTag/', '', $tag_ref);
                //         //     }
                //         // }
                        
                //         // Process character styles for XML tags as well
                //         // if ( !empty( $paragraph['char_styles'] ) ) {
                //         //     foreach ( $paragraph['char_styles'] as $char_style ) {
                //         //         // Check for XML element references in character styles
                //         //         if ( !empty( $char_style['xml_element'] ) ) {
                //         //             $tag_ref = $char_style['xml_element'];
                //         //             if ( isset( $xml_tags_map[$tag_ref] ) ) {
                //         //                 $tags[] = $xml_tags_map[$tag_ref];
                //         //             } else {
                //         //                 // If we don't have a mapping, extract from reference
                //         //                 $tags[] = str_replace('XMLTag/', '', $tag_ref);
                //         //             }
                //         //         }
                                
                //         //         // Check for markup tags in character styles
                //         //         if ( !empty( $char_style['markup_tag'] ) ) {
                //         //             $tag_ref = $char_style['markup_tag'];
                //         //             if ( isset( $xml_tags_map[$tag_ref] ) ) {
                //         //                 $tags[] = $xml_tags_map[$tag_ref];
                //         //             } else {
                //         //                 // If we don't have a mapping, extract from reference
                //         //                 $tags[] = str_replace('XMLTag/', '', $tag_ref);
                //         //             }
                //         //         }
                //         //     }
                //         // }
                //     }
                // }
            }
        }
        
        // Clean up and return unique tags
        $unique_tags = array_unique( $tags );
        $total_count = count($tags);
        $unique_count = count($unique_tags);
        
        error_log('Found ' . $total_count . ' total tags with ' . $unique_count . ' unique XML tags');
        
        // Log all found tags for debugging
        if (!empty($unique_tags)) {
            error_log('XML Tags found: ' . implode(', ', $unique_tags));
        } else {
            error_log('WARNING: No XML tags were found in the IDML content!');
            
            if (empty($stories)) {
                error_log('ERROR: No stories were found in the IDML document');
            }
        }
        
        return $unique_tags;
    }
    
    /**
     * Read and parse the XML tags from the XML/Tags.xml file.
     *
     * @since    1.0.0
     * @return   array|bool    Array of XML tags or false on failure.
     */
    public function read_xml_tags() {
        if ( ! isset( $this->contents ) ) {
            if ( ! $this->extract() ) {
                return false;
            }
        }
        
        $tags_xml_path = $this->contents['path'] . '/XML/Tags.xml';
        
        if ( ! file_exists( $tags_xml_path ) ) {
            $this->errors[] = __( 'XML/Tags.xml not found in the IDML file.', 'wp2id' );
            return false;
        }
        
        // Load the Tags.xml file
        $this->dom->load( $tags_xml_path );
        
        $xml_tags = array();
        
        // Get XML tags
        $xml_tag_nodes = $this->dom->getElementsByTagName( 'XMLTag' );
        foreach ( $xml_tag_nodes as $tag ) {
            $id = $tag->getAttribute( 'Self' );
            $name = $tag->getAttribute( 'Name' );
            
            $xml_tags[$id] = array(
                'id' => $id,
                'name' => $name,
            );
        }
        
        return $xml_tags;
    }
    
    /**
     * Read and parse a specific spread file from the IDML document.
     *
     * @since    1.0.0
     * @param    string    $spread_path    The path to the spread XML file within the IDML.
     * @return   array|bool                Array of spread content or false on failure.
     */
    public function read_spread( $spread_path ) {
        if ( ! isset( $this->contents ) ) {
            if ( ! $this->extract() ) {
                return false;
            }
        }
        
        $full_path = $this->contents['path'] . '/' . $spread_path;
        
        if ( ! file_exists( $full_path ) ) {
            $this->errors[] = sprintf( __( 'Spread file not found: %s', 'wp2id' ), $spread_path );
            return false;
        }
        
        // Load the spread XML file
        $this->dom->load( $full_path );
        
        $spread = array(
            'id' => '',
            'images' => array(),
            'page_items' => array(),
            'properties' => array(),
        );
        
        // Get Spread root element
        $spread_root = $this->dom->getElementsByTagName('Spread')->item(0);
        if ($spread_root) {
            $spread['id'] = $spread_root->getAttribute('Self');
        }
        
        // Get Image elements - these can be directly in the spread or within Rectangle frames
        $image_nodes = $this->dom->getElementsByTagName('Image');
        foreach ($image_nodes as $image) {
            $image_data = array(
                'self' => $image->getAttribute('Self'),
                'properties' => array(),
                'alt_text' => '',
                'content' => ''
            );
            
            // Look for alt text in Properties
            $property_nodes = $image->getElementsByTagName('Properties');
            if ($property_nodes->length > 0) {
                foreach ($property_nodes as $property_node) {
                    $this->extract_properties($property_node, $image_data['properties']);
                }
            }
            
            // Look for alt text in common attributes
            $alt_text_attributes = array('AlternateText', 'ActualText', 'AltText', 'Description', 'Label', 'Name', 'Title');
            foreach ($alt_text_attributes as $alt_attr) {
                if ($image->hasAttribute($alt_attr)) {
                    $attr_value = $image->getAttribute($alt_attr);
                    if (!empty($attr_value)) {
                        $image_data['alt_text'] = $attr_value;
                        $image_data['properties'][$alt_attr] = $attr_value;
                        error_log("Found alt text in image attribute {$alt_attr}: {$attr_value}");
                    }
                }
            }
            
            // Check for Script Label which may contain custom tags in IDML
            if ($image->hasAttribute('ScriptLabel')) {
                $script_label = $image->getAttribute('ScriptLabel');
                if (!empty($script_label)) {
                    $image_data['alt_text'] = $script_label;
                    $image_data['properties']['ScriptLabel'] = $script_label;
                    WP2ID_Debug::log("Found ScriptLabel in image: {$script_label}", 'IDML_Reader');
                }
            }
            
            // Check for metadata in associated ObjectMetadata
            $link_nodes = $image->getElementsByTagName('Link');
            if ($link_nodes->length > 0) {
                foreach ($link_nodes as $link) {
                    $metadata_nodes = $link->getElementsByTagName('MetadataPacketPreference');
                    if ($metadata_nodes->length > 0) {
                        foreach ($metadata_nodes as $metadata) {
                            $content = $metadata->nodeValue;
                            if (!empty($content)) {
                                $image_data['content'] = $content;
                                
                                // Store image metadata for future processing
                                WP2ID_Debug::log('Found image metadata content: ' . substr($content, 0, 100), 'IDML_Reader');
                            }
                        }
                    }
                }
            }
            
            $spread['images'][] = $image_data;
        }
        
        // Get Rectangle frames (may contain images with alt text)
        $rectangle_nodes = $this->dom->getElementsByTagName('Rectangle');
        foreach ($rectangle_nodes as $rectangle) {
            $rect_data = array(
                'self' => $rectangle->getAttribute('Self'),
                'properties' => array(),
                'alt_text' => '',
                'content' => ''
            );
            
            // Look for properties and alt text
            $property_nodes = $rectangle->getElementsByTagName('Properties');
            if ($property_nodes->length > 0) {
                foreach ($property_nodes as $property_node) {
                    $this->extract_properties($property_node, $rect_data['properties']);
                }
            }
            
            // Look for alt text attributes in rectangle
            $alt_text_attributes = array('AlternateText', 'ActualText', 'AltText', 'Description');
            foreach ($alt_text_attributes as $alt_attr) {
                if ($rectangle->hasAttribute($alt_attr)) {
                    $attr_value = $rectangle->getAttribute($alt_attr);
                    if (!empty($attr_value)) {
                        $rect_data['alt_text'] = $attr_value;
                        $rect_data['properties'][$alt_attr] = $attr_value;
                    }
                }
            }
            
            // Check for ObjectMetadata within rectangle
            $metadata_nodes = $rectangle->getElementsByTagName('MetadataPacketPreference');
            if ($metadata_nodes->length > 0) {
                foreach ($metadata_nodes as $metadata) {
                    $content = $metadata->nodeValue;
                    if (!empty($content)) {
                        $rect_data['content'] = $content;
                    }
                }
            }
            
            $spread['page_items'][] = $rect_data;
        }
        
        // Get other page items that might contain alt text
        $other_item_tags = array('Oval', 'GraphicLine', 'Polygon', 'TextFrame', 'Group');
        foreach ($other_item_tags as $tag_name) {
            $item_nodes = $this->dom->getElementsByTagName($tag_name);
            foreach ($item_nodes as $item) {
                $item_data = array(
                    'type' => $tag_name,
                    'self' => $item->getAttribute('Self'),
                    'properties' => array(),
                    'alt_text' => '',
                    'content' => ''
                );
                
                // Look for properties and alt text
                $property_nodes = $item->getElementsByTagName('Properties');
                if ($property_nodes->length > 0) {
                    foreach ($property_nodes as $property_node) {
                        $this->extract_properties($property_node, $item_data['properties']);
                    }
                }
                
                // Look for alt text in common attributes
                $alt_text_attributes = array('AlternateText', 'ActualText', 'AltText', 'Description');
                foreach ($alt_text_attributes as $alt_attr) {
                    if ($item->hasAttribute($alt_attr)) {
                        $attr_value = $item->getAttribute($alt_attr);
                        if (!empty($attr_value)) {
                            $item_data['alt_text'] = $attr_value;
                            $item_data['properties'][$alt_attr] = $attr_value;
                        }
                    }
                }
                
                // If it's a TextFrame, also check the content for custom tags
                if ($tag_name === 'TextFrame') {
                    $content_nodes = $item->getElementsByTagName('Content');
                    foreach ($content_nodes as $content) {
                        $content_text = $content->nodeValue;
                        $item_data['content'] .= $content_text;
                        error_log("Found TextFrame content: {$content_text}");
                    }
                    
                    // Also check for story references in TextFrame which might contain our tags
                    $story_refs = $item->getElementsByTagName('StoryReference');
                    foreach ($story_refs as $story_ref) {
                        if ($story_ref->hasAttribute('Self')) {
                            $story_id = $story_ref->getAttribute('Self');
                            error_log("TextFrame references story: {$story_id}");
                            // Make sure to include the story ID reference
                            $item_data['story_ref'] = $story_id;
                        }
                    }
                }
                
                $spread['page_items'][] = $item_data;
            }
        }
        
        return $spread;
    }
    
    /**
     * Read and parse all spreads from the IDML document.
     *
     * @since    1.0.0
     * @return   array|bool    Array of spreads or false on failure.
     */
    public function read_all_spreads() {
        $designmap = $this->read_designmap();
        
        if ( ! $designmap ) {
            return false;
        }
        
        $spreads = array();
        
        foreach ( $designmap['spreads'] as $id => $spread_info ) {
            $spread = $this->read_spread( $spread_info['src'] );
            
            if ( $spread ) {
                $spreads[$id] = $spread;
            }
        }
        
        return $spreads;
    }
    
    /**
     * Extract properties from a Properties element.
     *
     * @since    1.0.0
     * @access   private
     * @param    DOMElement    $property_node    The Properties node.
     * @param    array         &$target_array    The array to store properties in.
     * @return   void
     */
    private function extract_properties( $property_node, &$target_array ) {
        $property_children = $property_node->childNodes;
        foreach ($property_children as $prop) {
            if ($prop->nodeType === XML_ELEMENT_NODE) {
                $prop_name = $prop->nodeName;
                $prop_value = $prop->nodeValue;
                if (!empty($prop_value)) {
                    $target_array[$prop_name] = $prop_value;
                }
                
                // Recursively extract nested properties
                if ($prop->hasChildNodes()) {
                    foreach ($prop->childNodes as $child) {
                        if ($child->nodeType === XML_ELEMENT_NODE) {
                            $nested_name = $prop_name . '/' . $child->nodeName;
                            $nested_value = $child->nodeValue;
                            if (!empty($nested_value)) {
                                $target_array[$nested_name] = $nested_value;
                            }
                        }
                    }
                }
            }
        }
    }
    
    /**
     * Extract detailed tag information including actual content from stories.
     * This method provides comprehensive tag details including content, length, 
     * and extraction metadata for the tag-based content storage system.
     *
     * @since    1.0.0
     * @param    array     $stories      Array of stories from IDML.
     * @param    string    $tag_system   The tag system to use (only 'tag-based' is supported).
     * @param    array     $spreads      Optional. Array of spreads from IDML for image tags.
     * @return   array                   Array of detailed tag information with content and metadata.
     */
    public function extract_custom_tags_detailed( $stories, $tag_system = 'tag-based', $spreads = array() ) {
        // Log method entry with parameters
        if ( class_exists( 'WP2ID_Debug' ) ) {
            WP2ID_Debug::log( __METHOD__ . ' called with tag_system: ' . $tag_system, 'IDML_Reader' );
            WP2ID_Debug::log( 'Stories count: ' . count( $stories ), 'IDML_Reader' );
            WP2ID_Debug::log( 'Spreads count: ' . count( $spreads ), 'IDML_Reader' );
        }
        
        $detailed_tags = array();
        
        // Only process tag-based system (InDesign XML tags)
        if ( $tag_system !== 'tag-based' ) {
            error_log( 'WARNING: extract_custom_tags_detailed() only supports tag-based system, received: ' . $tag_system );
            return array();
        }
        
        // Validate input
        if ( empty( $stories ) || ! is_array( $stories ) ) {
            error_log( 'WARNING: extract_custom_tags_detailed() received empty or invalid stories array' );
            return array();
        }
        
        // Read XML tags from Tags.xml - these are the official tag names
        $xml_tags = $this->read_xml_tags();
        if ( empty( $xml_tags ) ) {
            error_log( 'WARNING: No XML tags found in Tags.xml for detailed extraction' );
            return array();
        }
        
        // Create mapping from XML tag IDs to names
        $xml_tags_map = array();
        $official_tag_names = array();
        foreach ( $xml_tags as $id => $tag_data ) {
            $xml_tags_map[$id] = $tag_data['name'];
            $official_tag_names[] = $tag_data['name'];
        }
        
        if ( class_exists( 'WP2ID_Debug' ) ) {
            WP2ID_Debug::log( 'XML Tags available: ' . implode( ', ', $official_tag_names ), 'IDML_Reader' );
        }
        
        // Step 1: Build mapping between internal IDs and official XML tag names
        $internal_id_to_tag_mapping = array();
        $found_content_by_tag = array();
        
        foreach ( $stories as $story_id => $story ) {
            if ( empty( $story['content'] ) ) {
                continue;
            }
            
            // Method 1: Extract from paragraphs with detailed content mapping
            if ( ! empty( $story['paragraphs'] ) && is_array( $story['paragraphs'] ) ) {
                foreach ( $story['paragraphs'] as $paragraph_index => $paragraph ) {
                    $internal_tag = $this->extract_tag_from_paragraph( $paragraph, $xml_tags_map );
                    
                    if ( $internal_tag && ! empty( $paragraph['content'] ) ) {
                        $content = $this->finalize_extracted_content( $paragraph['content'] );
                        
                        // Check if this internal tag maps to an official XML tag
                        $official_tag = null;
                        if ( in_array( $internal_tag, $official_tag_names ) ) {
                            // This is already an official tag name
                            $official_tag = $internal_tag;
                        } else {
                            // This might be an internal ID (like di2i4) - try to find matching official tag
                            foreach ( $official_tag_names as $xml_tag ) {
                                // Check if content matches with any tag found via story xml_tags
                                if ( ! empty( $story['xml_tags'] ) ) {
                                    foreach ( $story['xml_tags'] as $tag_ref ) {
                                        $potential_tag = isset( $xml_tags_map[$tag_ref] ) ? $xml_tags_map[$tag_ref] : null;
                                        if ( $potential_tag === $xml_tag ) {
                                            // Map internal ID to official tag
                                            $internal_id_to_tag_mapping[$internal_tag] = $xml_tag;
                                            $official_tag = $xml_tag;
                                            break 2;
                                        }
                                    }
                                }
                            }
                        }
                        
                        if ( $official_tag ) {
                            $word_count = $this->count_words( $content );
                            $page_info = $this->extract_page_info( $story_id, $spreads );
                            
                            $found_content_by_tag[$official_tag] = array(
                                'type' => $this->determine_tag_type( $official_tag, $content ),
                                'content' => $content,
                                'length' => strlen( $content ),
                                'word_count' => $word_count,
                                'page_info' => $page_info,
                                'source_story' => $story_id,
                                'paragraph_index' => $paragraph_index,
                                'extraction_method' => 'paragraph_content',
                                'style_info' => $this->extract_style_info( $paragraph ),
                                'internal_id' => $internal_tag !== $official_tag ? $internal_tag : null
                            );
                            
                            if ( class_exists( 'WP2ID_Debug' ) ) {
                                WP2ID_Debug::log( "Mapped internal tag '{$internal_tag}' to official tag '{$official_tag}': length=" . strlen( $content ), 'IDML_Reader' );
                            }
                        }
                    }
                }
            }
        }
        
        // Step 2: Process official XML tags only
        foreach ( $official_tag_names as $tag_name ) {
            // Check if we already found content for this tag via paragraph mapping
            if ( isset( $found_content_by_tag[$tag_name] ) ) {
                $detailed_tags[$tag_name] = $found_content_by_tag[$tag_name];
                continue;
            }
            
            // Method 2: Fallback - use story xml_tags for tags not found in paragraphs
            $found_in_stories = false;
            foreach ( $stories as $story_id => $story ) {
                if ( ! empty( $story['xml_tags'] ) && is_array( $story['xml_tags'] ) ) {
                    foreach ( $story['xml_tags'] as $tag_ref ) {
                        $potential_tag = isset( $xml_tags_map[$tag_ref] ) ? $xml_tags_map[$tag_ref] : null;
                        
                        if ( $potential_tag === $tag_name ) {
                            $content = $this->finalize_extracted_content( $story['content'] );
                            $tag_type = $this->determine_tag_type( $tag_name, $content );
                            $word_count = $this->count_words( $content );
                            $page_info = $this->extract_page_info( $story_id, $spreads );
                            
                            $detailed_tags[$tag_name] = array(
                                'type' => $tag_type,
                                'content' => $content,
                                'length' => strlen( $content ),
                                'word_count' => $word_count,
                                'page_info' => $page_info,
                                'source_story' => $story_id,
                                'extraction_method' => $tag_type === 'image' ? 'image_placeholder' : 'story_fallback',
                                'tag_ref' => $tag_ref,
                                'internal_id' => $tag_ref !== $tag_name ? $tag_ref : null
                            );
                            
                            if ( class_exists( 'WP2ID_Debug' ) ) {
                                WP2ID_Debug::log( "Extracted official tag '{$tag_name}' via fallback: type={$tag_type}, length=" . strlen( $content ), 'IDML_Reader' );
                            }
                            $found_in_stories = true;
                            break 2; // Found the tag, move to next official tag
                        }
                    }
                }
            }
            
            // Method 3: Ensure image tags are always included even if not found in stories
            if ( ! $found_in_stories ) {
                $tag_type = $this->determine_tag_type( $tag_name, '' );
                $empty_page_info = array( 'page_numbers' => array(), 'spread_names' => array(), 'first_page' => null );
                
                if ( $tag_type === 'image' ) {
                    $detailed_tags[$tag_name] = array(
                        'type' => 'image',
                        'content' => '', // Empty content for image placeholder
                        'length' => 0,
                        'word_count' => 0,
                        'page_info' => $empty_page_info,
                        'source_story' => null,
                        'extraction_method' => 'image_placeholder_default',
                        'tag_ref' => null,
                        'internal_id' => null
                    );
                    
                    if ( class_exists( 'WP2ID_Debug' ) ) {
                        WP2ID_Debug::log( "Added missing image tag '{$tag_name}' as placeholder", 'IDML_Reader' );
                    }
                } else {
                    // For text tags not found anywhere, also include with empty content
                    $detailed_tags[$tag_name] = array(
                        'type' => 'text',
                        'content' => '', // Empty content for missing text tag
                        'length' => 0,
                        'word_count' => 0,
                        'page_info' => $empty_page_info,
                        'source_story' => null,
                        'extraction_method' => 'text_placeholder_default',
                        'tag_ref' => null,
                        'internal_id' => null
                    );
                    
                    if ( class_exists( 'WP2ID_Debug' ) ) {
                        WP2ID_Debug::log( "Added missing text tag '{$tag_name}' as placeholder", 'IDML_Reader' );
                    }
                }
            }
        }
        
        // Log summary
        if ( class_exists( 'WP2ID_Debug' ) ) {
            WP2ID_Debug::log( 'extract_custom_tags_detailed() found ' . count( $detailed_tags ) . ' detailed tags', 'IDML_Reader' );
            if ( ! empty( $detailed_tags ) ) {
                $tag_names = array_keys( $detailed_tags );
                WP2ID_Debug::log( 'Detailed tags: ' . implode( ', ', $tag_names ), 'IDML_Reader' );
            }
        }
        
        return $detailed_tags;
    }
    
    /**
     * Count words in text content.
     * 
     * @since    1.0.0
     * @param    string    $text    The text to count words in.
     * @return   int                Number of words.
     */
    private function count_words( $text ) {
        if ( empty( $text ) ) {
            return 0;
        }
        
        // Remove HTML tags if any
        $text = strip_tags( $text );
        
        // Remove extra whitespace and trim
        $text = trim( preg_replace( '/\s+/', ' ', $text ) );
        
        if ( empty( $text ) ) {
            return 0;
        }
        
        // Split by spaces and count
        $words = explode( ' ', $text );
        return count( array_filter( $words, function( $word ) {
            return trim( $word ) !== '';
        }));
    }

    /**
     * Extract page information for a story from spreads data.
     * 
     * @since    1.0.0
     * @param    string    $story_id    The story ID.
     * @param    array     $spreads     Array of spreads data.
     * @return   array                  Page information array with page numbers and spread names.
     */
    private function extract_page_info( $story_id, $spreads ) {
        $page_info = array(
            'page_numbers' => array(),
            'spread_names' => array(),
            'first_page' => null
        );
        
        if ( empty( $spreads ) || ! is_array( $spreads ) ) {
            return $page_info;
        }
        
        // Search through spreads to find which pages contain this story
        foreach ( $spreads as $spread_id => $spread_data ) {
            if ( ! isset( $spread_data['src'] ) ) {
                continue;
            }
            
            // Try to read the spread file to find story references
            $spread_content = $this->read_spread( $spread_data['src'] );
            if ( ! $spread_content || ! isset( $spread_content['page_items'] ) ) {
                continue;
            }
            
            // Check if this spread contains our story
            $story_found = false;
            foreach ( $spread_content['page_items'] as $item ) {
                if ( isset( $item['story_ref'] ) && $item['story_ref'] === $story_id ) {
                    $story_found = true;
                    break;
                }
            }
            
            if ( $story_found ) {
                // Extract page number from spread ID or name
                $page_number = $this->extract_page_number_from_spread( $spread_id, $spread_data );
                if ( $page_number ) {
                    $page_info['page_numbers'][] = $page_number;
                    $page_info['spread_names'][] = $spread_id;
                    
                    if ( $page_info['first_page'] === null || $page_number < $page_info['first_page'] ) {
                        $page_info['first_page'] = $page_number;
                    }
                }
            }
        }
        
        // Sort page numbers
        if ( ! empty( $page_info['page_numbers'] ) ) {
            sort( $page_info['page_numbers'] );
        }
        
        return $page_info;
    }

    /**
     * Extract page number from spread ID or data.
     * 
     * @since    1.0.0
     * @param    string    $spread_id      The spread ID.
     * @param    array     $spread_data    The spread data.
     * @return   int|null                  Page number or null if not found.
     */
    private function extract_page_number_from_spread( $spread_id, $spread_data ) {
        // Try to extract page number from spread ID (common patterns)
        if ( preg_match( '/page[_\-\s]*(\d+)/i', $spread_id, $matches ) ) {
            return intval( $matches[1] );
        }
        
        if ( preg_match( '/spread[_\-\s]*(\d+)/i', $spread_id, $matches ) ) {
            return intval( $matches[1] );
        }
        
        // Try to extract from spread source filename
        if ( isset( $spread_data['src'] ) ) {
            $filename = basename( $spread_data['src'], '.xml' );
            if ( preg_match( '/(\d+)/', $filename, $matches ) ) {
                return intval( $matches[1] );
            }
        }
        
        // Default fallback - return a generic page number based on spread order
        static $page_counter = 1;
        return $page_counter++;
    }

    /**
     * Determine the type of a tag based on its name and content.
     * 
     * @since    1.0.0
     * @param    string    $tag_name    The tag name.
     * @param    string    $content     The content associated with the tag.
     * @return   string                 The tag type ('text' or 'image').
     */
    private function determine_tag_type( $tag_name, $content ) {
        // Check if tag name suggests it's an image
        $image_keywords = array( 'image', 'img', 'photo', 'picture', 'pic', 'graphic', 'logo', 'icon' );
        
        $tag_name_lower = strtolower( $tag_name );
        foreach ( $image_keywords as $keyword ) {
            if ( strpos( $tag_name_lower, $keyword ) !== false ) {
                return 'image';
            }
        }
        
        // If content is empty or very short, and tag name suggests image, it's likely an image placeholder
        if ( empty( $content ) && ( strpos( $tag_name_lower, '_image' ) !== false || 
                                   strpos( $tag_name_lower, 'image_' ) !== false ) ) {
            return 'image';
        }
        
        // Default to text
        return 'text';
    }

    /**
     * Extract style information from a paragraph element.
     * 
     * @since    1.0.0
     * @param    array    $paragraph    The paragraph data array.
     * @return   array                  Style information array.
     */
    private function extract_style_info( $paragraph ) {
        $style_info = array(
            'font_family' => null,
            'font_size' => null,
            'font_style' => null,
            'color' => null,
            'alignment' => null
        );
        
        // This is a placeholder implementation
        // In a real implementation, you would parse the paragraph's style attributes
        // and extract font family, size, color, etc.
        
        if ( is_array( $paragraph ) && isset( $paragraph['style'] ) ) {
            // Parse style attributes if available
            $style_info['raw_style'] = $paragraph['style'];
        }
        
        return $style_info;
    }

    /**
     * Extract tag from paragraph content.
     * 
     * @since    1.0.0
     * @param    array     $paragraph       The paragraph data.
     * @param    array     $xml_tags_map    Mapping of XML tag IDs to names.
     * @return   string|null                Tag name or internal ID if found, null otherwise.
     */
    private function extract_tag_from_paragraph( $paragraph, $xml_tags_map ) {
        // Method 1: Check for markup_tag from XMLElement structure
        if ( isset( $paragraph['markup_tag'] ) && ! empty( $paragraph['markup_tag'] ) ) {
            $markup_tag = $paragraph['markup_tag'];
            
            // If it's in the XML tags map, return the official tag name
            if ( isset( $xml_tags_map[$markup_tag] ) ) {
                return $xml_tags_map[$markup_tag];
            }
            
            // Otherwise return the internal tag ID as-is for further processing
            return $markup_tag;
        }
        
        // Method 2: Check if paragraph has xml_element_id or similar internal reference
        if ( isset( $paragraph['xml_element_id'] ) && ! empty( $paragraph['xml_element_id'] ) ) {
            return $paragraph['xml_element_id'];
        }
        
        // Method 3: Check for Self attribute which might contain internal IDs
        if ( isset( $paragraph['self'] ) && ! empty( $paragraph['self'] ) ) {
            // Self attributes often look like "di2i4", "di2i5", etc.
            $self_id = $paragraph['self'];
            
            // Check if this matches any official tags first
            if ( in_array( $self_id, $xml_tags_map ) ) {
                return array_search( $self_id, $xml_tags_map );
            }
            
            // Return internal ID for mapping
            return $self_id;
        }
        
        // Method 4: Parse from any XML structure within the paragraph
        if ( isset( $paragraph['xml_content'] ) && ! empty( $paragraph['xml_content'] ) ) {
            // Try to extract MarkupTag from XML content
            if ( preg_match( '/MarkupTag="([^"]+)"/', $paragraph['xml_content'], $matches ) ) {
                $tag_ref = $matches[1];
                
                // Remove XMLTag/ prefix if present
                $tag_ref = str_replace( 'XMLTag/', '', $tag_ref );
                
                // Check if it's in the XML tags map
                if ( isset( $xml_tags_map[$tag_ref] ) ) {
                    return $xml_tags_map[$tag_ref];
                }
                
                return $tag_ref;
            }
        }
        
        return null;
    }

    /**
     * Process paragraph content and extract data.
     * 
     * @since    1.0.0
     * @param    DOMElement    $paragraph       The paragraph DOM element.
     * @param    array         $paragraph_data  The paragraph data array.
     * @param    array         $story           The story data array.
     * @return   void
     */
    private function process_paragraph_content( $paragraph, &$paragraph_data, &$story ) {
        // This is a helper method to process paragraph content
        // Extract text content from the paragraph
        $content = '';
        
        if ( $paragraph instanceof DOMElement ) {
            $content = $paragraph->textContent;
        }
        
        // Clean up the content
        $content = $this->finalize_extracted_content( $content );
        
        // Store in paragraph data
        $paragraph_data['content'] = $content;
        
        // Add to story content if not already present
        if ( ! isset( $story['content'] ) ) {
            $story['content'] = '';
        }
        
        $story['content'] .= $content . ' ';
    }
    
    /**
     * Finalize extracted content by cleaning and normalizing it.
     * 
     * @since    1.0.0
     * @param    string    $content    The raw content to finalize.
     * @return   string                The finalized content.
     */
    private function finalize_extracted_content( $content ) {
        if ( empty( $content ) ) {
            return '';
        }
        
        // Ensure content is a string
        if ( ! is_string( $content ) ) {
            $content = (string) $content;
        }
        
        // Clean up whitespace
        $content = trim( $content );
        
        // Replace multiple whitespace with single spaces
        $content = preg_replace( '/\s+/', ' ', $content );
        
        // Remove any XML/HTML tags if present
        $content = strip_tags( $content );
        
        // Decode HTML entities
        $content = html_entity_decode( $content, ENT_QUOTES, 'UTF-8' );
        
        return $content;
    }
}