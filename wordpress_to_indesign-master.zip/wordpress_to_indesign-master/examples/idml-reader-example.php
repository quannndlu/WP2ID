<?php
/**
 * Example usage of the WP2ID_IDML_Reader class.
 *
 * This file demonstrates how to use the WP2ID_IDML_Reader class to read and process IDML files.
 *
 * @since      1.0.0
 * @package    WP2ID
 * @subpackage WP2ID/examples
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Example function for reading an IDML file.
 *
 * This function demonstrates how to use the WP2ID_IDML_Reader class to read and process an IDML file.
 *
 * @since    1.0.0
 * @param    string    $file_path    The path to the IDML file.
 * @return   array                   Array of IDML file information.
 */
function wp2id_read_idml_example( $file_path ) {
    // Ensure the IDML reader class is loaded
    require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wp2id-idml-reader.php';
    
    // Create a new instance of the IDML reader
    $reader = new WP2ID_IDML_Reader( $file_path );
    
    // Extract the IDML file
    if ( ! $reader->extract() ) {
        return array(
            'success' => false,
            'error' => $reader->get_last_error(),
        );
    }
    
    // Read the designmap (main structure of the document)
    $designmap = $reader->read_designmap();
    if ( ! $designmap ) {
        $reader->cleanup();
        return array(
            'success' => false,
            'error' => $reader->get_last_error(),
        );
    }
    
    // Read all stories (text content)
    $stories = $reader->read_all_stories();
    if ( ! $stories ) {
        $reader->cleanup();
        return array(
            'success' => false,
            'error' => $reader->get_last_error(),
        );
    }
    
    // Read styles
    $styles = $reader->read_styles();
    if ( ! $styles ) {
        $reader->cleanup();
        return array(
            'success' => false,
            'error' => $reader->get_last_error(),
        );
    }
    
    // Read metadata
    $metadata = $reader->read_metadata();
    if ( ! $metadata ) {
        $reader->cleanup();
        return array(
            'success' => false,
            'error' => $reader->get_last_error(),
        );
    }
    
    // Clean up temporary files
    $reader->cleanup();
    
    // Return the extracted information
    return array(
        'success' => true,
        'designmap' => $designmap,
        'stories' => $stories,
        'styles' => $styles,
        'metadata' => $metadata,
    );
}

/**
 * Example function for processing IDML content.
 *
 * This function demonstrates how to process the content extracted from an IDML file.
 *
 * @since    1.0.0
 * @param    array    $idml_data    The IDML data extracted by wp2id_read_idml_example().
 * @return   string                 A summary of the IDML content.
 */
function wp2id_process_idml_example( $idml_data ) {
    if ( ! $idml_data['success'] ) {
        return 'Error: ' . $idml_data['error'];
    }
    
    $summary = '';
    
    // Process metadata
    if ( ! empty( $idml_data['metadata'] ) ) {
        $summary .= "IDML Metadata:\n";
        foreach ( $idml_data['metadata'] as $key => $value ) {
            $summary .= "- $key: $value\n";
        }
        $summary .= "\n";
    }
    
    // Process styles
    $summary .= "IDML Styles:\n";
    $summary .= "- Paragraph Styles: " . count( $idml_data['styles']['paragraph'] ) . "\n";
    $summary .= "- Character Styles: " . count( $idml_data['styles']['character'] ) . "\n";
    $summary .= "\n";
    
    // Process stories
    $summary .= "IDML Stories:\n";
    foreach ( $idml_data['stories'] as $story_id => $story ) {
        $summary .= "- Story ID: $story_id\n";
        $summary .= "  Content length: " . strlen( $story['content'] ) . " characters\n";
        $summary .= "  Paragraphs: " . count( $story['paragraphs'] ) . "\n";
    }
    
    return $summary;
}

/**
 * Example function for converting IDML stories to HTML.
 *
 * This function demonstrates how to convert the content extracted from an IDML file to HTML.
 *
 * @since    1.0.0
 * @param    array    $stories    The stories extracted from the IDML file.
 * @param    array    $styles     The styles extracted from the IDML file.
 * @return   array               HTML representation of each story.
 */
function wp2id_convert_stories_to_html_example( $stories, $styles ) {
    $html_stories = array();
    
    foreach ( $stories as $story_id => $story ) {
        $html = '';
        
        foreach ( $story['paragraphs'] as $paragraph ) {
            $para_style_id = $paragraph['style_id'];
            $para_style_name = isset( $styles['paragraph'][$para_style_id]['name'] ) ? $styles['paragraph'][$para_style_id]['name'] : '';
            
            $html .= '<p class="' . esc_attr( sanitize_title( $para_style_name ) ) . '">';
            
            foreach ( $paragraph['char_styles'] as $char_style ) {
                $char_style_id = $char_style['style_id'];
                $char_style_name = isset( $styles['character'][$char_style_id]['name'] ) ? $styles['character'][$char_style_id]['name'] : '';
                
                if ( $char_style_name && $char_style_name !== '[No character style]' ) {
                    $html .= '<span class="' . esc_attr( sanitize_title( $char_style_name ) ) . '">';
                    $html .= esc_html( $char_style['content'] );
                    $html .= '</span>';
                } else {
                    $html .= esc_html( $char_style['content'] );
                }
            }
            
            $html .= '</p>';
        }
        
        $html_stories[$story_id] = $html;
    }
    
    return $html_stories;
}
