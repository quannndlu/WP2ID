/**
 * WP2ID Content Warnings System JavaScript
 *
 * Handles real-time content analysis, capacity warnings, and user interactions
 * for the content warnings system in WordPress admin.
 *
 * @since      1.0.0
 * @package    WP2ID
 * @subpackage WP2ID/admin/js
 */

(function($) {
    'use strict';

    /**
     * Content Warnings Manager
     */
    var WP2IDContentWarnings = {
        
        /**
         * Initialize the content warnings system
         */
        init: function() {
            this.bindEvents();
            this.initializeMeters();
            this.startRealTimeMonitoring();
            
            // Initial content analysis
            this.analyzeCurrentContent();
        },
        
        /**
         * Bind event handlers
         */
        bindEvents: function() {
            var self = this;
            
            // Monitor content changes in real-time
            $('#title, #content, [id^="acf-"], .wp2id-content-field').on('input keyup paste', 
                this.debounce(function() {
                    self.analyzeCurrentContent();
                }, 500)
            );
            
            // Monitor template selection changes
            $('#wp2id_publication_template').on('change', function() {
                self.onTemplateChange();
            });
            
            // Handle preview actions
            $(document).on('click', '.wp2id-preview-content', function(e) {
                e.preventDefault();
                self.previewContent($(this).data('tag'));
            });
            
            // Handle optimization suggestions
            $(document).on('click', '.wp2id-optimize-content', function(e) {
                e.preventDefault();
                self.showOptimizationSuggestions($(this).data('tag'));
            });
            
            // Handle manual refresh
            $(document).on('click', '.wp2id-refresh-warnings', function(e) {
                e.preventDefault();
                self.forceRefresh();
            });
            
            // WordPress editor integration
            if (typeof wp !== 'undefined' && wp.data && wp.data.select) {
                // Gutenberg integration
                wp.data.subscribe(function() {
                    self.analyzeCurrentContent();
                });
            }
            
            // Classic editor integration
            if (typeof tinyMCE !== 'undefined') {
                $(document).on('tinymce-editor-init', function(event, editor) {
                    editor.on('input keyup paste undo redo', function() {
                        self.analyzeCurrentContent();
                    });
                });
            }
        },
        
        /**
         * Initialize capacity meters with animations
         */
        initializeMeters: function() {
            $('.wp2id-capacity-meter').each(function() {
                var $meter = $(this);
                var $fill = $meter.find('.wp2id-capacity-fill');
                var percentage = parseFloat($fill.data('percentage')) || 0;
                
                // Animate the meter fill
                setTimeout(function() {
                    $fill.css('width', percentage + '%');
                }, 100);
            });
        },
        
        /**
         * Start real-time monitoring
         */
        startRealTimeMonitoring: function() {
            var self = this;
            
            // Monitor every 30 seconds for any missed changes
            setInterval(function() {
                if (self.hasContentChanged()) {
                    self.analyzeCurrentContent();
                }
            }, 30000);
        },
        
        /**
         * Check if content has changed since last analysis
         */
        hasContentChanged: function() {
            var currentContent = this.getCurrentContent();
            var lastContent = this.lastAnalyzedContent || '';
            
            return JSON.stringify(currentContent) !== JSON.stringify(lastContent);
        },
        
        /**
         * Get current content from all fields
         */
        getCurrentContent: function() {
            var content = {};
            
            // Get title
            content.title = $('#title').val() || '';
            
            // Get main content
            if (typeof wp !== 'undefined' && wp.data && wp.data.select) {
                // Gutenberg
                var editor = wp.data.select('core/editor');
                if (editor && editor.getEditedPostContent) {
                    content.content = editor.getEditedPostContent() || '';
                }
            } else if (typeof tinyMCE !== 'undefined' && tinyMCE.get('content')) {
                // Classic editor
                content.content = tinyMCE.get('content').getContent() || '';
            } else {
                // Fallback to textarea
                content.content = $('#content').val() || '';
            }
            
            // Get custom fields
            $('[id^="acf-"], .wp2id-content-field').each(function() {
                var $field = $(this);
                var fieldName = $field.attr('name') || $field.attr('id');
                if (fieldName) {
                    content[fieldName] = $field.val() || '';
                }
            });
            
            return content;
        },
        
        /**
         * Analyze current content and update warnings
         */
        analyzeCurrentContent: function() {
            var self = this;
            var content = this.getCurrentContent();
            
            // Store for comparison
            this.lastAnalyzedContent = content;
            
            // Show loading state
            this.showLoadingState();
            
            // Make AJAX request for analysis
            $.ajax({
                url: wp2idWarnings.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'wp2id_analyze_content_warnings',
                    nonce: wp2idWarnings.nonce,
                    content: content,
                    post_id: $('#post_ID').val() || 0
                },
                success: function(response) {
                    if (response.success) {
                        self.updateWarningsDisplay(response.data);
                    } else {
                        self.showError(response.data || wp2idWarnings.strings.contentTooLong);
                    }
                },
                error: function() {
                    self.showError('Failed to analyze content. Please try again.');
                },
                complete: function() {
                    self.hideLoadingState();
                }
            });
        },
        
        /**
         * Update the warnings display with new data
         */
        updateWarningsDisplay: function(data) {
            var $container = $('#wp2id-warnings-list');
            var $stats = $('#wp2id-warnings-stats');
            
            if (!data.warnings || !data.statistics) {
                return;
            }
            
            // Update warning items
            $container.empty();
            
            if (data.warnings.length === 0) {
                $container.html('<p class="wp2id-no-warnings">' + wp2idWarnings.strings.contentOptimal + '</p>');
            } else {
                data.warnings.forEach(function(warning) {
                    var $item = this.createWarningItem(warning);
                    $container.append($item);
                }.bind(this));
            }
            
            // Update statistics
            this.updateStatistics(data.statistics);
            
            // Add update indicator
            this.showUpdateIndicator();
        },
        
        /**
         * Create a warning item element
         */
        createWarningItem: function(warning) {
            var $item = $('<div class="wp2id-warning-item ' + warning.level + '">');
            
            var $icon = $('<div class="wp2id-warning-icon ' + warning.level + '">');
            var $content = $('<div class="wp2id-warning-content">');
            
            var $tag = $('<div class="wp2id-warning-tag">').text(warning.tag);
            var $message = $('<div class="wp2id-warning-message">').text(warning.message);
            
            // Create capacity meter
            var $meter = this.createCapacityMeter(warning.capacity);
            
            // Create action buttons
            var $actions = this.createActionButtons(warning.tag, warning.level);
            
            $content.append($tag, $message, $meter, $actions);
            $item.append($icon, $content);
            
            return $item;
        },
        
        /**
         * Create capacity meter element
         */
        createCapacityMeter: function(capacity) {
            var $meter = $('<div class="wp2id-capacity-meter">');
            var $bar = $('<div class="wp2id-capacity-bar">');
            var $fill = $('<div class="wp2id-capacity-fill ' + capacity.level + '">');
            var $text = $('<div class="wp2id-capacity-text">').text(capacity.percentage + '%');
            
            $fill.css('width', '0%'); // Start at 0 for animation
            $fill.data('percentage', capacity.percentage);
            
            // Animate to actual percentage
            setTimeout(function() {
                $fill.css('width', capacity.percentage + '%');
            }, 100);
            
            $bar.append($fill);
            $meter.append($bar, $text);
            
            return $meter;
        },
        
        /**
         * Create action buttons for warning items
         */
        createActionButtons: function(tag, level) {
            var $actions = $('<div class="wp2id-warning-actions">');
            
            // Preview button
            var $preview = $('<button class="wp2id-action-button wp2id-preview-content">')
                .text(wp2idWarnings.strings.previewContent)
                .data('tag', tag);
            
            $actions.append($preview);
            
            // Add optimization suggestion for high-level warnings
            if (level === 'critical' || level === 'warning') {
                var $optimize = $('<button class="wp2id-action-button primary wp2id-optimize-content">')
                    .text(wp2idWarnings.strings.suggestTruncation)
                    .data('tag', tag);
                
                $actions.append($optimize);
            }
            
            return $actions;
        },
        
        /**
         * Update statistics display
         */
        updateStatistics: function(stats) {
            var $stats = $('#wp2id-warnings-stats');
            $stats.empty();
            
            Object.keys(stats).forEach(function(key) {
                var stat = stats[key];
                var $item = $('<div class="wp2id-stat-item">');
                var $number = $('<span class="wp2id-stat-number">').text(stat.value);
                var $label = $('<span class="wp2id-stat-label">').text(stat.label);
                
                $item.append($number, $label);
                $stats.append($item);
            });
        },
        
        /**
         * Handle template change
         */
        onTemplateChange: function() {
            var self = this;
            var templateId = $('#wp2id_publication_template').val();
            
            if (!templateId) {
                $('#wp2id-content-warnings-container').hide();
                return;
            }
            
            // Reload template tags and re-analyze
            this.loadTemplateData(templateId, function() {
                self.analyzeCurrentContent();
                $('#wp2id-content-warnings-container').show();
            });
        },
        
        /**
         * Load template data for new template
         */
        loadTemplateData: function(templateId, callback) {
            $.ajax({
                url: wp2idWarnings.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'wp2id_load_template_data',
                    nonce: wp2idWarnings.nonce,
                    template_id: templateId
                },
                success: function(response) {
                    if (response.success && callback) {
                        callback(response.data);
                    }
                }
            });
        },
        
        /**
         * Preview content for a specific tag
         */
        previewContent: function(tag) {
            var content = this.getCurrentContent();
            
            // Open preview in new window or modal
            var previewWindow = window.open('', 'wp2id-preview', 'width=800,height=600');
            previewWindow.document.write('<html><head><title>Content Preview: ' + tag + '</title></head><body>');
            previewWindow.document.write('<h2>Preview for tag: ' + tag + '</h2>');
            previewWindow.document.write('<div style="font-family: Arial, sans-serif; padding: 20px;">');
            
            // Show relevant content for the tag
            Object.keys(content).forEach(function(key) {
                if (content[key]) {
                    previewWindow.document.write('<h3>' + key + '</h3>');
                    previewWindow.document.write('<p>' + content[key].substring(0, 500) + '...</p>');
                }
            });
            
            previewWindow.document.write('</div></body></html>');
            previewWindow.document.close();
        },
        
        /**
         * Show optimization suggestions
         */
        showOptimizationSuggestions: function(tag) {
            var message = wp2idWarnings.strings.suggestTruncation + ' for tag: ' + tag;
            
            // Create a simple modal or use WordPress admin notices
            var $notice = $('<div class="notice notice-warning is-dismissible">')
                .html('<p>' + message + '</p>');
            
            $('.wrap h1').after($notice);
            
            // Auto-dismiss after 5 seconds
            setTimeout(function() {
                $notice.fadeOut();
            }, 5000);
        },
        
        /**
         * Force refresh of warnings
         */
        forceRefresh: function() {
            this.lastAnalyzedContent = null;
            this.analyzeCurrentContent();
        },
        
        /**
         * Show loading state
         */
        showLoadingState: function() {
            $('#wp2id-content-warnings-container').addClass('wp2id-loading');
            
            var $spinner = $('.wp2id-loading-spinner');
            if ($spinner.length === 0) {
                $spinner = $('<div class="wp2id-loading-spinner">').appendTo('.wp2id-warnings-header');
            }
        },
        
        /**
         * Hide loading state
         */
        hideLoadingState: function() {
            $('#wp2id-content-warnings-container').removeClass('wp2id-loading');
            $('.wp2id-loading-spinner').remove();
        },
        
        /**
         * Show update indicator
         */
        showUpdateIndicator: function() {
            var $indicator = $('.wp2id-update-indicator');
            if ($indicator.length === 0) {
                $indicator = $('<div class="wp2id-update-indicator">').appendTo('.wp2id-warnings-header');
            }
            
            // Remove after animation
            setTimeout(function() {
                $indicator.fadeOut(function() {
                    $(this).remove();
                });
            }, 2000);
        },
        
        /**
         * Show error message
         */
        showError: function(message) {
            var $error = $('<div class="notice notice-error">')
                .html('<p>' + message + '</p>');
            
            $('#wp2id-warnings-list').html($error);
        },
        
        /**
         * Debounce function to limit API calls
         */
        debounce: function(func, wait) {
            var timeout;
            return function executedFunction() {
                var later = function() {
                    clearTimeout(timeout);
                    func.apply(this, arguments);
                }.bind(this);
                
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }
    };

    /**
     * Initialize when document is ready
     */
    $(document).ready(function() {
        // Only initialize on publication edit screens
        if ($('#wp2id-content-warnings-container').length > 0) {
            WP2IDContentWarnings.init();
        }
    });

    /**
     * Expose to global scope for debugging
     */
    window.WP2IDContentWarnings = WP2IDContentWarnings;

})(jQuery);
