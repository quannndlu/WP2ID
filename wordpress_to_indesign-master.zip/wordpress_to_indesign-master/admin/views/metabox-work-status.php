<?php
/**
 * Work Status Select View for Publication Metabox
 *
 * @since 1.0.0
 * @package WP2ID
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wp2id-work-status-select">
    <label for="wp2id_work_status"><?php _e('Work Status:', 'wp2id'); ?></label>
    <select name="wp2id_work_status" id="wp2id_work_status" class="widefat">
        <option value="initialization" class="status-init-option" <?php selected($work_status, 'initialization'); ?>><?php _e('Initialization', 'wp2id'); ?></option>
        <option value="list_created" class="status-list-option" <?php selected($work_status, 'list_created'); ?>><?php _e('List Created', 'wp2id'); ?></option>
        <option value="completed" class="status-completed-option" <?php selected($work_status, 'completed'); ?>><?php _e('Completed', 'wp2id'); ?></option>
    </select>
    <p class="description"><?php _e('Current work status of this publication.', 'wp2id'); ?></p>
</div>
