<?php

/**
 * Template Select View for Publication Metabox
 *
 * @since 1.0.0
 * @package WP2ID
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Get saved upload mode
$upload_mode = get_post_meta($post->ID, '_wp2id_publication_upload_mode', true);
if (empty($upload_mode)) {
    $upload_mode = 'template'; // Default value
}

// Get saved direct IDML file
$direct_idml_file = get_post_meta($post->ID, '_wp2id_publication_direct_idml_file', true);
$direct_idml_filename = '';
if ($direct_idml_file) {
    $direct_idml_filename = basename(get_attached_file($direct_idml_file));
}

// Get saved direct IDML tags for display
$direct_idml_tags = get_post_meta($post->ID, '_wp2id_publication_direct_idml_tags_details', true);
?>

<div class="wp2id-template-select">
    <!-- Template Selection Section -->
    <div class="wp2id-section">
        <label for="wp2id_template_id"><?php _e('Select Template:', 'wp2id'); ?></label>
        <select name="wp2id_template_id" id="wp2id_template_id" class="widefat">
            <option value=""><?php _e('— Select Template —', 'wp2id'); ?></option>
            <?php foreach ($templates as $template) : ?>
                <option value="<?php echo $template->ID; ?>" <?php selected($template_id, $template->ID); ?>>
                    <?php echo esc_html($template->post_title); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <p class="description"><?php _e('Select the InDesign template to use for this publication.', 'wp2id'); ?></p>
    </div>

    <div class="wp2id-separator">
        <span><?php _e('— OR —', 'wp2id'); ?></span>
    </div>

    <!-- Direct IDML Upload Section -->
    <div class="wp2id-section">
        <label><?php _e('Upload IDML File Directly:', 'wp2id'); ?></label>
        <div class="idml-upload-section">
            <button type="button" id="upload-direct-idml" class="button">
                <!-- <span class="dashicons dashicons-upload"></span> -->
                <?php _e('Select IDML File', 'wp2id'); ?>
            </button>
            <input type="hidden" name="wp2id_direct_idml_file" id="wp2id_direct_idml_file" value="<?php echo esc_attr($direct_idml_file); ?>">

            <!-- Hidden field to track upload mode automatically -->
            <input type="hidden" name="wp2id_upload_mode" id="wp2id_upload_mode" value="<?php echo esc_attr($upload_mode); ?>">

            <!-- Hidden field to track file preservation -->
            <?php if ($direct_idml_file): ?>
                <input type="hidden" name="wp2id_idml_file_exists" value="1">
            <?php endif; ?>

            <div id="selected-idml-info" style="display: <?php echo $direct_idml_file ? 'block' : 'none'; ?>;">
                <p><strong><?php _e('Selected file:', 'wp2id'); ?></strong> <span id="idml-filename"><?php echo esc_html($direct_idml_filename); ?></span></p>
                <div class="idml-file-actions">
                    <button type="button" id="remove-direct-idml" class="button"><?php _e('Remove', 'wp2id'); ?></button>
                    <?php if ($upload_mode === 'direct_idml' && !empty($direct_idml_tags)) : ?>
                        <button type="button" id="show-tags-dialog" class="button button-secondary danger">
                            <!-- <span class="dashicons dashicons-tag"></span> -->
                            <?php _e('Show Tags', 'wp2id'); ?>
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Tags Modal Dialog -->
<div id="wp2id-tags-dialog" class="wp2id-modal" style="display: none;">
    <div class="wp2id-modal-content">
        <div class="wp2id-modal-header">
            <h2><?php _e('Extracted Tags', 'wp2id'); ?></h2>
            <button type="button" class="wp2id-modal-close" aria-label="<?php _e('Close', 'wp2id'); ?>">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <div class="wp2id-modal-body">
            <div id="tags-dialog-content">
                <?php if (!empty($direct_idml_tags)) : ?>
                    <div class="wp2id-tags-details">
                        <div class="wp2id-tags-details-table">
                            <table class="wp-list-table widefat fixed striped">
                                <thead>
                                    <tr>
                                        <th scope="col"><?php _e('Tag Name', 'wp2id'); ?></th>
                                        <th scope="col"><?php _e('Type', 'wp2id'); ?></th>
                                        <th scope="col"><?php _e('Length', 'wp2id'); ?></th>
                                        <th scope="col"><?php _e('Page', 'wp2id'); ?></th>
                                        <th scope="col"><?php _e('Content Preview', 'wp2id'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php error_log(print_r($direct_idml_tags, true)); ?>
                                    <?php foreach ($direct_idml_tags as $tag_name => $details) : ?>
                                        <?php
                                        $source_story = isset($details['source_story']) ? $details['source_story'] : '';
                                        $internal_id = isset($details['internal_id']) ? $details['internal_id'] : '';
                                        $tag_type = isset($details['type']) ? $details['type'] : 'text';
                                        $char_count = isset($details['length']) ? $details['length'] : '0';
                                        $word_count = isset($details['word_count']) ? $details['word_count'] : '0';
                                        $content_preview = isset($details['content']) ? $details['content'] : '';
                                        $page_info = isset($details['page_info']) ? $details['page_info'] : array();

                                        // Build tag ID display
                                        $tag_id_display = $source_story;
                                        if ($internal_id) {
                                            $tag_id_display .= '/' . $internal_id;
                                        }

                                        // Build page display
                                        $page_display = '-';
                                        if (isset($page_info['page_numbers']) && !empty($page_info['page_numbers'])) {
                                            $pages = array_unique($page_info['page_numbers']);
                                            sort($pages);
                                            if (count($pages) > 3) {
                                                $page_display = $pages[0] . '-' . end($pages);
                                            } else {
                                                $page_display = implode(', ', $pages);
                                            }
                                        }

                                        // Truncate content preview
                                        if (strlen($content_preview) > 100) {
                                            $content_preview = substr($content_preview, 0, 100) . '...';
                                        }
                                        ?>
                                        <tr>
                                            <td class="tag-id">
                                                <code class="tag-name"> <strong><?php echo esc_html($tag_name); ?></strong> </code>
                                                <br>
                                                <code class="id-tag"><?php echo esc_html($tag_id_display); ?></code>
                                            </td>
                                            <td class="tag-type">
                                                <span class="tag-type-badge tag-type-<?php echo esc_attr(strtolower($tag_type)); ?>">
                                                    <?php echo esc_html(ucfirst($tag_type)); ?>
                                                </span>
                                            </td>
                                            <td class="tag-length">
                                                <?php echo esc_html($char_count . ' chars'); ?>
                                                <?php if ($tag_type !== 'image' && intval($word_count) > 0) : ?>
                                                    <br><small><?php echo esc_html($word_count . ' words'); ?></small>
                                                <?php endif; ?>
                                            </td>
                                            <td class="tag-page">
                                                <?php echo esc_html($page_display); ?>
                                            </td>
                                            <td class="tag-content">
                                                <?php echo esc_html($content_preview); ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php else : ?>
                    <p><?php _e('No tags found in the IDML file.', 'wp2id'); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="wp2id-modal-footer">
            <button type="button" class="button button-primary wp2id-modal-close"><?php _e('Close', 'wp2id'); ?></button>
        </div>
    </div>
</div>

<style>
    /* Section styling */

    .dander{
        background-color: #da251d;
    }
    .wp2id-section {
        margin-bottom: 20px;
        padding: 15px;
        background: #f9f9f9;
        border: 1px solid #ddd;
        border-radius: 4px;
    }

    .wp2id-section.disabled {
        opacity: 0.6;
        background: #f5f5f5;
    }

    .wp2id-section.disabled select,
    .wp2id-section.disabled button {
        pointer-events: none;
        opacity: 0.5;
    }

    .wp2id-separator {
        text-align: center;
        margin: 15px 0;
        position: relative;
    }

    .wp2id-separator:before {
        content: '';
        position: absolute;
        top: 50%;
        left: 0;
        right: 0;
        height: 1px;
        background: #ddd;
        z-index: 1;
    }

    .wp2id-separator span {
        background: #fff;
        padding: 0 15px;
        color: #666;
        font-size: 12px;
        position: relative;
        z-index: 2;
    }

    .idml-upload-section {
        margin-bottom: 10px;
        margin-top: 10px;
    }

    #upload-direct-idml {
        margin-bottom: 10px;
    }

    #selected-idml-info {
        padding: 10px;
        background: #e7f3ff;
        border: 1px solid #b3d9ff;
        border-radius: 4px;
        margin-top: 10px;
    }

    #selected-idml-info p {
        margin: 0 0 10px 0;
    }

    .idml-file-actions {
        display: flex;
        gap: 10px;
        align-items: center;
    }

    .idml-file-actions button {
        flex-shrink: 0;
    }

    /* Modal Dialog Styles */
    .wp2id-modal {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        z-index: 999999;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .wp2id-modal-content {
        background: white;
        border-radius: 4px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        max-width: 90%;
        max-height: 90%;
        width: 1000px;
        display: flex;
        flex-direction: column;
    }

    .wp2id-modal-header {
        padding: 20px;
        border-bottom: 1px solid #ddd;
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: #f9f9f9;
        border-radius: 4px 4px 0 0;
    }

    .wp2id-modal-header h2 {
        margin: 0;
        font-size: 18px;
        font-weight: 600;
    }

    .wp2id-modal-close {
        background: none;
        border: none;
        font-size: 20px;
        cursor: pointer;
        padding: 0;
        color: #666;
        line-height: 1;
    }

    .wp2id-modal-close:hover {
        color: #000;
    }

    .wp2id-modal-body {
        padding: 20px;
        flex: 1;
        overflow-y: auto;
    }

    .wp2id-modal-footer {
        padding: 20px;
        border-top: 1px solid #ddd;
        text-align: right;
        background: #f9f9f9;
        border-radius: 0 0 4px 4px;
    }

    /* Tags table styles within modal */
    .wp2id-modal .tag-name strong {
            color: #0073aa;
            font-weight: 600;
        }
    .wp2id-modal .wp2id-tags-details-table {
        overflow-x: auto;
    }

    .wp2id-modal .wp2id-tags-details-table table {
        min-width: 800px;
    }

    .wp2id-modal .wp2id-tags-details-table th,
    .wp2id-modal .wp2id-tags-details-table td {
        padding: 12px 8px;
        text-align: left;
    }

    .wp2id-modal .wp2id-tags-details-table th {
        background: #f1f1f1;
        font-weight: 600;
        border-bottom: 1px solid #ddd;
    }

    .wp2id-modal .wp2id-tags-details-table td {
        border-bottom: 1px solid #eee;
    }

    .wp2id-modal .wp2id-tags-details-table tr:hover {
        background: #f9f9f9;
    }

    /* Tags metabox styling (removed from main layout) */
    .wp2id-tags-metabox {
        margin-top: 20px;
        padding: 15px;
        background: #fff;
        border: 1px solid #c3c4c7;
        border-radius: 4px;
    }

    .wp2id-tags-metabox h4 {
        margin: 0 0 15px 0;
        font-size: 13px;
        font-weight: 600;
    }

    /* Tag table styles */
    .wp2id-tags-details-table .tag-type-badge {
        padding: 2px 8px;
        border-radius: 3px;
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .tag-type-text {
        background-color: #0073aa;
        color: white;
    }

    .tag-type-image {
        background-color: #00a0d2;
        color: white;
    }

    .id-tag {
        background: #f0f0f1;
        padding: 2px 6px;
        border-radius: 3px;
        font-family: Consolas, Monaco, monospace;
        font-size: 12px;
    }

    /* Prevent body scroll when modal is open */
    body.wp2id-modal-open {
        overflow: hidden;
    }
</style>

<script>
    jQuery(document).ready(function($) {
        // Show Tags Dialog
        $('#show-tags-dialog').on('click', function(e) {
            e.preventDefault();
            $('#wp2id-tags-dialog').show();
            $('body').addClass('wp2id-modal-open');
        });

        // Close Tags Dialog
        $('.wp2id-modal-close').on('click', function(e) {
            e.preventDefault();
            $('#wp2id-tags-dialog').hide();
            $('body').removeClass('wp2id-modal-open');
        });

        // Close dialog when clicking outside
        $('#wp2id-tags-dialog').on('click', function(e) {
            if (e.target === this) {
                $('#wp2id-tags-dialog').hide();
                $('body').removeClass('wp2id-modal-open');
            }
        });

        // Close dialog with Escape key
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape' && $('#wp2id-tags-dialog').is(':visible')) {
                $('#wp2id-tags-dialog').hide();
                $('body').removeClass('wp2id-modal-open');
            }
        });
    });
</script>