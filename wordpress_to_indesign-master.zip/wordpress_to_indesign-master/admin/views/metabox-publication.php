<?php

/**
 * Publication Posts Metabox View
 *
 * @since 1.0.0
 * @package WP2ID
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Check permissions for displaying tabs and features
$can_access_search = WP2ID_Permission_Manager::current_user_can('access_search_results');
$can_access_workarea = WP2ID_Permission_Manager::current_user_can('access_work_area');
$can_remove_posts = WP2ID_Permission_Manager::current_user_can('remove_posts');
$can_export = WP2ID_Permission_Manager::current_user_can('export_publications');

// If user has no permissions, show message
if (!$can_access_search && !$can_access_workarea) {
    echo '<div class="wp2id-no-permission">';
    echo '<p>' . __('You do not have permission to access any publication features.', 'wp2id') . '</p>';
    echo '</div>';
    return;
}
?>

<div class="wp2id-posts-metabox">
    <!-- Tab navigation -->
    <div class="wp2id-tabs-nav">
        <?php if ($can_access_search): ?>
            <a href="#" class="wp2id-tab-link <?php echo !$can_access_workarea ? 'active' : ''; ?>" data-tab="search"><?php _e('Search', 'wp2id'); ?></a>
        <?php endif; ?>
        <?php if ($can_access_workarea): ?>
            <a href="#" class="wp2id-tab-link <?php echo $can_access_workarea ? 'active' : ''; ?>" data-tab="workarea"><?php _e('WorkArea', 'wp2id'); ?></a>
        <?php endif; ?>
    </div>

    <!-- Tab contents -->
    <div class="wp2id-tabs-content"><?php if ($can_access_search): ?>
            <!-- Search Tab -->
            <div class="wp2id-tab-content <?php echo !$can_access_workarea ? 'active' : ''; ?>" id="wp2id-tab-search">
                <!-- Filter Form -->
                <div class="wp2id-filter-box">
                    <h3><?php _e('Filter Posts', 'wp2id'); ?></h3>
                    <div class="filter-row">
                        <div class="filter-item">
                            <label for="wp2id_post_category"><?php _e('Category:', 'wp2id'); ?></label>
                            <select id="wp2id_post_category">
                                <option value=""><?php _e('All Categories', 'wp2id'); ?></option>
                                <?php foreach ($categories as $category) : ?>
                                    <option value="<?php echo $category->term_id; ?>">
                                        <?php echo esc_html($category->name); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="filter-item">
                            <label for="wp2id_post_date"><?php _e('Date:', 'wp2id'); ?></label>
                            <select id="wp2id_post_date">
                                <option value=""><?php _e('Any Date', 'wp2id'); ?></option>
                                <option value="today"><?php _e('Today', 'wp2id'); ?></option>
                                <option value="week"><?php _e('This Week', 'wp2id'); ?></option>
                                <option value="month"><?php _e('This Month', 'wp2id'); ?></option>
                            </select>
                        </div>

                        <div class="filter-item">
                            <label for="wp2id_post_author"><?php _e('Author:', 'wp2id'); ?></label>
                            <?php wp_dropdown_users(array(
                                            'show_option_all' => __('All Authors', 'wp2id'),
                                            'name' => 'wp2id_post_author',
                                            'id' => 'wp2id_post_author'
                                        )); ?>
                        </div>
                        <div class="filter-item">
                            <label for="wp2id_post_search"><?php _e('Search:', 'wp2id'); ?></label>
                            <input type="text" id="wp2id_post_search" placeholder="<?php esc_attr_e('Search posts...', 'wp2id'); ?>">
                        </div>
                    </div>

                    <div class="filter-row">
                        <div class="filter-actions">
                            <button type="button" class="button" id="wp2id_filter_posts"><?php _e('Search Posts', 'wp2id'); ?></button>
                            <button type="button" class="button" id="wp2id_reset_filters"><?php _e('Reset', 'wp2id'); ?></button>
                        </div>
                    </div>
                </div>

                <!-- Search Results -->
                <div class="wp2id-search-results">
                    <h3><?php _e('Search Results', 'wp2id'); ?></h3>
                    <div id="wp2id_search_results_container">
                        <p class="description"><?php _e('Use the filters above to search for posts.', 'wp2id'); ?></p>
                    </div>
                    <div id="wp2id_search_results_pagination" class="tablenav"></div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($can_access_workarea): ?>
            <!-- WorkArea Tab -->
            <div class="wp2id-tab-content <?php echo $can_access_workarea ? 'active' : ''; ?>" id="wp2id-tab-workarea">

                <!-- Selected Posts -->
                <div class="wp2id-selected-posts">
                    <div class="wp2id-publication-header">
                        <div class="wp2id-publication-title">
                        <h3><?php _e('Selected Posts', 'wp2id'); ?></h3>
                        </div>
                        <!-- Preview and Export Actions -->
                        <div class="wp2id-publication-actions">
                            <h3><?php _e('Publication Actions', 'wp2id'); ?></h3>
                            <div class="publication-actions-form">
                                <!-- <button type="button" class="button button-secondary" id="wp2id_preview_publication">
                        <span class="dashicons dashicons-visibility"></span>
                        <?php _e('Preview Publication', 'wp2id'); ?>
                    </button> -->
                                <?php if ($can_export): ?>
                                    <button type="button" class="button button-primary" id="wp2id_export_publication">
                                        <!-- <span class="dashicons dashicons-download"></span> -->
                                        <?php _e('Export to InDesign', 'wp2id'); ?>
                                    </button>
                                <?php endif; ?>
                                </button>
                            </div>
                            <!-- <p class="description">
                                <?php _e('Preview your publication layout or export it to InDesign format.', 'wp2id'); ?>
                            </p> -->
                        </div>
                    </div>
                    

                    <p><?php _e('Manage your selected posts below.', 'wp2id'); ?></p>

                    <!-- Hidden field to store all post mappings -->
                    <?php
                    // Get saved post mappings for this publication
                    $wp2id_post_mappings = get_post_meta($post->ID, '_wp2id_post_mappings', true);
                    WP2ID_Debug::log('wp2id_post_mappings: ' . print_r($wp2id_post_mappings, true), 'Publication');
                    if (empty($wp2id_post_mappings)) {
                        $wp2id_post_mappings = array();
                    }
                    ?>
                    <input type="hidden" id="wp2id_post_mappings" name="wp2id_post_mappings" value="<?php echo esc_attr(json_encode($wp2id_post_mappings)); ?>" />
                    <div class="wp2id-table-container">
                        <table id="wp2id_selected_posts" class="wp2id-posts-table widefat">
                            <thead>
                                <tr>
                                    <th class="check-column">
                                        <input type="checkbox" id="wp2id-select-all-posts" title="<?php esc_attr_e('Select all posts', 'wp2id'); ?>">
                                    </th>
                                    <th class="id-column">
                                        <?php _e('ID', 'wp2id'); ?>
                                    </th>
                                    <th class="title-column">
                                        <?php _e('Post Title', 'wp2id'); ?>
                                    </th>
                                    <th class="image-column">
                                        <?php _e('Feature Image', 'wp2id'); ?>
                                    </th>
                                    <th class="content-column">
                                        <?php _e('Content', 'wp2id'); ?>
                                    </th>
                                    <th class="excerpt-column">
                                        <?php _e('Excerpt', 'wp2id'); ?>
                                    </th>
                                    <th class="author-column">
                                        <?php _e('Author', 'wp2id'); ?>
                                    </th>
                                    <th class="date-column">
                                        <?php _e('Date', 'wp2id'); ?>
                                    </th>
                                    <th class="category-column">
                                        <?php _e('Category', 'wp2id'); ?>
                                    </th>
                                    <th class="page-column">
                                        <?php _e('Page', 'wp2id'); ?>
                                    </th>
                                    <th class="actions-column"><?php _e('Actions', 'wp2id'); ?></th>
                                </tr>
                            </thead>
                            <tbody id="wp2id_selected_posts_body" class="wp2id-sortable-list">
                                <?php
                                if (!empty($publication_posts)) {
                                    foreach ($publication_posts as $index => $post_id) {
                                        $post_obj = get_post($post_id);
                                        if (!$post_obj) {
                                            continue; // Skip if post doesn't exist
                                        }

                                        // Get post data
                                        $post_title = get_the_title($post_id);
                                        $post_type = get_post_type($post_id);
                                        $author_id = get_post_field('post_author', $post_id);
                                        $author_name = get_the_author_meta('display_name', $author_id);
                                        $post_date = get_the_date('', $post_id);

                                        // Get thumbnail - larger size for better preview
                                        $thumbnail = get_the_post_thumbnail($post_id, array(150, 150));
                                        if (empty($thumbnail)) {
                                            $thumbnail = '<div class="no-thumbnail">' . __('No Image', 'wp2id') . '</div>';
                                        }

                                        // Get excerpt
                                        $excerpt = has_excerpt($post_id) ? get_the_excerpt($post_id) : wp_trim_words(get_the_content(null, false, $post_id), 10);

                                        // Get content preview
                                        $content_preview = wp_trim_words(get_the_content(null, false, $post_id), 15);

                                        // Get categories
                                        $categories = get_the_category($post_id);
                                        $category_list = array();
                                        if (!empty($categories)) {
                                            foreach ($categories as $category) {
                                                $category_list[] = $category->name;
                                            }
                                        }
                                        $categories_str = !empty($category_list) ? implode(', ', $category_list) : __('Uncategorized', 'wp2id');
                                        // Get position data for this post if available
                                        $post_position_data = isset($position_data[$post_id]) ? $position_data[$post_id] : array();
                                        $position_json = htmlspecialchars(json_encode($post_position_data), ENT_QUOTES, 'UTF-8');
                                        $position_classes = array();

                                        // Add position classes for columns with position settings
                                        foreach (array('title', 'content', 'excerpt', 'image', 'author', 'date', 'category') as $element) {
                                            if (isset($post_position_data[$element])) {
                                                if (!empty($post_position_data[$element]['horizontal'])) {
                                                    $position_classes[$element][] = 'pos-' . $post_position_data[$element]['horizontal'];
                                                }
                                                if (!empty($post_position_data[$element]['vertical'])) {
                                                    $position_classes[$element][] = 'pos-' . $post_position_data[$element]['vertical'];
                                                }
                                            }
                                        }
                                ?>
                                        <tr id="post-<?php echo $post_id; ?>" class="post-row" data-post-id="<?php echo $post_id; ?>" data-positions='<?php echo $position_json; ?>'>
                                            <td class="check-column">
                                                <input type="checkbox" class="wp2id-post-check" name="wp2id_post_check[]" value="<?php echo $post_id; ?>">
                                                <input type="hidden" name="wp2id_publication_posts[]" value="<?php echo $post_id; ?>">
                                            </td>
                                            <td class="id-column"><?php echo $post_id; ?></td>
                                            <td class="title-column <?php echo isset($position_classes['title']) ? implode(' ', $position_classes['title']) : ''; ?>">
                                                <?php echo esc_html($post_title); ?>
                                                <?php if (isset($post_position_data['title'])): ?>
                                                    <span class="wp2id-position-label">
                                                        <?php
                                                        $pos_text = array();
                                                        if (!empty($post_position_data['title']['horizontal'])) $pos_text[] = $post_position_data['title']['horizontal'];
                                                        if (!empty($post_position_data['title']['vertical'])) $pos_text[] = $post_position_data['title']['vertical'];
                                                        echo implode('-', $pos_text);
                                                        ?>
                                                    </span>
                                                <?php endif; ?>
                                                <?php if (!empty($post_position_data)): ?>
                                                    <input type="hidden" name="wp2id_positions[<?php echo $post_id; ?>]" value='<?php echo $position_json; ?>'>
                                                <?php endif; ?>
                                            </td>
                                            <td class="image-column <?php echo isset($position_classes['image']) ? implode(' ', $position_classes['image']) : ''; ?>">
                                                <?php echo $thumbnail; ?>
                                                <?php if (isset($post_position_data['image'])): ?>
                                                    <span class="wp2id-position-label">
                                                        <?php
                                                        $pos_text = array();
                                                        if (!empty($post_position_data['image']['horizontal'])) $pos_text[] = $post_position_data['image']['horizontal'];
                                                        if (!empty($post_position_data['image']['vertical'])) $pos_text[] = $post_position_data['image']['vertical'];
                                                        echo implode('-', $pos_text);
                                                        ?>
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="content-column <?php echo isset($position_classes['content']) ? implode(' ', $position_classes['content']) : ''; ?>">
                                                <div class="content-preview"><?php echo esc_html($content_preview); ?></div>
                                                <?php if (isset($post_position_data['content'])): ?>
                                                    <span class="wp2id-position-label">
                                                        <?php
                                                        $pos_text = array();
                                                        if (!empty($post_position_data['content']['horizontal'])) $pos_text[] = $post_position_data['content']['horizontal'];
                                                        if (!empty($post_position_data['content']['vertical'])) $pos_text[] = $post_position_data['content']['vertical'];
                                                        echo implode('-', $pos_text);
                                                        ?>
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="excerpt-column <?php echo isset($position_classes['excerpt']) ? implode(' ', $position_classes['excerpt']) : ''; ?>">
                                                <div class="excerpt-preview"><?php echo esc_html($excerpt); ?></div>
                                                <?php if (isset($post_position_data['excerpt'])): ?>
                                                    <span class="wp2id-position-label">
                                                        <?php
                                                        $pos_text = array();
                                                        if (!empty($post_position_data['excerpt']['horizontal'])) $pos_text[] = $post_position_data['excerpt']['horizontal'];
                                                        if (!empty($post_position_data['excerpt']['vertical'])) $pos_text[] = $post_position_data['excerpt']['vertical'];
                                                        echo implode('-', $pos_text);
                                                        ?>
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="author-column <?php echo isset($position_classes['author']) ? implode(' ', $position_classes['author']) : ''; ?>">
                                                <?php echo esc_html($author_name); ?>
                                                <?php if (isset($post_position_data['author'])): ?>
                                                    <span class="wp2id-position-label">
                                                        <?php
                                                        $pos_text = array();
                                                        if (!empty($post_position_data['author']['horizontal'])) $pos_text[] = $post_position_data['author']['horizontal'];
                                                        if (!empty($post_position_data['author']['vertical'])) $pos_text[] = $post_position_data['author']['vertical'];
                                                        echo implode('-', $pos_text);
                                                        ?>
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="date-column <?php echo isset($position_classes['date']) ? implode(' ', $position_classes['date']) : ''; ?>">
                                                <?php echo $post_date; ?>
                                                <?php if (isset($post_position_data['date'])): ?>
                                                    <span class="wp2id-position-label">
                                                        <?php
                                                        $pos_text = array();
                                                        if (!empty($post_position_data['date']['horizontal'])) $pos_text[] = $post_position_data['date']['horizontal'];
                                                        if (!empty($post_position_data['date']['vertical'])) $pos_text[] = $post_position_data['date']['vertical'];
                                                        echo implode('-', $pos_text);
                                                        ?>
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="category-column <?php echo isset($position_classes['category']) ? implode(' ', $position_classes['category']) : ''; ?>">
                                                <?php echo esc_html($categories_str); ?>
                                                <?php if (isset($post_position_data['category'])): ?>
                                                    <span class="wp2id-position-label">
                                                        <?php
                                                        $pos_text = array();
                                                        if (!empty($post_position_data['category']['horizontal'])) $pos_text[] = $post_position_data['category']['horizontal'];
                                                        if (!empty($post_position_data['category']['vertical'])) $pos_text[] = $post_position_data['category']['vertical'];
                                                        echo implode('-', $pos_text);
                                                        ?>
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="page-column">
                                                <?php
                                                // Get saved page number for this post
                                                $saved_page_number = get_post_meta($post->ID, '_wp2id_post_page_numbers', true);
                                                $post_page_number = '';
                                                if (is_array($saved_page_number) && isset($saved_page_number[$post_id])) {
                                                    $post_page_number = $saved_page_number[$post_id];
                                                }
                                                ?>
                                                <span class="post-page-number"><?php echo esc_html($post_page_number); ?></span>
                                                <input type="hidden" name="wp2id_page_numbers[<?php echo $post_id; ?>]" value="<?php echo esc_attr($post_page_number); ?>">
                                            </td>
                                            <td class="actions-column">
                                                <a href="#" class="wp2id-set-position button button-small" data-id="<?php echo $post_id; ?>">
                                                    <?php _e('Mappings', 'wp2id'); ?>
                                                </a>
                                                <?php if ($can_remove_posts): ?>
                                                    <a href="#" class="wp2id-remove-post button button-small" data-id="<?php echo $post_id; ?>">
                                                        <?php _e('Remove', 'wp2id'); ?>
                                                    </a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php
                                    }
                                } else {
                                    ?>
                                    <tr class="no-posts">
                                        <td colspan="11"><?php _e('No posts selected. Use the Search tab to find and add posts.', 'wp2id'); ?></td>
                                    </tr>
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Position Dialog -->
<div class="wp2id-position-overlay"></div>
<div class="wp2id-position-dialog" id="wp2id-position-dialog">
    <div class="wp2id-position-dialog-header">
        <h3 class="wp2id-position-dialog-title"><?php _e('Map Template Tags', 'wp2id'); ?></h3>
        <a href="#" class="wp2id-position-dialog-close">&times;</a>
    </div>

    <div class="wp2id-position-dialog-content">
        <!-- Left Panel: Template Tag Mapping -->
        <div class="wp2id-dialog-left-panel">
            <h4 class="wp2id-mapping-section-title">
                <span class="dashicons dashicons-admin-links"></span>
                <?php _e('Template Tag Mapping', 'wp2id'); ?>
            </h4>

            <!-- Page Information Display -->
            <div class="wp2id-page-info-display" id="wp2id-page-info-display" style="display: none;">
                <div class="wp2id-page-info-content">
                    <span class="wp2id-page-info-label"><?php _e('Target Page:', 'wp2id'); ?></span>
                    <span class="wp2id-page-info-value" id="wp2id-page-info-value"></span>
                </div>
            </div>

            <input type="hidden" id="wp2id-position-post-id" value="">

            <div class="wp2id-position-content-container">
                <!-- Tags Content -->
                <div class="wp2id-tags-options">
                    <!-- Loading message will be replaced by AJAX -->
                    <p class="wp2id-tags-loading"><?php _e('Loading template tags...', 'wp2id'); ?></p>

                    <div class="wp2id-tags-mapping-container" style="display: none;">
                        <div class="wp2id-position-group">
                            <div class="wp2id-vertical-mapping-list" id="wp2id-tag-mapping-list">
                                <!-- Will be populated by JavaScript -->
                            </div>
                        </div>
                    </div>

                    <div class="wp2id-no-template-message" style="display: none;">
                        <p><?php _e('No template selected or no tags available.', 'wp2id'); ?></p>
                    </div>
                </div>
            </div>

            <div class="wp2id-position-actions">
                <button type="button" id="wp2id-save-position" class="button button-primary"><?php _e('Save Tag Mappings', 'wp2id'); ?></button>
                <button type="button" id="wp2id-cancel-position" class="button"><?php _e('Cancel', 'wp2id'); ?></button>
            </div>
        </div>

        <!-- Right Panel: Post Preview -->
        <div class="wp2id-dialog-right-panel">
            <h4 class="wp2id-mapping-section-title">
                <span class="dashicons dashicons-visibility"></span>
                <?php _e('Post Preview', 'wp2id'); ?>
            </h4>

            <div id="wp2id-post-preview-container">
                <p class="wp2id-preview-loading"><?php _e('Loading post preview...', 'wp2id'); ?></p>
            </div>
        </div>
    </div>
</div>