/**
 * WP2ID Publication Admin List JavaScript
 * Adds basic functionality for work status badge
 */

jQuery(document).ready(function($) {
    // No additional functionality needed for badges
    // The CSS alone provides the needed styling
});
