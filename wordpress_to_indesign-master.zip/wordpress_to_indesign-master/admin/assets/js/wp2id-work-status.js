/**
 * WP2ID Work Status JavaScript
 * Handles visual enhancements for publication work status
 */

(function($) {
    'use strict';
    
    // On DOM ready
    $(document).ready(function() {
        
        // For edit publication page - update status indicator when select changes
        function initStatusSelect() {
            if ($('#wp2id_work_status').length) {
                $('#wp2id_work_status').on('change', function() {
                    var status = $(this).val();
                    var $indicator = $('#wp2id-status-indicator');
                    
                    // Remove all status classes
                    $indicator.removeClass('wp2id-status-initialization wp2id-status-list-created wp2id-status-completed');
                    
                    // Add appropriate class based on selected status
                    $indicator.addClass('wp2id-status-' + status);
                    
                    // Update status label
                    var statusLabel = '';
                    if (status === 'initialization') {
                        statusLabel = wp2id_work_status.labels.initialization;
                    } else if (status === 'list_created') {
                        statusLabel = wp2id_work_status.labels.list_created;
                    } else {
                        statusLabel = wp2id_work_status.labels.completed;
                    }
                    
                    $indicator.find('.status-label').text(statusLabel);
                    
                    // Maybe update progress indicators or other UI elements
                    updateProgressBar(status);
                });
            }
        }
        
        // Update progress bar based on status
        function updateProgressBar(status) {
            var $progressBar = $('.wp2id-status-progress-bar');
            if ($progressBar.length) {
                if (status === 'initialization') {
                    $progressBar.css('width', '33%');
                } else if (status === 'list_created') {
                    $progressBar.css('width', '66%');
                } else {
                    $progressBar.css('width', '100%');
                }
            }
        }
        
        // Initialize
        initStatusSelect();
    });
    
})(jQuery);
