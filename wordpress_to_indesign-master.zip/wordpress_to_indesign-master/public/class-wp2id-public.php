<?php
/**
 * The public-facing functionality of the plugin.
 *
 * @since      1.0.0
 * @package    WP2ID
 * @subpackage WP2ID/public
 */

if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 */
class WP2ID_Public {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param    string    $plugin_name       The name of this plugin.
     * @param    string    $version    The version of this plugin.
     */
    public function __construct( $plugin_name, $version ) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    /**
     * Register the stylesheets for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_styles() {
        wp_enqueue_style(
            $this->plugin_name,
            plugin_dir_url( __FILE__ ) . '../assets/css/wp2id-public.css',
            array(),
            $this->version,
            'all'
        );
    }

    /**
     * Register the JavaScript for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts() {
        // Security best practice: Use nonces for AJAX requests
        $nonce = wp_create_nonce('wp2id_public_nonce');
        
        wp_enqueue_script(
            $this->plugin_name,
            plugin_dir_url( __FILE__ ) . '../assets/js/wp2id-public.js',
            array( 'jquery' ),
            $this->version,
            false
        );
        
        // Pass nonce and other variables to JS
        wp_localize_script(
            $this->plugin_name,
            'wp2id_public',
            array(
                'ajax_url' => admin_url( 'admin-ajax.php' ),
                'nonce' => $nonce
            )
        );
    }
}
